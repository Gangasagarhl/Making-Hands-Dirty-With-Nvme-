@echo off
rem Force-stops every running Mouse Jiggler (the PowerShell process running MouseJiggler.ps1).
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p = Get-CimInstance Win32_Process -Filter \"Name='powershell.exe'\" | Where-Object { $_.CommandLine -like '*MouseJiggler.ps1*' -and $_.ProcessId -ne $PID };" ^
  "if ($p) { $p | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }; Write-Host ('Mouse Jiggler stopped (' + @($p).Count + ' process).') } else { Write-Host 'Mouse Jiggler is not running.' }"
ping -n 4 127.0.0.1 >nul
