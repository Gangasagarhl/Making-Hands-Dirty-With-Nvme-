# MouseJiggler - keeps the screen awake by nudging the mouse periodically.
# Also tells Windows the display is required (SetThreadExecutionState), so sleep/lock
# timers are blocked even if an app ignores synthetic mouse input.
param([switch]$Check)  # -Check: compile, nudge once, exit (no GUI)

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class Jiggle {
    [StructLayout(LayoutKind.Sequential)]
    struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)]
    struct INPUT { public uint type; public MOUSEINPUT mi; }

    [DllImport("user32.dll", SetLastError = true)]
    static extern uint SendInput(uint nInputs, INPUT[] inputs, int cbSize);
    [DllImport("kernel32.dll")]
    static extern uint SetThreadExecutionState(uint flags);
    [DllImport("user32.dll")]
    static extern short GetAsyncKeyState(int vKey);

    // True while Esc is held down, in any application (does not block Esc for other apps).
    public static bool EscPressed() { return (GetAsyncKeyState(0x1B) & 0x8000) != 0; }

    const uint MOUSEEVENTF_MOVE = 0x0001;

    static void Move(int dx, int dy) {
        var a = new INPUT[1];
        a[0].type = 0;
        a[0].mi.dx = dx; a[0].mi.dy = dy;
        a[0].mi.dwFlags = MOUSEEVENTF_MOVE;
        SendInput(1, a, Marshal.SizeOf(typeof(INPUT)));
    }

    [StructLayout(LayoutKind.Sequential)]
    struct POINT { public int X; public int Y; }
    [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")] static extern bool SetCursorPos(int x, int y);

    // Real input event (resets the idle timer), then put the cursor back exactly where it was.
    public static void Nudge(int px) {
        POINT p;
        GetCursorPos(out p);
        Move(px, 0);
        System.Threading.Thread.Sleep(50);
        Move(-px, 0);
        System.Threading.Thread.Sleep(20);
        SetCursorPos(p.X, p.Y);
    }

    // ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED, or just ES_CONTINUOUS to release.
    public static void KeepAwake(bool on) {
        SetThreadExecutionState(on ? 0x80000003u : 0x80000000u);
    }
}
"@

if ($Check) {
    $before = [System.Windows.Forms.Cursor]::Position
    [Jiggle]::Nudge(1)
    "OK - compiled and nudged. Cursor before: $before, after: $([System.Windows.Forms.Cursor]::Position)"
    return
}

# ---------- UI ----------
$form = New-Object System.Windows.Forms.Form
$form.Text = "Mouse Jiggler"
$form.Size = New-Object System.Drawing.Size(300, 225)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'

$lblInterval = New-Object System.Windows.Forms.Label
$lblInterval.Text = "Interval (seconds):"
$lblInterval.Location = '15,20'; $lblInterval.AutoSize = $true
$numInterval = New-Object System.Windows.Forms.NumericUpDown
$numInterval.Location = '170,17'; $numInterval.Width = 90
$numInterval.Minimum = 1; $numInterval.Maximum = 3600; $numInterval.Value = 30

$lblPixels = New-Object System.Windows.Forms.Label
$lblPixels.Text = "Move distance (pixels):"
$lblPixels.Location = '15,52'; $lblPixels.AutoSize = $true
$numPixels = New-Object System.Windows.Forms.NumericUpDown
$numPixels.Location = '170,49'; $numPixels.Width = 90
$numPixels.Minimum = 1; $numPixels.Maximum = 200; $numPixels.Value = 1

$status = New-Object System.Windows.Forms.Label
$status.Location = '15,85'; $status.Size = '260,20'

$hint = New-Object System.Windows.Forms.Label
$hint.Text = "Press Esc anywhere to stop."
$hint.Location = '15,155'; $hint.AutoSize = $true; $hint.ForeColor = 'Gray'

$btn = New-Object System.Windows.Forms.Button
$btn.Location = '15,115'; $btn.Size = '120,32'

$btnTray = New-Object System.Windows.Forms.Button
$btnTray.Text = "Hide to tray"
$btnTray.Location = '145,115'; $btnTray.Size = '120,32'

$form.Controls.AddRange(@($lblInterval, $numInterval, $lblPixels, $numPixels, $status, $btn, $btnTray, $hint))

$timer = New-Object System.Windows.Forms.Timer

$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Icon = [System.Drawing.SystemIcons]::Application
$tray.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miToggle = $menu.Items.Add("Stop")
$miShow   = $menu.Items.Add("Show window")
$miExit   = $menu.Items.Add("Exit")
$tray.ContextMenuStrip = $menu

$script:running = $false
$script:count = 0

function Set-Running([bool]$on) {
    $script:running = $on
    if ($on) {
        $timer.Interval = [int]$numInterval.Value * 1000
        $timer.Start()
        [Jiggle]::KeepAwake($true)
        $btn.Text = "Stop"; $miToggle.Text = "Stop"
        $status.Text = "Running - screen will stay awake"
        $status.ForeColor = 'DarkGreen'
        $tray.Text = "Mouse Jiggler: running"
    } else {
        $timer.Stop()
        [Jiggle]::KeepAwake($false)
        $btn.Text = "Start"; $miToggle.Text = "Start"
        $status.Text = "Stopped"
        $status.ForeColor = 'DarkRed'
        $tray.Text = "Mouse Jiggler: stopped"
    }
}

$timer.Add_Tick({
    [Jiggle]::Nudge([int]$numPixels.Value)
    $script:count++
    $status.Text = "Running - jiggled $($script:count)x, last at $(Get-Date -Format HH:mm:ss)"
})
# Esc anywhere stops jiggling (checked every 100 ms).
$escTimer = New-Object System.Windows.Forms.Timer
$escTimer.Interval = 100
$escTimer.Add_Tick({
    if ($script:running -and [Jiggle]::EscPressed()) {
        Set-Running $false
        $status.Text = "Stopped by Esc - click Start to resume"
        $tray.ShowBalloonTip(2000, "Mouse Jiggler", "Stopped (Esc pressed).", 'Info')
    }
})
$escTimer.Start()

$numInterval.Add_ValueChanged({ $timer.Interval = [int]$numInterval.Value * 1000 })

$btn.Add_Click({ Set-Running (-not $script:running) })
$miToggle.Add_Click({ Set-Running (-not $script:running) })

$showForm = { $form.Show(); $form.WindowState = 'Normal'; $form.Activate() }
$btnTray.Add_Click({
    $form.Hide()
    $tray.ShowBalloonTip(2000, "Mouse Jiggler", "Still running. Right-click the tray icon for options.", 'Info')
})
$miShow.Add_Click($showForm)
$tray.Add_DoubleClick($showForm)
$miExit.Add_Click({ $form.Close() })

$form.Add_FormClosed({
    $timer.Stop()
    $escTimer.Stop()
    [Jiggle]::KeepAwake($false)
    $tray.Visible = $false
    $tray.Dispose()
})

Set-Running $true
[System.Windows.Forms.Application]::Run($form)
