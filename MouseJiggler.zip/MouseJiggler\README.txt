MOUSE JIGGLER - keeps the screen awake
=======================================

FIRST: extract (unzip) the whole folder. Do not run the files from inside the zip.
  Right-click MouseJiggler.zip > Extract All... > Extract

START
  Double-click "Start Mouse Jiggler.bat"
  A small "Mouse Jiggler" window opens and starts immediately.
  Every 30 seconds the mouse moves 1 pixel and returns to the same spot.
  Interval and move distance can be changed in the window.

STOP (any of these)
  1. Press Esc anywhere                  -> stops moving (click Start to resume)
  2. Click "Stop" in the window          -> stops moving (click Start to resume)
  3. Close the window (X)                -> exits completely
  4. Tray icon (bottom-right, near clock, may be under the ^ arrow)
     right-click > Stop / Exit
  5. Double-click "Stop Mouse Jiggler.bat" -> force-stops it, always works

Once stopped, Windows goes back to its normal screen-off/lock settings.
Nothing is installed and it does not start automatically after a restart.

Requirements: Windows 10/11 (uses built-in PowerShell, nothing to install).
