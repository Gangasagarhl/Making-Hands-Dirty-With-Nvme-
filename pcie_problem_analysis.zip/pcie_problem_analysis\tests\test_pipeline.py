"""End-to-end validation: generate a synthetic pex->CSV export with known injected faults, run the full pipeline
with the mock LLM provider, and assert that every injected fault is found with packet-level evidence near its
injection point. Run:  pytest -q tests
"""
import json
import os
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from backend.analyzer.llm_pipeline import run_job  # noqa: E402
from backend.config import AnalysisConfig, LLMConfig  # noqa: E402

EXPECT = {  # injected fault id -> finding kinds that must have evidence within TOLERANCE packets of the injection
    "F1": ["lcrc_error"], "F2": ["replay_timer_timeout"], "F3": ["completion_timeout"], "F4": ["unsupported_request"],
    "F5": ["malformed_tlp"], "F6": ["poisoned_tlp"], "F7": ["flow_control_stall"], "F8": ["l1_exit_latency"],
    "F9": ["slow_nvme_command"], "F10": ["receiver_error"],
}
TOLERANCE = 60


@pytest.fixture(scope="session")
def job(tmp_path_factory):
    out = tmp_path_factory.mktemp("trace")
    subprocess.run([sys.executable, os.path.join(ROOT, "stage1_research", "generate_synthetic_trace.py"),
                    "--out", str(out), "--rows", "80000"], check=True)
    job_dir = out / "job"
    job_dir.mkdir()
    cfg = LLMConfig()
    cfg.provider = "mock"
    res = run_job(str(job_dir), {"trace": str(out / "pcie_trace_export.csv")}, cfg, AnalysisConfig())
    assert res["ok"], res
    with open(out / "injected_faults.json", encoding="utf-8") as f:
        truth = json.load(f)
    with open(job_dir / "findings_trace.json", encoding="utf-8") as f:
        findings = json.load(f)
    with open(job_dir / "deterministic_trace.json", encoding="utf-8") as f:
        det = json.load(f)
    return {"dir": job_dir, "truth": truth, "findings": findings, "det": det}


def test_schema_fully_mapped(job):
    assert job["det"]["schema_missing"] == [], job["det"]["schema_missing"]
    assert job["det"]["header_columns"] == 112


@pytest.mark.parametrize("fault_id", list(EXPECT))
def test_injected_fault_is_found(job, fault_id):
    truth = next(f for f in job["truth"]["faults"] if f["id"] == fault_id)
    pk0 = truth["first_packet"]
    hits = [f for f in job["findings"] if f["kind"] in EXPECT[fault_id]]
    assert hits, f"{fault_id} ({truth['name']}) at packet {pk0}: no finding of kind {EXPECT[fault_id]}; present: {sorted({f['kind'] for f in job['findings']})}"
    assert any(abs(p - pk0) <= TOLERANCE for f in hits for p in f["evidence_packets"]), \
        f"{fault_id}: evidence {[f['evidence_packets'][:6] for f in hits]} not within {TOLERANCE} of {pk0}"


def test_nvme_decoded_from_raw_tlps(job):
    nv = job["det"]["nvme"]
    assert nv["bar0"] == "0xF0000000"
    assert nv["completed_commands"] > 500
    assert {"Read", "Write", "Flush"} <= set(nv["commands_by_opcode"])
    assert nv["latency_by_opcode_us"]["Read"]["median_us"] < 200


def test_no_false_positives(job):
    slow = [f for f in job["findings"] if f["kind"] == "slow_nvme_command"]
    assert len(slow) <= 2, [f["title"] for f in slow]
    errs = job["det"]["counts"]["errors"]
    assert errs.get("unexpected_completion", 0) == 0
    assert errs.get("lcrc_error", 0) <= 3           # F1 + F10 only
    assert errs.get("flow_control_stall", 0) <= 2


def test_l1_finding_names_the_command_and_xy(job):
    f = next(f for f in job["findings"] if f["kind"] == "l1_exit_latency")
    assert f["affected_command"].get("cid") is not None, f
    assert f["timing"].get("l1_exit_wait_before_doorbell_us", 0) > 20


def test_slow_command_attributed_to_device_phase(job):
    f = next(f for f in job["findings"] if f["kind"] == "slow_nvme_command")
    assert f["timing"]["slow_phase"].startswith("last_data_to_cqe")
    assert f["timing"]["extra_us"] > 10000


def test_artifacts_and_budget(job):
    d = job["dir"]
    for name in ("report.html", "root_causes.json", "test_cases.json", "window_analyses.json",
                 os.path.join("testcases", "test_pcie_regressions.py"), os.path.join("testcases", "analyzer_triggers.md")):
        assert (d / name).exists(), name
    with open(d / "windows_trace.json", encoding="utf-8") as f:
        windows = json.load(f)
    budget = LLMConfig().evidence_budget_tokens(2200)
    assert windows and all(w["tokens"] <= budget for w in windows), [(w["finding_id"], w["tokens"]) for w in windows]
    assert job["det"]["segments"], "segment timeline missing"
