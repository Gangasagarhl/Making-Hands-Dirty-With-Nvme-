#!/usr/bin/env bash
# Install, verify and run the PCIe/NVMe trace analysis on one Teledyne CSV export (Linux/macOS).
#   BASE_URL=https://.../v1 API_KEY=sk-... MODEL=qwen-plus ./setup_and_run.sh /path/export.csv
#   ./setup_and_run.sh /path/export.csv            # URL/key/model taken from .env (copy .env.example to .env)
#   SERVE=1 ./setup_and_run.sh /path/export.csv    # also start the UI on port 8000
set -euo pipefail
cd "$(dirname "$0")"
CSV="${1:?usage: $0 <csv path>}"
PROVIDER="${PROVIDER:-}"; BASE_URL="${BASE_URL:-}"; API_KEY="${API_KEY:-}"; MODEL="${MODEL:-}"
CONTEXT_TOKENS="${CONTEXT_TOKENS:-28000}"; MAX_WINDOWS="${MAX_WINDOWS:-20}"; SKIP_TESTS="${SKIP_TESTS:-0}"; SERVE="${SERVE:-0}"; PORT="${PORT:-8000}"
ENVIRONMENT="${ENVIRONMENT:-Linux 6.x host, nvme-cli, fio, setpci; DUT NVMe SSD /dev/nvme0 Gen4 x4 behind a Teledyne Summit interposer; PCIe Protocol Analysis 13.28.b.15}"
[ -f "$CSV" ] || { echo "CSV not found: $CSV"; exit 1; }

echo "== 1/4 Python environment"
[ -d .venv ] || python3 -m venv .venv
PY=.venv/bin/python
$PY -m pip install -q -r requirements.txt
$PY -c "import fastapi, pandas, uvicorn, requests; print('deps ok')"

if [ "$SKIP_TESTS" != "1" ]; then
  echo "== 2/4 Self-test (synthetic export with 10 known faults)"
  $PY -m pytest -q tests || { echo "self-test failed - see AGENT_INSTRUCTIONS.md section 6"; exit 1; }
fi

if [ -n "$BASE_URL" ] && [ -n "$API_KEY" ] && [ ! -f .env ]; then
  printf 'LLM_BASE_URL=%s\nLLM_API_KEY=%s\nLLM_MODEL=%s\nLLM_CONTEXT_TOKENS=%s\n' "$BASE_URL" "$API_KEY" "$MODEL" "$CONTEXT_TOKENS" > .env
  echo "   wrote .env with the API settings"
fi
echo "== 3/4 Analysis of $CSV (provider: ${PROVIDER:-auto from URL/key})"
ARGS=(run_cli.py --trace "$CSV" --max-windows "$MAX_WINDOWS" --context-tokens "$CONTEXT_TOKENS" --environment "$ENVIRONMENT")
[ -n "$PROVIDER" ] && ARGS+=(--provider "$PROVIDER")
[ -n "$BASE_URL" ] && ARGS+=(--base-url "$BASE_URL")
[ -n "$API_KEY" ] && ARGS+=(--api-key "$API_KEY")
[ -n "$MODEL" ] && ARGS+=(--model "$MODEL")
$PY "${ARGS[@]}"

JOB=$(ls -td data/jobs/*/ | head -n 1)
echo "== 4/4 Done. Outputs in $JOB"
echo "   report:      ${JOB}report.html"
echo "   root causes: ${JOB}root_causes.json"
echo "   test cases:  ${JOB}testcases/"
$PY - "$JOB" <<'EOF'
import json, sys
d = json.load(open(sys.argv[1] + "deterministic_trace.json"))
print(f"   schema_missing: {d['schema_missing'] or 'none'}   nvme.bar0: {d['nvme']['bar0']}   commands: {d['nvme']['completed_commands']}   duration_s: {d['duration_s']}")
EOF

if [ "$SERVE" = "1" ]; then
  echo "Starting UI on http://127.0.0.1:$PORT (Ctrl+C to stop)"
  $PY run_server.py --host 0.0.0.0 --port "$PORT"
fi
