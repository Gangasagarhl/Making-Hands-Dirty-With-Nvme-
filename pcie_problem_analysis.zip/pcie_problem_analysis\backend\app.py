"""FastAPI server: upload the two Teledyne CSV exports (or point at files already on disk for multi-GB
traces), run the Stage 2 pipeline in a background thread, poll progress, fetch the Stage 3 report and the
generated test cases.

    python -m uvicorn backend.app:app --host 0.0.0.0 --port 8000
    (or)  python run_server.py
"""
from __future__ import annotations

import io
import json
import os
import shutil
import threading
import time
import uuid
import zipfile
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .analyzer.llm_pipeline import clean_nan, run_job
from .config import JOBS_DIR, AnalysisConfig, LLMConfig


def _load_json(path: str):
    with open(path, encoding="utf-8") as f:
        return clean_nan(json.load(f))

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND = os.path.join(ROOT, "frontend")
os.makedirs(JOBS_DIR, exist_ok=True)

app = FastAPI(title="PCIe / NVMe trace analysis", version="1.0")
_jobs: dict[str, dict] = {}


def _job_dir(job_id: str) -> str:
    d = os.path.join(JOBS_DIR, job_id)
    if not os.path.isdir(d):
        raise HTTPException(404, "job not found")
    return d


def _llm_cfg_from_form(provider, base_url, api_key, model, context_tokens, max_output_tokens) -> LLMConfig:
    cfg = LLMConfig()
    if provider:
        cfg.provider = provider
    if base_url:
        cfg.base_url = base_url
    if api_key:
        cfg.api_key = api_key
    if model:
        cfg.model = model
    if context_tokens:
        cfg.context_tokens = int(context_tokens)
    if max_output_tokens:
        cfg.max_output_tokens = int(max_output_tokens)
    return cfg.normalize()


def _start(job_id: str, job_dir: str, inputs: dict, llm_cfg: LLMConfig, acfg: AnalysisConfig, environment: str):
    def target():
        run_job(job_dir, inputs, llm_cfg, acfg, environment)
    t = threading.Thread(target=target, daemon=True, name=f"job-{job_id}")
    _jobs[job_id] = {"thread": t, "created": time.time(), "inputs": {k: os.path.basename(v) for k, v in inputs.items() if v}}
    t.start()


async def _save_upload(up: UploadFile, dest: str):
    with open(dest, "wb") as f:
        while True:
            chunk = await up.read(8 * 1024 * 1024)
            if not chunk:
                break
            f.write(chunk)


@app.post("/api/jobs")
async def create_job(
    trace: Optional[UploadFile] = File(None),
    trace_path: Optional[str] = Form(None),
    all_speeds: Optional[UploadFile] = File(None),
    gen4_x4: Optional[UploadFile] = File(None),
    all_speeds_path: Optional[str] = Form(None),
    gen4_x4_path: Optional[str] = Form(None),
    provider: Optional[str] = Form(None),
    base_url: Optional[str] = Form(None),
    api_key: Optional[str] = Form(None),
    model: Optional[str] = Form(None),
    context_tokens: Optional[int] = Form(None),
    max_output_tokens: Optional[int] = Form(None),
    max_llm_windows: Optional[int] = Form(None),
    environment: Optional[str] = Form(""),
):
    job_id = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
    job_dir = os.path.join(JOBS_DIR, job_id)
    os.makedirs(os.path.join(job_dir, "input"), exist_ok=True)
    inputs = {}
    for label, up, path in (("trace", trace, trace_path), ("all_speeds", all_speeds, all_speeds_path), ("gen4_x4", gen4_x4, gen4_x4_path)):
        if up is not None and up.filename:
            dest = os.path.join(job_dir, "input", f"{label}.csv")
            await _save_upload(up, dest)
            inputs[label] = dest
        elif path:
            if not os.path.isfile(path):
                raise HTTPException(400, f"{label}: file not found: {path}")
            inputs[label] = os.path.abspath(path)
    if not inputs:
        raise HTTPException(400, "provide the CSV export (upload or server-side path)")
    llm_cfg = _llm_cfg_from_form(provider, base_url, api_key, model, context_tokens, max_output_tokens)
    if llm_cfg.provider == "claude_cli" and not os.path.isfile(llm_cfg.resolve_claude_cli()) and not shutil.which("claude"):
        raise HTTPException(400, "claude CLI not found; set CLAUDE_CLI_PATH or choose another provider")
    acfg = AnalysisConfig()
    if max_llm_windows:
        acfg.max_llm_windows = int(max_llm_windows)
    with open(os.path.join(job_dir, "job.json"), "w", encoding="utf-8") as f:
        json.dump({"id": job_id, "inputs": inputs, "llm": llm_cfg.public(), "analysis": acfg.__dict__,
                   "environment": environment}, f, indent=1)
    _start(job_id, job_dir, inputs, llm_cfg, acfg, environment or "")
    return {"job_id": job_id}


@app.get("/api/jobs")
def list_jobs():
    out = []
    for d in sorted(os.listdir(JOBS_DIR), reverse=True)[:50]:
        sp = os.path.join(JOBS_DIR, d, "status.json")
        if os.path.isfile(sp):
            st = _load_json(sp)
            out.append({"job_id": d, "status": st.get("status"), "stage": st.get("stage"), "fraction": st.get("fraction"),
                        "started": st.get("started")})
    return out


@app.get("/api/jobs/{job_id}")
def job_status(job_id: str):
    d = _job_dir(job_id)
    st = _load_json(os.path.join(d, "status.json"))
    st["job_id"] = job_id
    st["artifacts"] = sorted(x for x in os.listdir(d) if x.endswith((".json", ".html", ".txt")))
    return st


@app.get("/api/jobs/{job_id}/report", response_class=HTMLResponse)
def job_report(job_id: str):
    p = os.path.join(_job_dir(job_id), "report.html")
    if not os.path.isfile(p):
        raise HTTPException(404, "report not ready")
    return FileResponse(p, media_type="text/html")


@app.get("/api/jobs/{job_id}/artifact/{name}")
def job_artifact(job_id: str, name: str):
    if "/" in name or "\\" in name or ".." in name:
        raise HTTPException(400, "bad name")
    p = os.path.join(_job_dir(job_id), name)
    if not os.path.isfile(p):
        raise HTTPException(404, "not found")
    return FileResponse(p)


@app.get("/api/jobs/{job_id}/findings")
def job_findings(job_id: str):
    d = _job_dir(job_id)
    out = {}
    for name in os.listdir(d):
        if name.startswith("findings_") and name.endswith(".json"):
            out[name[9:-5]] = _load_json(os.path.join(d, name))
    for extra in ("root_causes.json", "test_cases.json", "comparison.json", "window_analyses.json"):
        p = os.path.join(d, extra)
        if os.path.isfile(p):
            out[extra[:-5]] = _load_json(p)
    return out


@app.get("/api/jobs/{job_id}/testcases.zip")
def job_testcases(job_id: str):
    d = os.path.join(_job_dir(job_id), "testcases")
    if not os.path.isdir(d):
        raise HTTPException(404, "test cases not ready")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name in os.listdir(d):
            z.write(os.path.join(d, name), arcname=f"testcases/{name}")
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f"attachment; filename=testcases_{job_id}.zip"})


@app.delete("/api/jobs/{job_id}")
def delete_job(job_id: str):
    d = _job_dir(job_id)
    shutil.rmtree(d, ignore_errors=True)
    return {"deleted": job_id}


@app.get("/api/config")
def get_config():
    cfg = LLMConfig().normalize()
    cli = cfg.resolve_claude_cli()
    return {"llm_defaults": cfg.public(), "analysis_defaults": AnalysisConfig().__dict__,
            "providers": ["openai", "anthropic", "claude_cli", "mock"],
            "api_configured": bool(cfg.api_key) and cfg.provider in ("openai", "anthropic"),
            "claude_cli": cli if (os.path.isfile(cli) or shutil.which(cli)) else None}


@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(FRONTEND, "index.html"), encoding="utf-8") as f:
        return f.read()


app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
