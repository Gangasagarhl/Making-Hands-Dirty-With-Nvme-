"""Maps the Teledyne LeCroy pex->CSV packet export (PCIe Protocol Analysis 13.28.b.15, 112 columns) onto the
canonical column set used by the analyzer. Header names are matched case-insensitively with aliases, so
small spelling differences in a real export are tolerated; the mapping chosen is logged per job
(deterministic_*.json -> schema_mapping) and unmapped canonical names are listed under schema_missing."""
from __future__ import annotations

import re
from typing import Iterable

import numpy as np
import pandas as pd

COLUMN_ALIASES: dict[str, list[str]] = {
    "marker":   ["marker"],
    "pkt":      ["packet", "packet #", "packet number", "pkt", "#"],
    "link":     ["link"],
    "dir":      ["direction", "dir"],
    "os_type":  ["ordered set type", "ordered set", "os type"],
    "dllp_type": ["dllp type", "dll type", "dllp"],
    "tlp_type": ["tlp type", "tlp"],
    "link_event": ["link event", "event"],
    "psn":      ["psn", "sequence number", "seq num", "tlp sequence number"],
    "acknak":   ["ack/nak sequence number", "ack/nak seq number", "acknak sequence number", "ack nak sequence number", "ack/nak seq"],
    "vcid":     ["vc id", "vcid"],
    "hdrscale": ["hdrscale", "hdr scale"],
    "hdrfc":    ["hdrfc", "hdr fc"],
    "datascale": ["datascale", "data scale"],
    "datafc":   ["datafc", "data fc"],
    "tc":       ["tc", "traffic class"],
    "td":       ["td"],
    "ep":       ["ep", "poisoned"],
    "attr":     ["attributes", "attr"],
    "at":       ["at"],
    "length":   ["length", "len", "length (dw)"],
    "req":      ["requester id", "requester", "req id"],
    "tag":      ["tag"],
    "cpl":      ["completer id", "completer"],
    "addr":     ["address", "addr"],
    "devid":    ["device id"],          # first occurrence (TLP Cfg target); the UDID one is ignored
    "register": ["register", "reg"],
    "first_be": ["first be", "1st be"],
    "last_be":  ["last be"],
    "status":   ["cpl status", "completion status", "cpl stat", "status"],
    "bcount":   ["byte cnt", "byte count (tlp)", "bytecount", "byte cnt."],
    "bcm":      ["bcm"],
    "lwr_addr": ["lwr addr", "lower address"],
    "msg_routing": ["msg routing"],
    "msg_code": ["message code", "msg code"],
    "ts_link":  ["ts link"],
    "ts_lane":  ["ts lane"],
    "n_fts":    ["n_fts", "n fts"],
    "train_ctl": ["training_control", "training control"],
    "ts_rate":  ["ts_data rate", "ts data rate", "data rate", "ts_datarate"],
    "ts_eq":    ["ts gen3 eq control", "eq control"],
    "lcrc":     ["lcrc"],
    "ecrc":     ["ecrc"],
    "crc16":    ["crc16", "crc 16"],
    "data":     ["data", "payload", "data payload"],
    "delta":    ["time delta", "delta time", "delta"],
    "time":     ["time stamp", "timestamp", "time"],
}
CANONICAL = list(COLUMN_ALIASES.keys())
NUMERIC = ("psn", "acknak", "hdrfc", "datafc", "length", "tag", "bcount", "ep", "td")


def _norm(s) -> str:
    return re.sub(r"\s+", " ", str(s).strip().lower())


def detect_mapping(header: Iterable[str]) -> dict[str, str]:
    header = list(header)
    normed: dict[str, str] = {}
    for h in header:
        normed.setdefault(_norm(h), h)     # first occurrence wins (Device ID)
    mapping: dict[str, str] = {}
    used: set[str] = set()
    for canon, aliases in COLUMN_ALIASES.items():
        for a in aliases:
            if a in normed and normed[a] not in used:
                mapping[canon] = normed[a]
                used.add(normed[a])
                break
    return mapping


def missing(mapping: dict[str, str]) -> list[str]:
    return [c for c in CANONICAL if c not in mapping]


def parse_time_to_seconds(series: pd.Series) -> np.ndarray:
    """'12.345678901', '12.345678901 s', '0.000 012 345 678', '12345678 ns', '12,345.678 us'."""
    s = series.astype(str)
    out = pd.to_numeric(s, errors="coerce")
    if out.notna().mean() > 0.98:
        return out.to_numpy(dtype="float64")
    st = s.str.strip()
    ns_mask = st.str.endswith("ns")
    us_mask = st.str.endswith("us") | st.str.endswith("µs")
    ms_mask = st.str.endswith("ms")
    cleaned = st.str.replace(r"[a-zA-Zµ]", "", regex=True).str.replace(r"[\s,]", "", regex=True)
    vals = pd.to_numeric(cleaned, errors="coerce").to_numpy(dtype="float64")
    vals[ns_mask.to_numpy()] /= 1e9
    vals[us_mask.to_numpy()] /= 1e6
    vals[ms_mask.to_numpy()] /= 1e3
    return vals


def normalize_chunk(df: pd.DataFrame, mapping: dict[str, str]) -> pd.DataFrame:
    """Return a frame with canonical columns (strings, '' for missing) plus parsed numeric helpers."""
    out = pd.DataFrame(index=df.index)
    for c in CANONICAL:
        src = mapping.get(c)
        out[c] = df[src].fillna("").astype(str) if src in df.columns else ""
    out["pkt_n"] = pd.to_numeric(out["pkt"], errors="coerce").fillna(-1).astype("int64")
    out["t_s"] = parse_time_to_seconds(out["time"])
    for c in NUMERIC:
        out[c + "_n"] = pd.to_numeric(out[c].str.replace(r"^0x", "", regex=True) if c in ("tag",) else out[c],
                                      errors="coerce").fillna(-1).astype("int64")
    # one packet-type string and a coarse class for every row
    tlp, dllp, ost, ev = out["tlp_type"], out["dllp_type"], out["os_type"], out["link_event"]
    out["ptype"] = tlp.where(tlp != "", dllp.where(dllp != "", ost.where(ost != "", ev)))
    cls = np.full(len(out), "OTHER", dtype=object)
    cls[(ev != "").to_numpy()] = "EVENT"
    cls[(ost != "").to_numpy()] = "OS"
    cls[(dllp != "").to_numpy()] = "DLLP"
    cls[(tlp != "").to_numpy()] = "TLP"
    out["cls"] = cls
    return out


def parse_hex_int(s: str) -> int:
    try:
        s = s.strip()
        return int(s, 16) if s.lower().startswith("0x") else int(s, 0)
    except Exception:
        return -1


def data_bytes(s: str) -> bytes:
    """'07 00 00 00' / '07000000' / '0x07 0x00' -> bytes (best effort)."""
    if not s:
        return b""
    toks = re.findall(r"[0-9A-Fa-f]{2}", s.replace("0x", " "))
    try:
        return bytes(int(t, 16) for t in toks)
    except Exception:
        return b""


def compact_row(r) -> str:
    """Token-cheap one-line rendering of a canonical row for an LLM evidence window."""
    d = "Dn" if r.dir.lower().startswith("down") else ("Up" if r.dir.lower().startswith("up") else r.dir[:4])
    parts = [f"#{r.pkt}", f"t={r.t_s:.9f}" if r.t_s == r.t_s else "t=?", d, r.cls, r.ptype]
    kv = (("psn", r.psn), ("ackseq", r.acknak), ("req", r.req), ("cpl", r.cpl), ("tag", r.tag), ("addr", r.addr), ("reg", r.register),
          ("len", r.length), ("bc", r.bcount), ("st", r.status), ("EP", r.ep if r.ep not in ("", "0") else ""),
          ("hdrfc", r.hdrfc), ("datafc", r.datafc), ("rate", r.ts_rate), ("lanes", r.ts_lane))
    for k, v in kv:
        if v not in ("", None):
            parts.append(f"{k}={v}")
    if "bad" in r.lcrc.lower():
        parts.append("LCRC=BAD")
    if "bad" in r.ecrc.lower():
        parts.append("ECRC=BAD")
    if r.data:
        parts.append("data=" + r.data[:47].rstrip() + ("…" if len(r.data) > 47 else ""))
    return " ".join(parts)
