# Project: PCIe / NVMe trace problem analysis

Read `AGENT_INSTRUCTIONS.md` first and follow it step by step. Summary for the agent:

1. `cp .env.example .env` and fill in the three values given by the user: `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`
   (OpenAI-compatible chat-completions endpoint; an Anthropic URL is auto-detected). No CLI is needed.
2. `pip install -r requirements.txt` (venv recommended).
3. `python -m pytest -q tests` must print `16 passed` before anything else.
4. Run on the user's CSV: `python run_cli.py --trace "<CSV PATH>"` (URL/key/model come from .env), or
   `setup_and_run.ps1 -Csv "<CSV PATH>"` / `./setup_and_run.sh "<CSV PATH>"` which does steps 2-4 in one go.
   UI: `python run_server.py --port 8000`, paste the CSV path, click Analyze.
5. Deliver `data/jobs/<job>/report.html`, the executive summary and root causes from `root_causes.json`,
   and `data/jobs/<job>/testcases/` (reproduction scripts per root cause).
6. On a first real export check `deterministic_trace.json -> schema_missing / nvme.bar0 / duration_s`
   and apply only the fixes listed in AGENT_INSTRUCTIONS.md section 6.

Do not send the CSV to any LLM directly; the pipeline already extracts token-budgeted evidence windows.
Do not change detection thresholds or prompts unless the user asks.
