"""Stage 3 - self-contained HTML report for one job (no external assets, works offline)."""
from __future__ import annotations

import html
import json
import math
import time

SEV_COLOR = {5: "#b3261e", 4: "#d9480f", 3: "#b7791f", 2: "#2b6cb0", 1: "#4a5568"}
SEV_NAME = {5: "critical", 4: "high", 3: "medium", 2: "low", 1: "info"}

CSS = """
:root{--bg:#f7f8fa;--card:#fff;--ink:#1a202c;--muted:#5a6473;--line:#e2e6ec;--accent:#1f5fbf}
@media (prefers-color-scheme: dark){:root{--bg:#0f1318;--card:#171c23;--ink:#e6e9ee;--muted:#9aa5b4;--line:#2a323d;--accent:#6ea3ff}}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:1180px;margin:0 auto;padding:24px 16px}
h1{font-size:26px;margin:0 0 4px}h2{font-size:20px;margin:36px 0 12px;border-bottom:1px solid var(--line);padding-bottom:6px}
h3{font-size:16px;margin:18px 0 6px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px 18px;margin:12px 0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.kpi b{display:block;font-size:22px}.kpi span{color:var(--muted);font-size:13px}
table{width:100%;border-collapse:collapse;font-size:13.5px}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--muted);font-weight:600}
.sev{display:inline-block;padding:1px 8px;border-radius:999px;color:#fff;font-size:12px;font-weight:600}
code,pre{font:12.5px/1.45 ui-monospace,Consolas,monospace}pre{background:rgba(127,127,127,.08);padding:10px;border-radius:8px;overflow:auto;max-height:420px}
.muted{color:var(--muted)}.pk{color:var(--accent);font-weight:600}
details summary{cursor:pointer;font-weight:600}
svg text{fill:var(--ink)}
.tl{display:flex;gap:4px;flex-wrap:wrap}.tl span{font-size:12px;padding:2px 6px;border-radius:6px;background:rgba(127,127,127,.12)}
"""


def esc(x) -> str:
    return html.escape(str(x))


def kpi(label, value):
    return f'<div class="kpi"><b>{esc(value)}</b><span>{esc(label)}</span></div>'


def sev_badge(s: int):
    return f'<span class="sev" style="background:{SEV_COLOR.get(s, "#555")}">{SEV_NAME.get(s, s)}</span>'


def timeline_svg(det: dict, findings, width=1100, height=150) -> str:
    t0, t1 = det.get("t_first_s", 0) or 0, det.get("t_last_s", 0) or 0
    if not (t1 > t0):
        return ""
    def x(t):
        return 40 + (t - t0) / (t1 - t0) * (width - 60)
    rows = [f'<svg viewBox="0 0 {width} {height}" width="100%" role="img" aria-label="anomaly timeline">',
            f'<line x1="40" y1="{height - 30}" x2="{width - 20}" y2="{height - 30}" stroke="#888"/>']
    for i in range(6):
        t = t0 + (t1 - t0) * i / 5
        rows.append(f'<text x="{x(t):.0f}" y="{height - 12}" font-size="11" text-anchor="middle">{t:.4f}s</text>')
    # speed/width bands from link events
    for ev in det.get("link_events", []):
        if "Speed" in ev.get("type", ""):
            rows.append(f'<line x1="{x(ev["t_s"]):.1f}" y1="20" x2="{x(ev["t_s"]):.1f}" y2="{height - 30}" stroke="#2b6cb0" stroke-dasharray="3 3"/>')
            rows.append(f'<text x="{x(ev["t_s"]) + 3:.1f}" y="30" font-size="10">{esc(ev["text"][:28])}</text>')
    for f in findings:
        if f.t_first_s != f.t_first_s:
            continue
        cx = x(f.t_first_s)
        cy = height - 30 - 12 * f.severity
        rows.append(f'<circle cx="{cx:.1f}" cy="{cy}" r="6" fill="{SEV_COLOR[f.severity]}"><title>{esc(f.id)} {esc(f.title)}</title></circle>')
        rows.append(f'<text x="{cx:.1f}" y="{cy - 9}" font-size="10" text-anchor="middle">{esc(f.id)}</text>')
    rows.append("</svg>")
    return "".join(rows)


def latency_bars(lat_by_opc: dict) -> str:
    if not lat_by_opc:
        return '<p class="muted">No NVMe decode columns found in this export; command-level latency unavailable.</p>'
    mx = max((v.get("p99_us", 0) or 0) for v in lat_by_opc.values()) or 1
    out = ['<table><tr><th>opcode</th><th>n</th><th>median us</th><th>p95 us</th><th>p99 us</th><th>max us</th><th></th></tr>']
    for k, v in lat_by_opc.items():
        if v.get("n", 0) == 0:
            continue
        w_med = 100 * (v["median_us"] / mx)
        w_p99 = 100 * (v["p99_us"] / mx)
        bar = (f'<svg width="100%" height="14" viewBox="0 0 100 14" preserveAspectRatio="none">'
               f'<rect x="0" y="2" width="{w_p99:.1f}" height="10" fill="#d9480f55"/>'
               f'<rect x="0" y="2" width="{w_med:.1f}" height="10" fill="#1f5fbf"/></svg>')
        out.append(f'<tr><td>{esc(k)}</td><td>{v["n"]}</td><td>{v["median_us"]}</td><td>{v["p95_us"]}</td><td>{v["p99_us"]}</td><td>{v["max_us"]}</td><td style="width:30%">{bar}</td></tr>')
    out.append("</table><p class='muted'>blue = median (X), orange = p99 (X+Y)</p>")
    return "".join(out)


def render(job_dir, files: dict, comparison: dict, analyses: list, root: dict, test_cases: list, client, llm_cfg) -> str:
    a_by_id = {a.get("finding_id"): a for a in analyses}
    parts = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
             f"<title>PCIe Trace Analysis</title><style>{CSS}</style></head><body><main>",
             "<h1>PCIe / NVMe trace analysis report</h1>",
             f"<p class='muted'>Generated {time.strftime('%Y-%m-%d %H:%M:%S')} · inputs: {esc(', '.join(files.keys()))} · "
             f"LLM: {esc(llm_cfg.provider)} / {esc(llm_cfg.model)} · {client.calls} calls, {client.prompt_tokens:,} prompt tokens</p>"]

    # ---------------- executive summary
    parts.append("<h2>1. What is wrong (executive summary)</h2><div class='card'>")
    parts.append(f"<p>{esc(root.get('executive_summary') or 'No LLM summary (mock provider or LLM failure); see root causes below.')}</p>")
    if root.get("open_questions"):
        parts.append("<p class='muted'>Open questions: " + "; ".join(esc(q) for q in root["open_questions"]) + "</p>")
    parts.append("</div>")

    # ---------------- KPIs per file
    for label, fd in files.items():
        det = fd["det"]
        nv = det["nvme"]
        parts.append(f"<h2>2. Trace profile: {esc(label)}</h2><div class='grid'>")
        parts.append(kpi("rows (packets)", f"{det['rows']:,}"))
        parts.append(kpi("duration", f"{det['duration_s']:.4f} s"))
        parts.append(kpi("error flags", f"{sum(det['counts']['errors'].values()):,}"))
        parts.append(kpi("NVMe commands completed", f"{nv['completed_commands']:,}"))
        cl = det["completion_latency_us"]
        parts.append(kpi("completion latency median / p99 (us)", f"{cl.get('median_us', '-')} / {cl.get('p99_us', '-')}"))
        parts.append(kpi("Ack latency p99 (us)", det["ack_latency_us"].get("p99_us", "-")))
        parts.append(kpi("max UpdateFC gap (us)", max(det["max_updatefc_gap_us"].values() or [0])))
        parts.append(kpi("L1 cycles", len(det["pm_l1_intervals"])))
        parts.append("</div>")
        parts.append("<div class='card'><h3>Link speed / width residency (from TS data rate, TS lanes and Link Event rows)</h3><table><tr><th>speed | width</th><th>time (s)</th></tr>")
        for k, v in sorted(det["speed_width"]["time_s"].items(), key=lambda kv: -kv[1]):
            parts.append(f"<tr><td>{esc(k)}</td><td>{v:.6f}</td></tr>")
        parts.append("</table></div>")
        parts.append("<div class='card'><h3>Anomaly classes detected from raw packets (no Errors column in the export)</h3>")
        if det["counts"]["errors"]:
            parts.append("<table><tr><th>error</th><th>count</th><th>first packets</th></tr>")
            for k, v in det["counts"]["errors"].items():
                ex = ", ".join(f"<span class='pk'>#{p}</span>" for p in det["error_examples"].get(k, [])[:8])
                parts.append(f"<tr><td>{esc(k)}</td><td>{v}</td><td>{ex}</td></tr>")
            parts.append("</table>")
        else:
            parts.append("<p class='muted'>none</p>")
        parts.append("</div>")
        parts.append("<div class='card'><h3>NVMe command latency by opcode (X = median, X+Y = p99)</h3>" + latency_bars(nv["latency_by_opcode_us"]) + "</div>")
        parts.append("<div class='card'><h3>Anomaly timeline</h3>" + timeline_svg(det, fd["findings"]) + "</div>")
        parts.append("<div class='card'><h3>Packet mix</h3><div class='tl'>" + "".join(
            f"<span>{esc(k)} {v:,}</span>" for k, v in list(det["counts"]["by_packet_type"].items())[:30]) + "</div></div>")

    # ---------------- link state profile / comparison
    if comparison.get("interpretation"):
        parts.append("<h2>3. Link state profile (derived from training sets and link events)</h2><div class='card'>")
        parts.append(f"<p>{esc(comparison['interpretation'])}</p>")
        if comparison.get("residency_pct"):
            parts.append("<p>Residency %: " + esc(json.dumps(comparison["residency_pct"])) + "</p>")
        if comparison.get("speed_changes"):
            parts.append("<p>Speed changes: " + "; ".join(f"<span class='pk'>#{e['pkt']}</span> {esc(e['text'])}" for e in comparison["speed_changes"][:10]) + "</p>")
        if comparison.get("interpretation_two_files"):
            parts.append(f"<p>{esc(comparison['interpretation_two_files'])}</p>")
        parts.append("</div>")
    for label, fd in files.items():
        det = fd["det"]
        if det.get("config_space"):
            parts.append(f"<div class='card'><h3>Configuration-space traffic seen in the trace ({esc(label)})</h3><table><tr><th>pkt</th><th>type</th><th>register</th><th>tag</th><th>data</th><th>status</th></tr>")
            for c in det["config_space"][:40]:
                parts.append(f"<tr><td class='pk'>#{c['pkt']}</td><td>{esc(c.get('type'))}</td><td>{esc(c.get('register', ''))}</td><td>{esc(c.get('tag'))}</td><td><code>{esc(c.get('data', ''))}</code></td><td>{esc(c.get('status', ''))}</td></tr>")
            parts.append("</table><p class='muted'>NVMe BAR0 learned from CfgWr0 register 0x10: " + esc(det['nvme'].get('bar0')) + "</p></div>")
        segs = det.get("segments") or []
        if segs:
            parts.append(f"<div class='card'><h3>Segment timeline ({esc(label)}; one row per {segs[0]['rows']:,}-packet segment)</h3><table>"
                         "<tr><th>seg</th><th>packets</th><th>t (s)</th><th>speed</th><th>TLPs</th><th>Nak</th><th>replay</th><th>bad LCRC</th><th>anomalies</th><th>NVMe done</th><th>max cmd us</th><th>L1</th><th>Recovery</th><th>Cpl TO</th><th>FC stall</th></tr>")
            step = max(1, len(segs) // 60)
            for s in segs[::step]:
                parts.append(f"<tr><td>{s['segment']}</td><td>#{s['first_pkt']:,}-#{s['last_pkt']:,}</td><td>{(s.get('t_start') or 0):.4f}-{(s.get('t_end') or 0):.4f}</td><td>{esc(s.get('speed'))}</td>"
                             f"<td>{s['tlps']:,}</td><td>{s['naks']}</td><td>{s['replays']}</td><td>{s['bad_lcrc']}</td><td>{s['errors']}</td><td>{s['nvme_completed']:,}</td><td>{s['max_cmd_latency_us']:.0f}</td>"
                             f"<td>{s['l1_entries']}</td><td>{s['recovery']}</td><td>{s['cpl_timeouts']}</td><td>{s['fc_stalls']}</td></tr>")
            parts.append("</table></div>")

    # ---------------- root causes
    parts.append("<h2>4. Root causes (LLM reduce over all windows)</h2>")
    for rc in root.get("root_causes", []):
        parts.append("<div class='card'>")
        parts.append(f"<h3>{esc(rc.get('id'))} · {esc(rc.get('title'))} <span class='muted'>[{esc(rc.get('severity'))} · {esc(rc.get('layer'))} · side: {esc(rc.get('responsible_side'))}]</span></h3>")
        parts.append(f"<p>{esc(rc.get('explanation'))}</p>")
        if rc.get("latency_impact_us") is not None:
            parts.append(f"<p>Latency impact: <b>{esc(rc.get('latency_impact_us'))} us</b></p>")
        parts.append(f"<p><b>Fix:</b> {esc(rc.get('fix'))}</p>")
        parts.append("<p class='muted'>findings: " + ", ".join(esc(x) for x in rc.get("finding_ids", [])) +
                     " · packets: " + ", ".join(f"<span class='pk'>#{p}</span>" for p in (rc.get("evidence_packets") or [])[:15]) + "</p></div>")

    # ---------------- findings detail
    parts.append("<h2>5. Findings with packet-level evidence</h2>")
    for label, fd in files.items():
        parts.append(f"<h3 class='muted'>{esc(label)}</h3>")
        for f in fd["findings"]:
            a = a_by_id.get(f.id, {})
            parts.append("<div class='card'>")
            parts.append(f"<h3>{sev_badge(f.severity)} {esc(f.id)} · {esc(f.title)} <span class='muted'>[{esc(f.layer)}]</span></h3>")
            parts.append(f"<p><b>Observed:</b> {esc(f.observed)}</p>")
            parts.append(f"<p><b>Spec expects:</b> {esc(f.expected)} <span class='muted'>({esc(f.spec_ref)})</span></p>")
            parts.append(f"<p><b>Why:</b> {esc(f.why)}</p>")
            if f.timing:
                parts.append(f"<p><b>Timing (X / X+Y / Y):</b> {esc(json.dumps(f.timing, default=str))}</p>")
            if f.affected_command:
                parts.append(f"<p><b>Affected command:</b> {esc(json.dumps(f.affected_command, default=str))}</p>")
            parts.append("<p><b>Evidence packets (CSV 'Packet' column):</b> " + ", ".join(f"<span class='pk'>#{p}</span>" for p in f.evidence_packets[:30]) + "</p>")
            parts.append(f"<p><b>Fix hypothesis:</b> {esc(f.fix_hypothesis)}</p>")
            if a:
                conf = a.get("confirmed")
                parts.append("<details><summary>LLM window analysis · confirmed=" + esc(conf) + f" · confidence {esc(a.get('confidence'))}</summary>")
                parts.append(f"<p><b>Root cause:</b> {esc(a.get('root_cause'))}</p><p><b>Mechanism:</b> {esc(a.get('mechanism'))}</p>")
                parts.append(f"<p><b>Time:</b> expected {esc(a.get('expected_time_us'))} us · observed {esc(a.get('observed_time_us'))} us · extra {esc(a.get('extra_time_us'))} us ({esc(a.get('extra_time_source'))}) · side: {esc(a.get('responsible_side'))}</p>")
                parts.append(f"<p><b>Offending packets:</b> {esc(a.get('offending_packets'))} · command {esc(json.dumps(a.get('offending_command'), default=str))}</p>")
                parts.append(f"<p><b>Fix:</b> {esc(a.get('fix'))}</p><p class='muted'>{esc(a.get('notes') or a.get('error') or '')}</p></details>")
            parts.append("</div>")

    # ---------------- slow commands table
    for label, fd in files.items():
        slow = fd["det"]["nvme"]["slow_commands"]
        if not slow:
            continue
        parts.append(f"<h2>6. Slowest NVMe commands ({esc(label)}) - which phase holds the extra time</h2><div class='card'><table>")
        parts.append("<tr><th>queue</th><th>cid</th><th>opcode</th><th>latency us</th><th>doorbell pkt</th><th>CQE pkt</th><th>bytes</th><th>phases (us)</th><th>link events before</th></tr>")
        for c in slow[:15]:
            parts.append(f"<tr><td>{esc(c['qid'])}</td><td>{esc(c['cid'])}</td><td>{esc(c['opc'])}</td><td>{c['latency_us']}</td>"
                         f"<td class='pk'>#{c['doorbell_pkt']}</td><td class='pk'>#{c['cqe_pkt']}</td><td>{c.get('bytes', c.get('data_bytes'))}</td>"
                         f"<td><code>{esc(json.dumps(c['phases_us']))}</code></td><td>{esc(c['link_events_before'])}</td></tr>")
        parts.append("</table></div>")

    # ---------------- test cases
    parts.append("<h2>7. Generated test cases (reproduce on the next build)</h2>")
    for tc in test_cases:
        parts.append("<div class='card'>")
        parts.append(f"<h3>{esc(tc.get('test_id'))} · {esc(tc.get('title'))} <span class='muted'>→ {esc(tc.get('root_cause_id'))}</span></h3>")
        parts.append(f"<p>{esc(tc.get('objective'))}</p>")
        parts.append(f"<p><b>Analyzer trigger:</b> {esc(tc.get('analyzer_trigger', {}).get('event'))}</p>")
        parts.append("<pre>" + esc("\n".join(f"{s.get('n')}. {s.get('cmd')}   # {s.get('expect', '')}" for s in tc.get("steps", []))) + "</pre>")
        parts.append("<p><b>Pass:</b> " + "; ".join(esc(p) for p in tc.get("pass_criteria", [])) + "</p>")
        parts.append(f"<p class='muted'>maps to trace packets: {esc(tc.get('maps_to_trace_packets'))} · files: testcases/{esc(tc.get('test_id'))}.sh / .json</p></div>")

    # ---------------- method
    parts.append("<h2>8. How this was produced</h2><div class='card'><ol>"
                 "<li><b>2.1</b> Streaming pass over the raw packet export (constant memory): packet mix; speed/width from TS data rate / "
                 "lanes / Link Event rows; bad LCRC/ECRC cells; Nak DLLPs; replays as re-used PSNs (with/without a preceding Nak); Ack "
                 "latency per PSN; posted flow-control credit accounting (InitFC/UpdateFC DataFC vs consumed); EP=1; Cpl Status UR/CA; "
                 "Length vs payload / Max_Payload_Size; (requester, tag) request/completion matching with Byte Count for split completions "
                 "and tag-reuse detection; NVMe reconstruction from BAR0 doorbells, the 64-byte SQE in the CplD payload and the 16-byte "
                 "CQE payload; L1/Recovery intervals; idle gaps; per-segment timeline.</li>"
                 "<li><b>2.2</b> Spec rule engine: each anomaly class is matched to the PCIe 4.0 / NVMe 2.0 expectation and turned into a finding with packet numbers.</li>"
                 f"<li><b>2.3</b> Evidence windows (±{60}/{90} rows around each anomaly) rendered compactly and trimmed to the "
                 f"{llm_cfg.context_tokens:,}-token model budget.</li>"
                 "<li><b>2.4</b> One LLM call per window: confirm/refute, mechanism, offending packets, X / X+Y / Y attribution.</li>"
                 "<li><b>2.5</b> LLM reduce (batched to fit the context) merges windows into root causes + executive summary.</li>"
                 "<li><b>2.6</b> LLM test-case generation per root cause, enriched with deterministic recipes (nvme-cli, fio, setpci, analyzer trigger).</li>"
                 "<li><b>3</b> This report. All intermediate JSON files are in the job folder.</li></ol></div>")
    parts.append("</main></body></html>")
    return "".join(parts)
