"""LLM client with four providers:
  openai     - any OpenAI-compatible /chat/completions endpoint (Qwen via DashScope compatible mode, vLLM, Ollama, ...)
  anthropic  - Claude Messages API (e.g. claude-haiku-5-5)
  claude_cli - local Claude Code CLI:  claude -p --model haiku --output-format json
  mock       - offline deterministic answers so the whole pipeline can be exercised without a key
All calls ask for a JSON object and return (parsed_json, raw_text, usage).
"""
from __future__ import annotations

import json
import re
import subprocess
import time
from typing import Any

import requests

from ..config import LLMConfig


class LLMError(RuntimeError):
    pass


def _extract_json(text: str) -> Any:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception as e:
            raise LLMError(f"model did not return valid JSON: {e}: {text[:300]}")
    raise LLMError(f"model did not return JSON: {text[:300]}")


class LLMClient:
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg.normalize()
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.log: list[dict] = []

    # ------------------------------------------------------------------ public
    def chat_json(self, system: str, user: str, *, max_tokens: int | None = None, tag: str = "") -> dict:
        max_tokens = max_tokens or self.cfg.max_output_tokens
        last_err = None
        for attempt in range(1, self.cfg.max_retries + 1):
            try:
                t0 = time.time()
                if self.cfg.provider == "openai":
                    text, usage = self._openai(system, user, max_tokens)
                elif self.cfg.provider == "anthropic":
                    text, usage = self._anthropic(system, user, max_tokens)
                elif self.cfg.provider == "claude_cli":
                    text, usage = self._claude_cli(system, user)
                else:
                    text, usage = self._mock(system, user)
                self.calls += 1
                self.prompt_tokens += usage.get("prompt_tokens", 0)
                self.completion_tokens += usage.get("completion_tokens", 0)
                data = _extract_json(text)
                self.log.append({"tag": tag, "attempt": attempt, "seconds": round(time.time() - t0, 2),
                                 "usage": usage, "chars_in": len(system) + len(user), "ok": True})
                return data
            except Exception as e:   # noqa: BLE001
                last_err = e
                self.log.append({"tag": tag, "attempt": attempt, "ok": False, "error": str(e)[:400]})
                time.sleep(min(10, 2 ** attempt))
        raise LLMError(f"LLM call failed after {self.cfg.max_retries} attempts: {last_err}")

    # ------------------------------------------------------------------ providers
    def _openai(self, system, user, max_tokens):
        url = self.cfg.base_url.rstrip("/") + "/chat/completions"
        body = {
            "model": self.cfg.model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "temperature": self.cfg.temperature,
            "max_tokens": max_tokens,
            "response_format": {"type": "json_object"},
        }
        headers = {"Authorization": f"Bearer {self.cfg.api_key}", "api-key": self.cfg.api_key, "Content-Type": "application/json"}
        r = requests.post(url, json=body, timeout=self.cfg.timeout_s, headers=headers)
        if r.status_code == 400 and ("response_format" in r.text or "json_object" in r.text):
            body.pop("response_format", None)
            r = requests.post(url, json=body, timeout=self.cfg.timeout_s, headers=headers)
        if r.status_code >= 400:
            raise LLMError(f"HTTP {r.status_code} from {url}: {r.text[:400]}")
        j = r.json()
        msg = j["choices"][0]["message"]
        text = msg.get("content") or ""
        if not text and msg.get("reasoning_content"):      # some Qwen/DeepSeek deployments put the answer here
            text = msg["reasoning_content"]
        usage = j.get("usage", {})
        return text, {"prompt_tokens": usage.get("prompt_tokens", 0), "completion_tokens": usage.get("completion_tokens", 0)}

    def _anthropic(self, system, user, max_tokens):
        url = (self.cfg.base_url if "anthropic" in self.cfg.base_url else "https://api.anthropic.com").rstrip("/") + "/v1/messages"
        body = {"model": self.cfg.model, "max_tokens": max_tokens, "system": system,
                "messages": [{"role": "user", "content": user + "\n\nRespond with a single JSON object only."}],
                "temperature": self.cfg.temperature}
        r = requests.post(url, json=body, timeout=self.cfg.timeout_s,
                          headers={"x-api-key": self.cfg.api_key, "anthropic-version": "2023-06-01",
                                   "content-type": "application/json"})
        if r.status_code >= 400:
            raise LLMError(f"HTTP {r.status_code}: {r.text[:400]}")
        j = r.json()
        text = "".join(b.get("text", "") for b in j.get("content", []))
        u = j.get("usage", {})
        return text, {"prompt_tokens": u.get("input_tokens", 0), "completion_tokens": u.get("output_tokens", 0)}

    def _claude_cli(self, system, user):
        """Local Claude Code CLI in print mode (default model alias 'haiku'); strips the nested-session
        environment so it also works when launched from inside an IDE-hosted Claude Code session."""
        import os
        exe = getattr(self, "_cli", None) or self.cfg.resolve_claude_cli()
        self._cli = exe
        model = self.cfg.model if self.cfg.model and not self.cfg.model.startswith("qwen") else "haiku"
        # note: --bare would skip credential loading ("Not logged in"), so it is NOT used
        cmd = [exe, "-p", "--model", model, "--output-format", "json", "--no-session-persistence",
               "--system-prompt", system]
        env = {k: v for k, v in os.environ.items() if k not in ("CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_SSE_PORT")}
        p = subprocess.run(cmd, input=user + "\n\nRespond with a single JSON object only, no prose, no markdown fences.",
                           capture_output=True, text=True, timeout=self.cfg.timeout_s, encoding="utf-8", errors="replace", env=env)
        if p.returncode != 0:
            raise LLMError(f"claude CLI exit {p.returncode}: {(p.stderr or p.stdout)[:400]}")
        try:
            j = json.loads(p.stdout)
            if j.get("is_error"):
                raise LLMError(f"claude CLI error: {str(j.get('result'))[:300]}")
            text = j.get("result", p.stdout)
            u = j.get("usage", {})
            usage = {"prompt_tokens": u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0) + u.get("cache_creation_input_tokens", 0),
                     "completion_tokens": u.get("output_tokens", 0), "cost_usd": j.get("total_cost_usd")}
        except json.JSONDecodeError:
            text, usage = p.stdout, {}
        return text, usage

    # ------------------------------------------------------------------ mock
    def _mock(self, system, user):
        """Deterministic stand-in: echoes the structure the prompts ask for, using facts from the user message."""
        usage = {"prompt_tokens": int(len(system + user) / 3.3), "completion_tokens": 300}
        if "TASK: analyze_window" in user:
            pk = re.findall(r"#(\d+)", user)
            fid = re.search(r"finding_id: (\S+)", user)
            title = re.search(r"title: (.*)", user)
            kind = re.search(r"kind: (\S+)", user)
            out = {
                "finding_id": fid.group(1) if fid else "?",
                "confirmed": True,
                "root_cause": f"[mock] {title.group(1) if title else 'anomaly'} confirmed from the evidence rows.",
                "mechanism": f"[mock] The {kind.group(1) if kind else 'event'} sequence in the window matches the spec description "
                             "given in the deterministic finding; the packets listed below are the offending ones.",
                "offending_packets": [int(p) for p in pk[:5]],
                "offending_command": {},
                "expected_time_us": None, "observed_time_us": None, "extra_time_us": None,
                "extra_time_source": "see mechanism",
                "responsible_side": "device" if kind and kind.group(1) in ("malformed_tlp", "poisoned_tlp", "slow_nvme_command", "lcrc_error") else "host",
                "confidence": 0.6,
                "fix": "[mock] see deterministic fix hypothesis",
                "notes": "mock provider - configure LLM_PROVIDER/LLM_API_KEY for a real analysis",
            }
            return json.dumps(out), usage
        if "TASK: reduce_findings" in user:
            # group the window findings by their title stem (same mechanism in both exports -> one root cause)
            m = re.search(r"WINDOW FINDINGS \(JSON list\)\n(.*)\n\nReturn JSON", user, re.S)
            try:
                items = json.loads(m.group(1)) if m else []
            except Exception:
                items = []
            groups: dict[str, list] = {}
            for it in items:
                stem = re.sub(r"\s*\(\d+x\)|\s*\(.*?L1 cycles\)|:\s.*$", "", str(it.get("title") or it.get("root_cause") or "?"))
                stem = re.sub(r"SQ\d+ CID \d+", "", stem).strip()
                groups.setdefault(stem, []).append(it)
            sev_rank = {5: "critical", 4: "high", 3: "medium", 2: "low", 1: "info"}
            rcs = []
            for i, (stem, its) in enumerate(groups.items()):
                sev = max((it.get("severity") or 3) for it in its if isinstance(it.get("severity"), int)) if any(
                    isinstance(it.get("severity"), int) for it in its) else 3
                pk = sorted({p for it in its for p in (it.get("offending_packets") or []) if isinstance(p, int)})[:12]
                rcs.append({"id": f"RC-{i + 1}", "title": stem, "finding_ids": [it.get("finding_id") for it in its],
                            "severity": sev_rank.get(sev, "medium"), "layer": its[0].get("layer") or "unknown",
                            "explanation": "[mock] " + str(its[0].get("root_cause") or "")[:300],
                            "responsible_side": its[0].get("responsible_side") or "unknown",
                            "latency_impact_us": its[0].get("extra_time_us"), "fix": str(its[0].get("fix") or "")[:200],
                            "evidence_packets": pk})
            return json.dumps({"root_causes": rcs,
                               "executive_summary": "[mock] executive summary - configure a real LLM provider "
                                                    "(LLM_PROVIDER=openai, LLM_API_KEY, LLM_MODEL) for a written analysis.",
                               "open_questions": []}), usage
        if "TASK: generate_test_case" in user:
            rc = re.search(r'"id": "(RC-\d+)"', user)
            return json.dumps({
                "test_id": f"TC-{rc.group(1) if rc else 'X'}",
                "title": "[mock] reproduce root cause",
                "objective": "[mock]",
                "environment": {"host": "Linux 6.x, nvme-cli, fio", "analyzer": "Teledyne Summit + PCIe Protocol Analysis 13.28",
                                "link": "Gen4 x4"},
                "preconditions": ["device formatted", "ASPM state recorded"],
                "analyzer_trigger": {"event": "Errors", "pre_trigger_pct": 20},
                "steps": [{"n": 1, "cmd": "nvme id-ctrl /dev/nvme0", "expect": "controller identified"},
                          {"n": 2, "cmd": "fio --name=t --filename=/dev/nvme0n1 --rw=read --bs=128k --iodepth=32 --runtime=60 --time_based",
                           "expect": "no errors"}],
                "pass_criteria": ["0 occurrences of the error in the Teledyne Error Summary"],
                "fail_criteria": [">=1 occurrence"],
                "metrics_to_record": ["p99 latency", "Nak count"],
            }), usage
        return json.dumps({"ok": True}), usage
