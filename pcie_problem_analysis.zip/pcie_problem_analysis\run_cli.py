"""Run the whole pipeline from the command line (no server), e.g. for a 3 GB file on the analyzer PC:

  python run_cli.py --trace data/samples/pcie_trace_export.csv --out data/jobs/cli-run --provider claude_cli
  python run_cli.py --trace D:/traces/export.csv --provider openai --base-url https://.../v1 --api-key sk-... --model qwen-plus
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from backend.analyzer.llm_pipeline import run_job   # noqa: E402
from backend.config import AnalysisConfig, LLMConfig  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace", dest="trace", help="Teledyne pex->CSV packet export (the normal single-file input)")
    ap.add_argument("--all", dest="all_speeds", help="optional: 'All link speeds/widths' filtered export")
    ap.add_argument("--gen4", dest="gen4_x4", help="optional: 'Gen4, x4' filtered export")
    ap.add_argument("--out", default=os.path.join("data", "jobs", time.strftime("cli-%Y%m%d-%H%M%S")))
    ap.add_argument("--provider", default=None, choices=["openai", "anthropic", "claude_cli", "mock"])
    ap.add_argument("--base-url", default=None)
    ap.add_argument("--api-key", default=None)
    ap.add_argument("--model", default=None)
    ap.add_argument("--context-tokens", type=int, default=None)
    ap.add_argument("--max-windows", type=int, default=None)
    ap.add_argument("--environment", default="")
    a = ap.parse_args()
    cfg = LLMConfig()
    for k_cli, k_cfg in (("provider", "provider"), ("base_url", "base_url"), ("api_key", "api_key"), ("model", "model"),
                         ("context_tokens", "context_tokens")):
        v = getattr(a, k_cli)
        if v is not None:
            setattr(cfg, k_cfg, v)
    cfg.normalize()
    if cfg.provider == "mock":
        print("no API key configured (args / .env / LLM_API_KEY) -> using the offline mock provider: deterministic findings only")
    else:
        print(f"LLM provider {cfg.provider}: {cfg.base_url} model {cfg.model}")
    acfg = AnalysisConfig()
    if a.max_windows:
        acfg.max_llm_windows = a.max_windows
    os.makedirs(a.out, exist_ok=True)
    t0 = time.time()
    inputs = {k: v for k, v in (("trace", a.trace), ("all_speeds", a.all_speeds), ("gen4_x4", a.gen4_x4)) if v}
    if not inputs:
        ap.error("give --trace <csv>")
    res = run_job(a.out, inputs, cfg, acfg, a.environment)
    print(json.dumps(res), f"in {time.time() - t0:.1f}s -> {os.path.join(a.out, 'report.html')}")
