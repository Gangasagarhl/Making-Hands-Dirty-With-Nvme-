#!/usr/bin/env python
"""
Stage 1 - synthetic Teledyne LeCroy "pex -> CSV" packet export (PCIe Protocol Analysis 13.28.b.15 layout).

One CSV, the 112 columns of the real export (confirmed with the user), one packet per row.
There are NO decode-helper columns (no Errors, no Link Speed/Width, no NVMe fields): everything must be inferred
from the raw protocol content, exactly as with a real export:

  * speed / width            <- TS1/TS2 "TS_Data Rate", "TS Lane" and Link Event rows
  * LCRC / ECRC errors       <- "(Bad)" annotation in the LCRC / ECRC cell
  * NAK / replay             <- DLLP Type = Nak, and TLPs re-sent with an already-seen PSN
  * poison                   <- EP = 1
  * UR / CA                  <- Cpl Status
  * malformed TLP            <- Length (DW) disagrees with the payload in Data / exceeds Max_Payload_Size
  * completion timeout       <- a non-posted TLP (Tag) that never receives its Cpl/CplD
  * flow-control stall       <- credit accounting over InitFC/UpdateFC (HdrFC/DataFC) vs posted TLPs
  * ASPM L1                  <- DLLP PM_Enter_L1 / PM_Request_Ack + Link Event L1 Entry/Exit + Recovery
  * NVMe commands            <- doorbell MWr to BAR0+0x1000.., SQE bytes in the CplD Data of the 64-byte fetch,
                                CQE bytes in the 16-byte upstream MWr (CID / SQID / status), MSI-X MWr to 0xFEExxxxx

Injected faults (logged to injected_faults.json with the first packet number of each):
  F1  bad LCRC -> Nak -> replay            F6  poisoned data TLP (EP=1)
  F2  replay-timer expiry (Ack starvation) F7  posted flow-control credit stall, UpdateFC-P late
  F3  completion timeout on SQE fetch      F8  ASPM L1 entry, slow exit -> first command after idle is slow
  F4  Unsupported Request completion       F9  slow NVMe Write with a clean link (firmware)
  F5  malformed TLP (Length vs payload)    F10 receiver errors -> Recovery -> speed downshift Gen4 -> Gen3

Usage:
  python generate_synthetic_trace.py --out ../data/samples --rows 150000          # small sample
  python generate_synthetic_trace.py --out D:/traces --size-gb 2                   # ~2 GB, streamed
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import random
import struct
import time
from dataclasses import dataclass, field

COLUMNS = [
    "Marker", "Packet", "Link", "Direction", "Ordered Set Type", "DLLP Type", "TLP Type", "Link Event",
    "PSN", "ACK/NAK Sequence Number", "VC ID", "HdrScale", "HdrFC", "DataScale", "DataFC", "Feature Ack", "Feature Support",
    "TC", "LN", "TH", "NW", "TD", "EP", "Attributes", "AT", "Length", "Requester ID", "Tag", "Completer ID", "Address",
    "Device ID", "Register", "First BE", "Last BE", "Cpl Status", "Byte Cnt", "BCM", "Lwr Addr", "Msg Routing", "Message Code",
    "TS Link", "TS Lane", "N_FTS", "Training_Control", "TS_Data Rate", "TS Gen3 EQ Control", "TS Gen3 Pre-cursor",
    "TS Gen3 Cursor", "TS Gen3 Post-cursor",
    "PMUX Channel ID", "PMUX Metadata",
    "Snoop Requirement", "Snoop Scale", "Snoop Value", "No Snoop Requirement", "No Snoop Scale", "No Snoop Value",
    "PTM Master Time[63:32]", "PTM Master Time[31:0]", "PTM Propagation Delay",
    "ARP Command", "Slave Address", "Target Address", "Device Slave Address", "Assign Address", "Read/Write", "Byte Count",
    "Address Type", "PEC Support", "UDID Version", "Silicon Revision", "Vendor ID", "Device ID", "Zone", "IPMI", "ASF", "OEM",
    "SMBus Version", "Sub Vendor ID", "Sub Device ID", "Vendor Specific ID", "PEC",
    "LCRC", "ECRC", "CRC16", "Data", "Time Delta", "Time Stamp",
    "Jammer Phase", "Action", "Jammer Target Packet", "Jammer Result Packet",
    "CXL Packet", "CXL Packet Subtype", "Opcode", "CQID", "UQID", "Address[51:6]", "NT", "RSP_PRE", "MESI", "ChunkValid",
    "Bogus", "Poison", "Go-Err", "Meta Field", "Meta Value", "Snp Type", "LLCTRL", "Packet Subtype", "ALMP VLSM State",
    "ALMP VLSM Target",
]
# "Device ID" appears twice in the real header (TLP Device ID for Cfg requests, and the SMBus UDID Device ID);
# the first occurrence is the TLP one and is the only one this generator fills.
COL = {}
for i, c in enumerate(COLUMNS):
    COL.setdefault(c, i)

HOST_ID = "00:00.0"
SSD_ID = "01:00.0"
BAR0 = 0xF000_0000
DB_BASE = BAR0 + 0x1000
HOST_SQ_BASE = 0x1_2000_0000
HOST_CQ_BASE = 0x1_3000_0000
HOST_DATA_BASE = 0x2_0000_0000
MSIX_BASE = 0xFEE0_0000
RATE = {1: "2.5 GT/s", 2: "5.0 GT/s", 3: "8.0 GT/s", 4: "16.0 GT/s"}
MAX_PAYLOAD = 256


@dataclass
class Fault:
    id: str
    name: str
    layer: str
    t_start_s: float
    first_packet: int
    notes: str
    expected_findings: list = field(default_factory=list)
    command: dict = field(default_factory=dict)


class TraceWriter:
    def __init__(self, path: str, rnd: random.Random):
        self.f = open(path, "w", newline="", encoding="utf-8", buffering=4 * 1024 * 1024)
        self.w = csv.writer(self.f)
        self.w.writerow(COLUMNS)
        self.rnd = rnd
        self.n = 0
        self.t_ns = 0
        self.last_t_ns = 0
        self.speed = 1
        self.width = 1
        self.psn = {"Downstream": 0, "Upstream": 0}
        self.pool = [" ".join(f"{rnd.randrange(256):02X}" for _ in range(256)) for _ in range(32)]
        # posted flow control credit limits advertised by the host (receiver of Upstream posted TLPs)
        self.host_p_data_limit = 1024     # credits of 16 B (12-bit cumulative credit limit advertised by the host)
        self.host_p_consumed = 0
        self.host_p_limit_base = 0        # consumed value at the last UpdateFC-P
        self.fc_frozen = False
        from collections import deque
        self.host_seen_psn = deque(maxlen=64)

    def close(self):
        self.f.close()

    def size(self):
        return self.f.tell()

    def advance(self, ns):
        self.t_ns += int(ns)

    def _ts(self):
        s, ns = divmod(self.t_ns, 1_000_000_000)
        return f"{s}.{ns:09d}"

    def row(self, direction: str, **fields) -> int:
        self.n += 1
        r = [""] * len(COLUMNS)
        r[COL["Packet"]] = self.n
        r[COL["Link"]] = "0"
        r[COL["Direction"]] = direction
        r[COL["Time Delta"]] = self.t_ns - self.last_t_ns
        r[COL["Time Stamp"]] = self._ts()
        self.last_t_ns = self.t_ns
        for k, v in fields.items():
            r[COL[k]] = v
        self.w.writerow(r)
        return self.n

    # ---------------------------------------------------------------- packet helpers
    def lcrc(self, bad=False):
        v = f"0x{self.rnd.randrange(1 << 32):08X}"
        return v + " (Bad)" if bad else v

    def tlp(self, direction, ttype, *, psn=None, length=0, data=None, bad_lcrc=False, **fields):
        if psn is None:
            self.psn[direction] = (self.psn[direction] + 1) & 0xFFF
            psn = self.psn[direction]
        f = {"TLP Type": ttype, "PSN": psn, "TC": 0, "TD": 0, "EP": fields.pop("EP", 0), "Attributes": "0x0", "AT": 0,
             "LN": 0, "TH": 0, "NW": 0, "Length": length, "LCRC": self.lcrc(bad_lcrc)}
        if data is not None:
            f["Data"] = data
        f.update(fields)
        n = self.row(direction, **f)
        # receiver-side posted credit consumption: only TLPs the host actually accepts (good LCRC, PSN not already received)
        accepted = False
        if direction == "Upstream":            # the host is the receiver of upstream TLPs
            accepted = not bad_lcrc and psn not in self.host_seen_psn
            if accepted:
                self.host_seen_psn.append(psn)
        if direction == "Upstream" and ttype.startswith(("MWr", "Msg")) and accepted:
            self.host_p_consumed += max(1, (length * 4 + 15) // 16)
            # a real root complex returns posted credits continuously; emit UpdateFC-P once ~256 credits (4 KB) were consumed
            if not self.fc_frozen and ((self.host_p_consumed - self.host_p_limit_base) & 0xFFF) >= 256:
                self.update_fc("Downstream", "P")
        return n, psn

    def dllp(self, direction, dtype, **fields):
        return self.row(direction, **{"DLLP Type": dtype, "CRC16": f"0x{self.rnd.randrange(1 << 16):04X}", **fields})

    def ack(self, direction, psn, delay_ns=250):
        self.advance(delay_ns)
        return self.dllp(direction, "Ack", **{"ACK/NAK Sequence Number": psn})

    def nak(self, direction, psn):
        self.advance(300)
        return self.dllp(direction, "Nak", **{"ACK/NAK Sequence Number": psn})

    def update_fc(self, direction, kind="P", hdr=None, data=None, vc=0):
        self.advance(40)
        if direction == "Downstream" and kind == "P":
            self.host_p_data_limit = (self.host_p_consumed + 1024) & 0xFFF
            self.host_p_limit_base = self.host_p_consumed
            hdr, data = 0x40 if hdr is None else hdr, self.host_p_data_limit if data is None else data
        return self.dllp(direction, f"UpdateFC-{kind}", **{"VC ID": vc, "HdrScale": 0, "HdrFC": hdr if hdr is not None else 0x20,
                                                           "DataScale": 0, "DataFC": data if data is not None else 0x100})

    def os(self, direction, ostype, **fields):
        return self.row(direction, **{"Ordered Set Type": ostype, **fields})

    def ts(self, direction, kind, rate=None, lanes=None, speed_change=0, eq=None):
        rate = rate or self.speed
        lanes = lanes or self.width
        f = {"Ordered Set Type": kind, "TS Link": 0, "TS Lane": f"0-{lanes - 1}" if lanes > 1 else "0",
             "N_FTS": 0x7F, "Training_Control": f"0x{(0x02 if speed_change else 0):02X}",
             "TS_Data Rate": RATE[rate] + (" (speed_change)" if speed_change else "")}
        if eq is not None:
            f.update({"TS Gen3 EQ Control": eq, "TS Gen3 Pre-cursor": 0, "TS Gen3 Cursor": 24, "TS Gen3 Post-cursor": 8})
        return self.row(direction, **f)

    def event(self, direction, text):
        return self.row(direction, **{"Link Event": text})

    def skp(self, direction):
        self.advance(16)
        return self.os(direction, "SKP")

    def payload(self, nbytes):
        s = self.rnd.choice(self.pool)
        return s[: nbytes * 3 - 1] if nbytes <= 256 else s


def hexbytes(b: bytes) -> str:
    return " ".join(f"{x:02X}" for x in b)


def sqe_bytes(opc, cid, nsid, prp1, prp2, slba, nlb) -> bytes:
    cdw0 = opc | (cid << 16)
    return struct.pack("<IIQQQQIIIIII", cdw0, nsid, 0, 0, prp1, prp2, slba & 0xFFFFFFFF, slba >> 32, nlb - 1, 0, 0, 0)


def cqe_bytes(sqhd, sqid, cid, phase, status) -> bytes:
    return struct.pack("<IIHHHH", 0, 0, sqhd, sqid, cid, (status << 1) | phase)


# ======================================================================================= enumeration / training
def link_training(w: TraceWriter, faults):
    first = w.n + 1
    w.speed, w.width = 1, 1
    w.event("Downstream", "Link Training Start (Detect)")
    for _ in range(40):
        w.advance(4)
        w.ts("Downstream", "TS1", rate=1, lanes=1)
        w.advance(4)
        w.ts("Upstream", "TS1", rate=1, lanes=1)
    w.event("Downstream", "Polling.Configuration")
    w.width = 4
    for _ in range(16):
        w.advance(4)
        w.ts("Downstream", "TS2", rate=1, lanes=4)
        w.advance(4)
        w.ts("Upstream", "TS2", rate=1, lanes=4)
    w.event("Downstream", "Link Width Change: x1 -> x4")
    w.event("Downstream", "Link Up (L0)")
    for k, hdr, data in (("P", 0x20, 0x100), ("NP", 0x20, 0x00), ("Cpl", 0x00, 0x00)):
        for stage in ("InitFC1", "InitFC2"):
            w.advance(60)
            w.dllp("Downstream", f"{stage}-{k}", **{"VC ID": 0, "HdrScale": 0, "HdrFC": 0x40, "DataScale": 0, "DataFC": 0x400})
            w.advance(60)
            w.dllp("Upstream", f"{stage}-{k}", **{"VC ID": 0, "HdrScale": 0, "HdrFC": hdr, "DataScale": 0, "DataFC": data})
    w.host_p_data_limit, w.host_p_consumed, w.host_p_limit_base = 0x400, 0, 0
    w.advance(200)
    w.dllp("Downstream", "Data_Link_Feature", **{"Feature Ack": 0, "Feature Support": "0x1"})
    w.advance(100)
    w.dllp("Upstream", "Data_Link_Feature", **{"Feature Ack": 1, "Feature Support": "0x1"})
    for target in (3, 4):
        w.advance(2_000)
        w.event("Downstream", f"Recovery Entry (speed change to {RATE[target]})")
        for _ in range(12):
            w.advance(4)
            w.ts("Downstream", "TS1", rate=target, speed_change=1)
            w.advance(4)
            w.ts("Upstream", "TS1", rate=target, speed_change=1)
        w.advance(500)
        w.os("Downstream", "EIOS")
        w.event("Downstream", "Electrical Idle Entry")
        w.advance(1_500)
        w.event("Downstream", "Electrical Idle Exit")
        w.speed = target
        w.event("Downstream", f"Speed Change: {RATE[target - 1 if target == 3 else 3]} -> {RATE[target]}")
        if target == 4:
            for ph in (1, 2, 3):
                w.advance(400)
                w.event("Downstream", f"Recovery.Equalization Phase {ph}")
                for _ in range(4):
                    w.advance(2)
                    w.ts("Downstream", "TS1", rate=4, eq=ph)
                    w.advance(2)
                    w.ts("Upstream", "TS1", rate=4, eq=ph)
        for _ in range(8):
            w.advance(2)
            w.ts("Downstream", "TS2", rate=target)
            w.advance(2)
            w.ts("Upstream", "TS2", rate=target)
        w.event("Downstream", "Recovery Exit (L0)")
    faults.append(Fault("TRAIN", "Link training Gen1 x1 -> Gen4 x4", "Physical", 0.0, first,
                        "Normal: Detect -> Polling -> Configuration -> L0 at 2.5 GT/s, then Recovery speed changes to 8 and 16 GT/s "
                        "with Gen3/Gen4 equalization phases.", ["link_training_sequence"]))


def enumeration(w: TraceWriter):
    """Config-space enumeration + NVMe controller init so BAR0 / queues can be learned from the trace."""
    tag = 0

    def cfg(rw, reg, data=None, cpl_data=None):
        nonlocal tag
        tag = (tag + 1) % 32
        w.advance(w.rnd.randint(500, 1500))
        _, psn = w.tlp("Downstream", f"Cfg{rw}0", length=1, **{"Requester ID": HOST_ID, "Tag": tag, "Device ID": SSD_ID,
                                                                "Register": f"0x{reg:03X}", "First BE": "0xF", "Last BE": "0x0"},
                       data=hexbytes(struct.pack("<I", data)) if data is not None else None)
        w.ack("Upstream", psn)
        w.advance(w.rnd.randint(600, 1200))
        _, psn = w.tlp("Upstream", "CplD" if cpl_data is not None else "Cpl", length=1 if cpl_data is not None else 0,
                       **{"Requester ID": HOST_ID, "Tag": tag, "Completer ID": SSD_ID, "Cpl Status": "SC",
                          "Byte Cnt": 4, "BCM": 0, "Lwr Addr": "0x00"},
                       data=hexbytes(struct.pack("<I", cpl_data)) if cpl_data is not None else None)
        w.ack("Downstream", psn)

    cfg("Rd", 0x000, cpl_data=0xA80A144D)          # Vendor/Device ID
    cfg("Wr", 0x010, data=0xFFFFFFFF, cpl_data=None)
    cfg("Rd", 0x010, cpl_data=0xFFFFC004)          # BAR0 size probe
    cfg("Wr", 0x010, data=BAR0 | 0x4, cpl_data=None)   # BAR0 = 0xF0000000 (64-bit)
    cfg("Wr", 0x014, data=0x00000000, cpl_data=None)
    cfg("Wr", 0x004, data=0x00000406, cpl_data=None)   # Command: Mem + BusMaster
    cfg("Rd", 0x034, cpl_data=0x00000080)          # Cap pointer -> 0x80 (PCIe cap)
    cfg("Rd", 0x080, cpl_data=0x00020010)          # PCIe cap header
    cfg("Rd", 0x08C, cpl_data=0x1003_7C44)         # Link Capabilities: 16 GT/s x4, ASPM L0s/L1, L1 exit latency bits[17:15]=6 (32-64us)
    cfg("Rd", 0x090, cpl_data=0x1044_0042)         # Link Control/Status: ASPM L1 enabled, 16 GT/s x4
    cfg("Wr", 0x090, data=0x0000_0042, cpl_data=None)  # ASPM L1 enabled, common clock
    # NVMe controller registers in BAR0
    def bar_wr(off, val):
        w.advance(w.rnd.randint(300, 800))
        _, psn = w.tlp("Downstream", "MWr32", length=1, **{"Requester ID": HOST_ID, "Address": f"0x{BAR0 + off:016X}",
                                                           "First BE": "0xF", "Last BE": "0x0"}, data=hexbytes(struct.pack("<I", val)))
        w.ack("Upstream", psn)

    def bar_rd(off, val):
        nonlocal tag
        tag = (tag + 1) % 32
        w.advance(w.rnd.randint(300, 800))
        _, psn = w.tlp("Downstream", "MRd32", length=1, **{"Requester ID": HOST_ID, "Tag": tag, "Address": f"0x{BAR0 + off:016X}",
                                                           "First BE": "0xF", "Last BE": "0x0"})
        w.ack("Upstream", psn)
        w.advance(w.rnd.randint(600, 1200))
        _, psn = w.tlp("Upstream", "CplD", length=1, **{"Requester ID": HOST_ID, "Tag": tag, "Completer ID": SSD_ID, "Cpl Status": "SC",
                                                        "Byte Cnt": 4, "BCM": 0, "Lwr Addr": f"0x{off & 0x7F:02X}"},
                       data=hexbytes(struct.pack("<I", val)))
        w.ack("Downstream", psn)

    bar_rd(0x00, 0x00FF_0030)      # CAP low
    bar_rd(0x04, 0x0020_0010)      # CAP high: DSTRD=0, MPSMIN
    bar_rd(0x08, 0x0001_0400)      # VS 1.4
    bar_wr(0x14, 0x0000_0000)      # CC.EN = 0
    bar_rd(0x1C, 0x0000_0000)      # CSTS.RDY = 0
    bar_wr(0x24, 0x001F_001F)      # AQA
    bar_wr(0x28, HOST_SQ_BASE & 0xFFFFFFFF)   # ASQ low
    bar_wr(0x2C, HOST_SQ_BASE >> 32)
    bar_wr(0x30, HOST_CQ_BASE & 0xFFFFFFFF)   # ACQ low
    bar_wr(0x34, HOST_CQ_BASE >> 32)
    bar_wr(0x14, 0x0046_0001)      # CC.EN = 1, IOSQES/IOCQES
    w.advance(20_000)
    bar_rd(0x1C, 0x0000_0001)      # CSTS.RDY = 1


# ======================================================================================= NVMe model
class NvmeModel:
    def __init__(self, w: TraceWriter):
        self.w = w
        self.rnd = w.rnd
        self.sq_tail = {q: 0 for q in range(0, 5)}
        self.cq_head = {q: 0 for q in range(0, 5)}
        self.cid = {q: 0 for q in range(0, 5)}
        self.phase = {q: 1 for q in range(0, 5)}
        self.tag_up = 0
        self.tag_down = 0

    def next_tag(self, up=True):
        if up:
            self.tag_up = (self.tag_up + 1) % 64
            return self.tag_up
        self.tag_down = (self.tag_down + 1) % 32
        return self.tag_down

    def command(self, qid, opc, nlb=8, *, device_delay_ns=70_000, fault=None, cqe_status=0):
        w, rnd = self.w, self.rnd
        self.cid[qid] = (self.cid[qid] + 1) & 0xFFFF
        cid = self.cid[qid]
        slot = self.sq_tail[qid]
        self.sq_tail[qid] = (self.sq_tail[qid] + 1) % 1024
        nbytes = nlb * 512 if opc in (1, 2) else 0
        prp1 = HOST_DATA_BASE + rnd.randrange(1 << 20) * 4096
        prp2 = prp1 + 4096 if nbytes > 4096 else 0
        slba = rnd.randrange(1 << 30)
        ev = {"qid": qid, "cid": cid, "opc": {1: "Write", 2: "Read", 0: "Flush"}.get(opc, f"0x{opc:02X}"), "bytes": nbytes}

        # 1. SQ tail doorbell
        w.advance(rnd.randint(200, 900))
        n, psn = w.tlp("Downstream", "MWr32", length=1, **{"Requester ID": HOST_ID, "Address": f"0x{DB_BASE + (2 * qid) * 4:016X}",
                                                           "First BE": "0xF", "Last BE": "0x0"},
                       data=hexbytes(struct.pack("<I", self.sq_tail[qid])))
        ev["doorbell_pkt"], ev["t_doorbell"] = n, w.t_ns
        w.ack("Upstream", psn)
        # 2. SQE fetch
        w.advance(rnd.randint(300, 700))
        tag = self.next_tag()
        n, psn = w.tlp("Upstream", "MRd64", length=16, **{"Requester ID": SSD_ID, "Tag": tag,
                                                          "Address": f"0x{HOST_SQ_BASE + qid * 0x10000 + slot * 64:016X}",
                                                          "First BE": "0xF", "Last BE": "0xF"})
        ev["sqe_fetch_pkt"] = n
        w.ack("Downstream", psn)
        if fault == "F3_completion_timeout":
            ev["fault"] = fault
            w.advance(50_500_000)
            return ev
        w.advance(rnd.randint(400, 900))
        n, psn = w.tlp("Downstream", "CplD", length=16, **{"Requester ID": SSD_ID, "Tag": tag, "Completer ID": HOST_ID,
                                                           "Cpl Status": "SC", "Byte Cnt": 64, "BCM": 0, "Lwr Addr": "0x00"},
                       data=hexbytes(sqe_bytes(opc, cid, 1, prp1, prp2, slba, max(nlb, 1))))
        ev["sqe_data_pkt"] = n
        w.ack("Upstream", psn)

        # 3. data phase
        if opc == 2:    # Read: device writes to host memory
            remaining, addr, i = nbytes, prp1, 0
            while remaining > 0:
                chunk = min(MAX_PAYLOAD, remaining)
                if addr - prp1 >= 4096 and prp2:
                    addr = prp2 + (addr - prp1 - 4096)
                w.advance(rnd.randint(40, 120))
                ep = 1 if (fault == "F6_poisoned" and i == 0) else 0
                n, psn = w.tlp("Upstream", "MWr64", length=chunk // 4, EP=ep, **{"Requester ID": SSD_ID, "Address": f"0x{addr:016X}",
                                                                                   "First BE": "0xF", "Last BE": "0xF"},
                               data=w.payload(chunk))
                if ep:
                    ev["fault"], ev["fault_pkt"] = fault, n
                addr += chunk
                remaining -= chunk
                i += 1
                if i % 4 == 0:
                    w.ack("Downstream", psn)
            w.ack("Downstream", psn)
        elif opc == 1:  # Write: device reads from host memory
            remaining, addr, outstanding, i = nbytes, prp1, [], 0
            while remaining > 0:
                chunk = min(512, remaining)
                w.advance(rnd.randint(60, 150))
                tag = self.next_tag()
                length = chunk // 4
                n, psn = w.tlp("Upstream", "MRd64", length=length, **{"Requester ID": SSD_ID, "Tag": tag, "Address": f"0x{addr:016X}",
                                                                      "First BE": "0xF", "Last BE": "0xF"})
                w.ack("Downstream", psn)
                outstanding.append((tag, chunk, i))
                addr += chunk
                remaining -= chunk
                i += 1
            for tag, chunk, i in outstanding:
                parts = [min(MAX_PAYLOAD, chunk - k) for k in range(0, chunk, MAX_PAYLOAD)]
                remaining_bc = chunk
                for p in parts:
                    w.advance(rnd.randint(300, 800))
                    length = p // 4
                    data = w.payload(p)
                    if fault == "F5_malformed" and i == 0 and remaining_bc == chunk:
                        length = p // 4 + 1       # Length says 65 DW (260 B) but 256 B of data follow, and 260 B > Max_Payload_Size
                    n, psn = w.tlp("Downstream", "CplD", length=length, **{"Requester ID": SSD_ID, "Tag": tag, "Completer ID": HOST_ID,
                                                                           "Cpl Status": "SC", "Byte Cnt": remaining_bc, "BCM": 0,
                                                                           "Lwr Addr": "0x00"}, data=data)
                    if length != p // 4:
                        ev["fault"], ev["fault_pkt"] = fault, n
                    remaining_bc -= p
                    w.ack("Upstream", psn)

        # 4. device internal time, then CQE
        w.advance(device_delay_ns)
        if fault == "F9_slow_cmd":
            ev["fault"] = fault
        n, psn = w.tlp("Upstream", "MWr64", length=4, **{"Requester ID": SSD_ID,
                                                         "Address": f"0x{HOST_CQ_BASE + qid * 0x10000 + self.cq_head[qid] * 16:016X}",
                                                         "First BE": "0xF", "Last BE": "0xF"},
                       data=hexbytes(cqe_bytes(self.sq_tail[qid], qid, cid, self.phase[qid], cqe_status)))
        ev["cqe_pkt"], ev["t_cqe"] = n, w.t_ns
        w.ack("Downstream", psn)
        # 5. MSI-X
        w.advance(rnd.randint(100, 300))
        n, psn = w.tlp("Upstream", "MWr32", length=1, **{"Requester ID": SSD_ID, "Address": f"0x{MSIX_BASE + qid * 0x1000:016X}",
                                                         "First BE": "0xF", "Last BE": "0x0"}, data=hexbytes(struct.pack("<I", 0x4000 + qid)))
        w.ack("Downstream", psn)
        # 6. CQ head doorbell
        self.cq_head[qid] = (self.cq_head[qid] + 1) % 1024
        if self.cq_head[qid] == 0:
            self.phase[qid] ^= 1
        w.advance(rnd.randint(1_500, 4_000))
        n, psn = w.tlp("Downstream", "MWr32", length=1, **{"Requester ID": HOST_ID, "Address": f"0x{DB_BASE + (2 * qid + 1) * 4:016X}",
                                                           "First BE": "0xF", "Last BE": "0x0"},
                       data=hexbytes(struct.pack("<I", self.cq_head[qid])))
        w.ack("Upstream", psn)
        ev["latency_us"] = (ev["t_cqe"] - ev["t_doorbell"]) / 1000
        return ev


def admin_setup(m: NvmeModel):
    """Identify + Create IO CQ/SQ 1..4 on the admin queue (qid 0) so queue bases appear in the trace."""
    w = m.w
    for opc in (0x06,):
        m.command(0, opc, nlb=8, device_delay_ns=120_000)
    for q in range(1, 5):
        m.command(0, 0x05, nlb=0, device_delay_ns=30_000)   # Create IO CQ
        m.command(0, 0x01, nlb=0, device_delay_ns=30_000)   # Create IO SQ  (admin opcode 0x01)
    w.advance(50_000)


# ======================================================================================= faults
def fault_lcrc_nak_replay(w: TraceWriter, m: NvmeModel, faults):
    first, t0 = w.n + 1, w.t_ns
    addr = HOST_DATA_BASE + 0x5000_0000
    psns, datas = [], []
    for i in range(3):
        w.advance(80)
        d = w.payload(256)
        n, psn = w.tlp("Upstream", "MWr64", length=64, bad_lcrc=(i == 1), **{"Requester ID": SSD_ID, "Address": f"0x{addr + i * 256:016X}",
                                                                              "First BE": "0xF", "Last BE": "0xF"}, data=d)
        psns.append(psn)
        datas.append(d)
    w.nak("Downstream", psns[0])
    w.advance(600)
    for i in (1, 2):   # replay: same PSN again
        w.advance(80)
        w.tlp("Upstream", "MWr64", psn=psns[i], length=64, **{"Requester ID": SSD_ID, "Address": f"0x{addr + i * 256:016X}",
                                                             "First BE": "0xF", "Last BE": "0xF"}, data=datas[i])
    w.ack("Downstream", psns[2])
    faults.append(Fault("F1", "Bad LCRC -> Nak -> replay", "Data Link", t0 / 1e9, first,
                        "Upstream MWr64 with '(Bad)' LCRC, host Nak with the last good PSN, device re-sends PSNs %d and %d." % (psns[1], psns[2]),
                        ["lcrc_error", "nak", "replayed_tlp"]))


def fault_replay_timer(w: TraceWriter, m: NvmeModel, faults):
    first, t0 = w.n + 1, w.t_ns
    psns, datas = [], []
    for i in range(4):
        w.advance(70)
        d = w.payload(256)
        n, psn = w.tlp("Upstream", "MWr64", length=64, **{"Requester ID": SSD_ID, "Address": f"0x{HOST_DATA_BASE + 0x6000_0000 + i * 256:016X}",
                                                         "First BE": "0xF", "Last BE": "0xF"}, data=d)
        psns.append(psn)
        datas.append(d)
    w.advance(4_200)      # no Ack: REPLAY_TIMER (~2-3 us at Gen4 x4) expires
    for i, psn in enumerate(psns):
        w.advance(70)
        w.tlp("Upstream", "MWr64", psn=psn, length=64, **{"Requester ID": SSD_ID, "Address": f"0x{HOST_DATA_BASE + 0x6000_0000 + i * 256:016X}",
                                                         "First BE": "0xF", "Last BE": "0xF"}, data=datas[i])
    w.ack("Downstream", psns[-1])
    faults.append(Fault("F2", "Replay-timer expiry (Ack starvation)", "Data Link", t0 / 1e9, first,
                        "4 upstream TLPs, no Ack for 4.2 us, all 4 re-sent with their original PSNs, no Nak involved.",
                        ["replay_timer_timeout", "replayed_tlp"]))


def fault_unsupported_request(w: TraceWriter, m: NvmeModel, faults):
    first, t0 = w.n + 1, w.t_ns
    tag = m.next_tag(up=False)
    w.advance(500)
    n, psn = w.tlp("Downstream", "MRd32", length=1, **{"Requester ID": HOST_ID, "Tag": tag, "Address": f"0x{BAR0 + 0x3F00:016X}",
                                                       "First BE": "0xF", "Last BE": "0x0"})
    w.ack("Upstream", psn)
    w.advance(900)
    n, psn = w.tlp("Upstream", "Cpl", length=0, **{"Requester ID": HOST_ID, "Tag": tag, "Completer ID": SSD_ID, "Cpl Status": "UR",
                                                   "Byte Cnt": 4, "BCM": 0, "Lwr Addr": "0x00"})
    w.ack("Downstream", psn)
    faults.append(Fault("F4", "Unsupported Request completion", "Transaction", t0 / 1e9, first,
                        "Host MRd32 to BAR0+0x3F00 (unimplemented register); SSD answers Cpl with Cpl Status = UR.", ["unsupported_request"]))


def fault_flow_control_stall(w: TraceWriter, m: NvmeModel, faults):
    first, t0 = w.n + 1, w.t_ns
    # host advertises credits only up to consumed+8 (8 x 16B = 128 B) -> device can send one 128 B TLP then must wait
    w.fc_frozen = True
    w.host_p_data_limit = (w.host_p_consumed + 8) & 0xFFF
    w.host_p_limit_base = w.host_p_consumed
    w.advance(40)
    w.dllp("Downstream", "UpdateFC-P", **{"VC ID": 0, "HdrScale": 0, "HdrFC": 0x40, "DataScale": 0, "DataFC": w.host_p_data_limit})
    w.advance(70)
    n, psn = w.tlp("Upstream", "MWr64", length=32, **{"Requester ID": SSD_ID, "Address": f"0x{HOST_DATA_BASE + 0x7000_0000:016X}",
                                                      "First BE": "0xF", "Last BE": "0xF"}, data=w.payload(128))
    w.ack("Downstream", psn)
    w.advance(48_000)     # credits exhausted; host returns UpdateFC-P only after 48 us
    w.fc_frozen = False
    w.update_fc("Downstream", "P")
    for i in range(4):
        w.advance(70)
        n, psn = w.tlp("Upstream", "MWr64", length=64, **{"Requester ID": SSD_ID, "Address": f"0x{HOST_DATA_BASE + 0x7000_0080 + i * 256:016X}",
                                                         "First BE": "0xF", "Last BE": "0xF"}, data=w.payload(256))
    w.ack("Downstream", psn)
    faults.append(Fault("F7", "Posted flow-control credit stall, late UpdateFC-P", "Data Link", t0 / 1e9, first,
                        "Host UpdateFC-P advertised only 8 more data credits; after one 128 B TLP the device had 0 credits and the next "
                        "UpdateFC-P came 48 us later (spec: <= 30 us).", ["flow_control_stall"]))


def fault_aspm_l1(w: TraceWriter, m: NvmeModel, faults):
    first, t0 = w.n + 1, w.t_ns
    w.advance(5_000)
    w.dllp("Upstream", "PM_Active_State_Request_L1")
    w.advance(400)
    w.dllp("Downstream", "PM_Request_Ack")
    w.advance(200)
    w.os("Upstream", "EIOS")
    w.os("Downstream", "EIOS")
    w.event("Downstream", "Electrical Idle Entry")
    w.event("Downstream", "L1 Entry")
    w.advance(2_000_000)
    w.event("Downstream", "L1 Exit (CLKREQ# asserted)")
    w.event("Downstream", "Electrical Idle Exit")
    w.event("Downstream", "Recovery Entry")
    for _ in range(6):
        w.advance(4)
        w.ts("Downstream", "TS1")
        w.advance(4)
        w.ts("Upstream", "TS1")
    w.advance(58_000)
    for _ in range(4):
        w.advance(4)
        w.ts("Downstream", "TS2")
        w.advance(4)
        w.ts("Upstream", "TS2")
    w.event("Downstream", "Recovery Exit (L0)")
    ev = m.command(2, 2, nlb=8, device_delay_ns=70_000)
    ev["fault"] = "F8_aspm_l1_exit"
    faults.append(Fault("F8", "ASPM L1 exit latency added to the first command after idle", "Power Management", t0 / 1e9, first,
                        "PM_Active_State_Request_L1 / PM_Request_Ack, L1 for 2 ms, exit through Recovery takes ~58 us "
                        "(advertised L1 exit latency in Link Capabilities 0x8C bits[17:15]=6 => 32-64 us). The next Read "
                        "(SQ2 CID %d) pays that time before its doorbell can be written." % ev["cid"],
                        ["l1_exit_latency", "slow_command_after_idle"], command=ev))
    return ev


def fault_link_recovery_downshift(w: TraceWriter, faults):
    first, t0 = w.n + 1, w.t_ns
    w.advance(900)
    w.event("Upstream", "Invalid Symbol (lane 2)")
    w.advance(50)
    w.tlp("Upstream", "MWr64", length=64, bad_lcrc=True, **{"Requester ID": SSD_ID, "Address": f"0x{HOST_DATA_BASE + 0x8000_0000:016X}",
                                                           "First BE": "0xF", "Last BE": "0xF"}, data=w.payload(256))
    w.event("Upstream", "Framing Error")
    w.event("Upstream", "Receiver Error")
    w.advance(200)
    w.event("Downstream", "Recovery Entry (receiver error)")
    for _ in range(10):
        w.advance(4)
        w.ts("Downstream", "TS1", rate=3, speed_change=1)
        w.advance(4)
        w.ts("Upstream", "TS1", rate=3, speed_change=1)
    w.advance(1_200)
    w.speed = 3
    w.event("Downstream", "Speed Change: 16.0 GT/s -> 8.0 GT/s")
    for _ in range(6):
        w.advance(3)
        w.ts("Downstream", "TS2", rate=3)
        w.advance(3)
        w.ts("Upstream", "TS2", rate=3)
    w.event("Downstream", "Recovery Exit (L0)")
    faults.append(Fault("F10", "Receiver errors -> Recovery -> speed downshift Gen4 -> Gen3", "Physical", t0 / 1e9, first,
                        "Invalid symbol + framing/receiver error on the upstream lanes, LTSSM Recovery, link re-trains at 8.0 GT/s. "
                        "Everything after this packet runs at half bandwidth.", ["receiver_error", "speed_change"]))


# ======================================================================================= main
def generate(out_dir, rows=None, size_gb=None, seed=7):
    os.makedirs(out_dir, exist_ok=True)
    rnd = random.Random(seed)
    path = os.path.join(out_dir, "pcie_trace_export.csv")
    w = TraceWriter(path, rnd)
    faults: list[Fault] = []
    link_training(w, faults)
    enumeration(w)
    m = NvmeModel(w)
    admin_setup(m)
    target_bytes = int(size_gb * 1e9) if size_gb else None
    target_rows = rows or 150_000
    schedule = [(0.08, "F1"), (0.17, "F4"), (0.26, "F3"), (0.35, "F7"), (0.44, "F5"), (0.53, "F8"), (0.62, "F9"),
                (0.71, "F6"), (0.80, "F2"), (0.90, "F10")]
    fired = set()
    cmd_log = []
    t_start = time.time()
    last_report = 0
    while True:
        frac = (w.size() / target_bytes) if target_bytes else (w.n / target_rows)
        if frac >= 1.0:
            break
        for f_at, fid in schedule:
            if frac >= f_at and fid not in fired:
                fired.add(fid)
                if fid == "F1":
                    fault_lcrc_nak_replay(w, m, faults)
                elif fid == "F2":
                    fault_replay_timer(w, m, faults)
                elif fid == "F3":
                    ev = m.command(1, 2, nlb=8, fault="F3_completion_timeout")
                    faults.append(Fault("F3", "Completion Timeout on SQE fetch", "Transaction", ev["t_doorbell"] / 1e9, ev["doorbell_pkt"],
                                        "SQ1 doorbell, device MRd64 for the 64-byte SQE, host never returns CplD; command never completes.",
                                        ["completion_timeout", "nvme_command_never_completed"], command=ev))
                elif fid == "F4":
                    fault_unsupported_request(w, m, faults)
                elif fid == "F5":
                    ev = m.command(3, 1, nlb=16, fault="F5_malformed")
                    faults.append(Fault("F5", "Malformed TLP (Length vs payload / Max_Payload_Size)", "Transaction", ev["t_doorbell"] / 1e9,
                                        ev.get("fault_pkt", ev["doorbell_pkt"]),
                                        "Downstream CplD for the write data of SQ3 CID %d has Length=65 DW (260 B) with a 256 B payload; "
                                        "260 B also exceeds Max_Payload_Size 256." % ev["cid"], ["malformed_tlp"], command=ev))
                elif fid == "F6":
                    ev = m.command(4, 2, nlb=8, fault="F6_poisoned")
                    faults.append(Fault("F6", "Poisoned data TLP (EP=1)", "Transaction", ev["t_doorbell"] / 1e9, ev.get("fault_pkt", ev["doorbell_pkt"]),
                                        "First upstream MWr64 data TLP of Read SQ4 CID %d has EP=1." % ev["cid"], ["poisoned_tlp"], command=ev))
                elif fid == "F7":
                    fault_flow_control_stall(w, m, faults)
                elif fid == "F8":
                    cmd_log.append(fault_aspm_l1(w, m, faults))
                elif fid == "F9":
                    ev = m.command(1, 1, nlb=32, device_delay_ns=12_400_000, fault="F9_slow_cmd")
                    faults.append(Fault("F9", "Slow NVMe Write (12.4 ms device-side) with a clean link", "Device Firmware", ev["t_doorbell"] / 1e9,
                                        ev["doorbell_pkt"], "Write SQ1 CID %d: all PCIe phases normal, 12.4 ms between the last CplD and the CQE, "
                                        "no link event in between." % ev["cid"], ["slow_nvme_command"], command=ev))
                elif fid == "F10":
                    fault_link_recovery_downshift(w, faults)
        qid = rnd.choice([1, 2, 3, 4])
        opc = rnd.choices([2, 1, 0], weights=[6, 3, 1])[0]
        nlb = rnd.choice([1, 8, 8, 16, 32]) if opc else 0
        ev = m.command(qid, opc, nlb=nlb, device_delay_ns=rnd.randint(55_000, 110_000))
        if rnd.random() < 0.01:
            cmd_log.append(ev)
        if rnd.random() < 0.10:
            w.update_fc(rnd.choice(["Upstream", "Downstream"]), rnd.choice(["NP", "Cpl"]))
        if rnd.random() < 0.10:
            w.skp(rnd.choice(["Upstream", "Downstream"]))
        if time.time() - last_report > 15:
            last_report = time.time()
            print(f"  {w.n:,} rows, {w.size() / 1e9:.2f} GB, {time.time() - t_start:.0f}s", flush=True)
    w.close()
    meta = {"generator": "stage1_research/generate_synthetic_trace.py", "seed": seed, "rows": w.n, "bytes": os.path.getsize(path),
            "columns": COLUMNS, "bar0": f"0x{BAR0:X}", "faults": [f.__dict__ for f in faults], "sample_commands": cmd_log[:50]}
    with open(os.path.join(out_dir, "injected_faults.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    print(f"wrote {path}: {w.n:,} rows, {os.path.getsize(path) / 1e9:.3f} GB, {len(faults)} injected faults, {time.time() - t_start:.0f}s")
    return path


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "data", "samples"))
    ap.add_argument("--rows", type=int, default=None)
    ap.add_argument("--size-gb", type=float, default=None)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    generate(a.out, a.rows, a.size_gb, a.seed)
