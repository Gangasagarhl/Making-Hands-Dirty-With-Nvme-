"""Stage 2 / Substage 2.2 - rule engine: observations -> findings, each justified by a specification
expectation (PCIe Base Spec 4.0 / 5.0, NVMe Base Spec 2.0, Teledyne analyzer error classes).

Each Finding carries:
  * what was observed (with packet numbers = CSV 'Packet' column = line in the export)
  * what the spec expects (X) and what was measured (X+Y) with Y attributed to a cause
  * which NVMe command / TLP / DLLP is responsible
  * a fix hypothesis and a hint for the test case generator
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, asdict
from collections import defaultdict

# --------------------------------------------------------------------------- spec reference values
SPEC = {
    "completion_timeout": {
        "value": "50 us .. 50 ms (default range when the Completion Timeout Value field is not programmed); "
                 "Range A 50us-10ms, B 10-250ms, C 250ms-4s, D 4-64s",
        "ref": "PCIe Base Spec 4.0 §2.8 Completion Timeout Mechanism; Device Control 2 register",
    },
    "updatefc_interval": {
        "value": "UpdateFC must be scheduled at least every 30 us (34 us with extended synch) while credits are "
                 "not infinite; typical implementations send every few us",
        "ref": "PCIe Base Spec 4.0 §2.6.1.2 Flow Control Rules (UpdateFC transmission latency)",
    },
    "ack_latency_gen4_x4": {
        "value": "Ack transmission latency limit for 16 GT/s x4, max payload 256B ~ 0.5-1.1 us; "
                 "REPLAY_TIMER = 3x Ack latency limit (approx 1.5-3.5 us)",
        "ref": "PCIe Base Spec 4.0 §3.5.3.1 Table 3-7/3-8 (Ack Transmission Latency, Replay Timer limits)",
    },
    "replay_num": {"value": "REPLAY_NUM rolls over after 4 replays -> link retraining (Recovery)",
                   "ref": "PCIe Base Spec 4.0 §3.5.2.1"},
    "l1_exit_latency": {
        "value": "Endpoint advertises L1 Exit Latency (Link Capabilities[17:15]): <1us .. >64us; L1.2 adds "
                 "T_POWER_ON + T_COMMONMODE. Host LTR / ASPM policy must tolerate it.",
        "ref": "PCIe Base Spec 4.0 §5.4.1.2 ASPM L1, §7.5.3.6 Link Capabilities, L1 PM Substates ECN",
    },
    "l0_to_recovery": {"value": "Recovery must complete in 24 ms (Recovery.RcvrLock timeout) - normal exit ~ 1-10 us",
                       "ref": "PCIe Base Spec 4.0 §4.2.6.4 Recovery"},
    "malformed_tlp": {"value": "Length vs Byte Count / payload mismatch, bad TC/Attr, undefined type => Malformed TLP "
                               "(Fatal, uncorrectable). Receiver discards the TLP.",
                      "ref": "PCIe Base Spec 4.0 §2.2.8.6 / §6.2.3 Error classification"},
    "poisoned_tlp": {"value": "EP=1 marks data as corrupt; completer logs Poisoned TLP Received (non-fatal uncorrectable)",
                     "ref": "PCIe Base Spec 4.0 §2.7.2 Data Poisoning"},
    "unsupported_request": {"value": "Cpl with status UR: request type/address not supported by the completer",
                            "ref": "PCIe Base Spec 4.0 §2.3.1 Request Handling Rules"},
    "lcrc": {"value": "Bad LCRC -> receiver sends Nak -> transmitter replays from NAK seq+1. Correctable error "
                      "(Bad TLP / Bad DLLP in Correctable Error Status)",
             "ref": "PCIe Base Spec 4.0 §3.5.3 / §3.6.2"},
    "receiver_error": {"value": "8b/10b / 128b/130b decode, framing, disparity, invalid symbol => Receiver Error "
                                "(correctable); repeated errors trigger Recovery and possibly speed downshift",
                       "ref": "PCIe Base Spec 4.0 §4.2.4.7 / §6.2.3"},
    "gen4_x4_bandwidth": {"value": "16 GT/s x4 = 63 Gbit/s raw, ~7.88 GB/s per direction after 128b/130b; "
                                   "Gen3 x4 = ~3.94 GB/s",
                          "ref": "PCIe Base Spec 4.0 §4.2.2"},
    "nvme_latency": {"value": "NVMe specification defines no per-command time budget; the host driver timeout is "
                              "typically 30 s (Linux nvme_io_timeout). Expectation X = the device's own steady-state "
                              "median for that opcode and transfer size; Y = measured - X must be explained by trace events.",
                     "ref": "NVMe Base Spec 2.0 §3.3 Queueing model, §3.4 Command processing; Linux nvme core"},
    "nvme_flow": {"value": "SQ tail doorbell (MWr) -> controller fetches SQE (MRd) -> data PRP/SGL transfers -> CQE "
                           "(MWr to CQ) -> MSI-X (MWr) -> CQ head doorbell (MWr)",
                  "ref": "NVMe Base Spec 2.0 §3.3.1 / NVMe over PCIe Transport Spec §3"},
}

SEVERITY_NAME = {1: "info", 2: "low", 3: "medium", 4: "high", 5: "critical"}


@dataclass
class Finding:
    id: str
    kind: str
    layer: str
    severity: int
    title: str
    observed: str
    expected: str
    spec_ref: str
    why: str
    evidence_packets: list = field(default_factory=list)
    affected_command: dict = field(default_factory=dict)
    timing: dict = field(default_factory=dict)      # expected_us, observed_us, extra_us, attributed_to
    fix_hypothesis: str = ""
    test_hint: str = ""
    count: int = 1
    t_first_s: float = math.nan
    source_file: str = ""

    def to_dict(self):
        d = asdict(self)
        d["severity_name"] = SEVERITY_NAME[self.severity]
        return d


LAYER_OF = {
    "lcrc_error": "Data Link", "ecrc_error": "Transaction", "nak": "Data Link", "replay": "Data Link", "replayed_tlp": "Data Link",
    "replay_timer_timeout": "Data Link", "link_down": "Physical", "hot_reset": "Physical",
    "flow_control_stall": "Data Link", "updatefc_gap": "Data Link",
    "completion_timeout": "Transaction", "unsupported_request": "Transaction", "malformed_tlp": "Transaction",
    "poisoned_tlp": "Transaction", "unexpected_completion": "Transaction", "completion_status_ur": "Transaction",
    "completion_status_ca": "Transaction", "completion_status_crs": "Transaction",
    "receiver_error": "Physical", "speed_change": "Physical", "width_change": "Physical", "ltssm_recovery": "Physical",
    "pm_l1_request": "Power Management", "l1_exit_latency": "Power Management", "pm_l23": "Power Management",
    "slow_nvme_command": "NVMe / Device", "nvme_error_status": "NVMe / Device",
    "nvme_command_never_completed": "NVMe / Transaction",
}


def _nearest_before(items, t, key="t_s", window_s=0.001):
    """items sorted by t; return those within window_s before t"""
    out = []
    for it in items:
        if t - window_s <= it[key] <= t:
            out.append(it)
    return out


def build_findings(det: dict, source_file: str) -> list[Finding]:
    anoms = det["anomalies"]
    findings: list[Finding] = []
    by_kind: dict[str, list] = defaultdict(list)
    for a in anoms:
        by_kind[a["kind"]].append(a)

    fid = 0

    def new(kind, sev, title, observed, spec_key, why, pkts, **kw) -> Finding:
        nonlocal fid
        fid += 1
        spec = SPEC[spec_key]
        f = Finding(id=f"{source_file[:3].upper()}-{fid:03d}", kind=kind, layer=LAYER_OF.get(kind, "Unknown"), severity=sev,
                    title=title, observed=observed, expected=spec["value"], spec_ref=spec["ref"], why=why,
                    evidence_packets=sorted(set(int(p) for p in pkts if p is not None and p >= 0))[:40], source_file=source_file, **kw)
        findings.append(f)
        return f

    # ---- link layer: LCRC / NAK / replay (group into one finding with occurrence count)
    lcrc = by_kind.get("lcrc_error", []) + by_kind.get("ecrc_error", [])
    naks = by_kind.get("nak", [])
    replays = by_kind.get("replay", []) + by_kind.get("replayed_tlp", [])
    if lcrc or naks or replays:
        pk = [a["pkt"] for a in lcrc[:10]] + [a["pkt"] for a in naks[:10]] + [a["pkt"] for a in replays[:10]]
        sev = 4 if len(lcrc) + len(naks) > 10 else 3
        new("lcrc_error", sev, f"LCRC errors / NAK / replay sequence ({len(lcrc)} LCRC, {len(naks)} NAK, {len(replays)} replay events)",
            f"TLPs with bad LCRC were NAKed by the receiver and replayed by the transmitter. First at packet #{pk[0]}.",
            "lcrc", "A bad LCRC means the TLP was corrupted on the wire. One or two per GB of traffic can be marginal "
            "signal integrity; a burst indicates equalization/preset or a bad lane. Each event costs ~1-2 us of link time "
            "and the Teledyne 'Number of Packets' metric for that link transaction rises above 2.",
            pk, count=len(lcrc) + len(naks),
            t_first_s=min(a["t_s"] for a in (lcrc + naks + replays)),
            timing={"extra_us_per_event": "1-2", "attributed_to": "link-level retry (DLLP Nak + TLP replay)"},
            fix_hypothesis="Run lane margining / check Tx presets for the upstream (SSD->host) direction; check "
                           "connector/riser; compare error rate at Gen3 vs Gen4.",
            test_hint="Teledyne trigger on DLLP Nak; sustained 128K sequential read with fio; pass if 0 Nak per 10 GB")

    rt = by_kind.get("replay_timer_timeout", [])
    if rt:
        new("replay_timer_timeout", 4, f"REPLAY_TIMER expiry - Ack starvation ({len(rt)}x)",
            f"The transmitter's replay timer expired because no Ack arrived for outstanding TLPs (first at packet #{rt[0]['pkt']}); "
            "all unacknowledged TLPs were replayed.",
            "ack_latency_gen4_x4", "The receiving side (here the host root complex) must return Ack within the Ack latency limit. "
            "Starvation usually comes from the RC prioritising completions/UpdateFC over Ack (cf. NXP A-011451 erratum class of bugs). "
            "The SSD is the victim, not the cause, unless the replayed TLPs originated from the host.",
            [a["pkt"] for a in rt[:10]], count=len(rt), t_first_s=rt[0]["t_s"],
            timing={"extra_us_per_event": "3-6", "attributed_to": "REPLAY_TIMER expiry + retransmission of the replay buffer"},
            fix_hypothesis="Check the host's Ack scheduling / Ack latency settings; verify SSD ack-latency timer values against Table 3-7; "
                           "if replays originate from the host, inspect SSD Ack generation.",
            test_hint="Trigger on 'Replay Timer Timeout'; heavy mixed read/write with queue depth 32 on 4 queues; pass if 0 replays")

    # ---- flow control
    fc = by_kind.get("flow_control_stall", [])
    gaps = det.get("max_updatefc_gap_us", {})
    worst_gap_dir = max(gaps, key=gaps.get) if gaps else None
    if fc:
        pk = [a["pkt"] for a in fc[:10]] + [a["details"].get("updatefc_pkt") for a in fc[:10] if a.get("details", {}).get("updatefc_pkt")]
        worst = max(fc, key=lambda a: a["details"].get("stalled_us", 0))
        new("flow_control_stall", 4 if worst["details"].get("stalled_us", 0) > 30 else 3,
            f"Flow-control stall: posted credits exhausted, UpdateFC-P {worst['details'].get('stalled_us', '?')} us late ({len(fc)}x)",
            "; ".join(a["summary"] for a in fc[:3]),
            "updatefc_interval", "When the receiver's posted buffers are full the transmitter must hold its MWr TLPs. If the receiver "
            "does not return UpdateFC quickly (spec: at most every 30 us) the link idles with data pending. The SSD's "
            "read-data MWr stream stalls and every in-flight Read command gets longer.",
            pk, count=max(1, len(fc)), t_first_s=fc[0]["t_s"] if fc else math.nan,
            timing={"extra_us_per_event": worst["details"].get("stalled_us"),
                    "attributed_to": "receiver flow-control credit return (UpdateFC-P) latency"},
            fix_hypothesis="Increase RC posted receive buffer / credits, or fix UpdateFC scheduling on the receiver; on the SSD "
                           "side verify it advertises realistic InitFC credits.",
            test_hint="Trigger on UpdateFC gap > 30 us (timing trigger); 128K QD32 random read; pass if max UpdateFC gap < 30 us")

    # ---- transaction layer
    for kind, spec_key, sev, title, why, fix, th in (
        ("completion_timeout", "completion_timeout", 5, "Completion Timeout - request never (or too late) completed",
         "A non-posted request (MRd/CfgRd) must be completed within the Completion Timeout range. When the host never "
         "returns CplD for the SSD's SQE fetch or PRP data read, the NVMe command can never complete and the host driver "
         "will eventually abort/reset the controller (30 s timeout). Typical causes: IOMMU/DMA mapping fault, bad PRP "
         "pointer in the SQE, RC completer error.",
         "Dump the SQE PRP1/PRP2 of the affected CID; check IOMMU fault logs on the host; verify the address range is mapped; "
         "check the RC AER Uncorrectable status for Completion Timeout.",
         "Trigger on 'Completion Timeout'; issue the same opcode/LBA/size with nvme-cli; pass if every MRd gets CplD < 10 ms"),
        ("unsupported_request", "unsupported_request", 3, "Unsupported Request completion",
         "The completer answered with status UR: the request targeted a register/address it does not implement. "
         "Harmless if it is a probe, a driver bug if it is on the I/O path.",
         "Compare the address with the controller's register map (NVMe BAR0 offsets); fix the driver/firmware offset.",
         "Read the same BAR offset with setpci/devmem; expect UR status exactly once; pass if no UR during I/O"),
        ("malformed_tlp", "malformed_tlp", 5, "Malformed TLP",
         "Header fields are inconsistent (e.g. Length vs Byte Count, bad format/type). The receiver must discard the "
         "TLP and report a fatal error; the DMA transfer silently loses data and the NVMe command either hangs or completes with stale data.",
         "Inspect the SSD DMA/PRP engine for the opcode and transfer size that produced the TLP; check 4 KB boundary "
         "crossing and Max_Read_Request_Size handling.",
         "Reproduce the exact transfer size/alignment with fio (bs=, offset=); trigger on 'Malformed TLP'; pass if none"),
        ("poisoned_tlp", "poisoned_tlp", 4, "Poisoned TLP (EP=1) in data stream",
         "The SSD marked data as corrupt (EP bit). This is the device telling the host 'internal data integrity failure' "
         "(ECC, DRAM parity, end-to-end protection).",
         "Check SSD SMART/health log (media errors, error log page 0x01); check end-to-end protection settings; "
         "firmware ECC path.",
         "Trigger on 'Poisoned TLP'; re-read the same LBA range; pass if EP=0 on all data TLPs"),
        ("unexpected_completion", "completion_timeout", 3, "Unexpected Completion (no matching request)",
         "A completion arrived whose tag has no open request: either the request was lost/dropped (so a Completion "
         "Timeout will follow), or the tag was reused too early (tag management bug).",
         "Verify tag allocation (Extended Tag / 10-bit tag enable) matches between RC and SSD.",
         "Trigger on 'Unexpected Completion'; QD64 read workload; pass if none"),
    ):
        items = by_kind.get(kind, []) + [a for k, v in by_kind.items() if k.startswith("completion_status_" + kind[:2]) for a in v] \
            if kind in ("unsupported_request",) else by_kind.get(kind, [])
        if kind == "unsupported_request":
            items = by_kind.get("unsupported_request", []) + by_kind.get("completion_status_ur", [])
        n_items = len(items)
        if kind == "completion_timeout":
            items = items + by_kind.get("nvme_command_never_completed", [])
        if not items:
            continue
        pk = [a["pkt"] for a in items[:12]] + [a.get("details", {}).get("request_pkt") for a in items[:12]
                                               if a.get("details", {}).get("request_pkt")]
        obs = "; ".join(a["summary"] for a in items[:3])
        if kind == "completion_timeout" and len(items) > n_items:
            obs += f" ({n_items} timed-out request(s); the NVMe command(s) that depended on them are listed as never completed)"
        cmd = {}
        for a in items:
            d = a.get("details", {})
            if d.get("qid") is not None:
                cmd = {"qid": f"SQ{d.get('qid')}", "cid": d.get("cid"), "opcode": d.get("opc"), "doorbell_pkt": d.get("doorbell_pkt"),
                       "sqe_fetch_pkt": d.get("sqe_fetch_pkt"), "tag": d.get("tag")}
                break
        new(kind, sev, f"{title} ({n_items or len(items)}x)", obs, spec_key, why, pk, count=n_items or len(items),
            t_first_s=items[0]["t_s"], affected_command=cmd, fix_hypothesis=fix, test_hint=th)

    # ---- physical layer
    rx = by_kind.get("receiver_error", [])
    sc = [a for a in by_kind.get("speed_change", []) if a["severity"] >= 4]
    rec = by_kind.get("ltssm_recovery", [])
    if rx:   # only Recovery entries after the first physical-layer error are suspicious (training ones are normal)
        rec = [a for a in rec if a["t_s"] >= rx[0]["t_s"]]
    else:
        rec = []
    if rx or sc:
        pk = [a["pkt"] for a in rx[:10]] + [a["pkt"] for a in sc[:5]] + [a["pkt"] for a in rec[:5]]
        new("receiver_error", 4 if sc else 3,
            "Physical layer errors" + (" followed by link Recovery and speed downshift" if sc else ""),
            "; ".join(a["summary"] for a in (rx[:2] + sc[:2])),
            "receiver_error", "Invalid symbols / framing errors are decode failures on the receiver. After repeated errors the LTSSM "
            "enters Recovery; if the link partner cannot re-lock at 16 GT/s it falls back to 8 GT/s, halving bandwidth "
            "(all later commands are slower - compare 'All link speeds' vs 'Gen4 x4' export row counts).",
            pk, count=len(rx) + len(sc), t_first_s=(rx + sc)[0]["t_s"],
            timing={"attributed_to": "LTSSM Recovery (~us) + permanent bandwidth loss after downshift"},
            fix_hypothesis="Signal integrity: check Rx/Tx equalization presets, lane margining results, cabling/riser, "
                           "and the Link Status register (Current Link Speed) after the event.",
            test_hint="Trigger on 'Link Speed Change'; 10-minute sequential read; pass if speed stays 16 GT/s and 0 Receiver Errors")

    # ---- power management: L1 exit latency and the first command after idle
    l1 = by_kind.get("l1_exit_latency", [])
    if l1:
        worst = max(l1, key=lambda a: a["details"].get("exit_latency_us", 0))
        d = worst["details"]
        after = [c for c in det.get("commands_after_l1", []) if c.get("l1", {}).get("enter_pkt") == d.get("enter_pkt")]
        cmd_info = {}
        cmd_timing = {}
        if after:
            c = after[0]
            cmd_info = {"qid": f"SQ{c['qid']}", "cid": c["cid"], "opcode": c["opc"], "doorbell_pkt": c["doorbell_pkt"],
                        "cqe_pkt": c["cqe_pkt"], "phases_us": c["phases_us"], "bytes": c.get("bytes")}
            cmd_timing = {"expected_us (X = median)": c.get("median_us"), "observed_us": c.get("latency_us"),
                          "extra_us_in_command": c.get("extra_us"), "l1_exit_wait_before_doorbell_us": d.get("exit_latency_us"),
                          "total_Y_us": round((c.get("extra_us") or 0) + (d.get("exit_latency_us") or 0), 3)}
        cmd_note = ""
        if after:
            c = after[0]
            cmd_note = (f" The first command after the exit ({c['opc']} SQ{c['qid']} CID {c['cid']}, doorbell #{c['doorbell_pkt']}, CQE #{c['cqe_pkt']}) "
                        f"has a normal doorbell-to-CQE span of {c.get('latency_us')} us (median {round(c.get('median_us') or 0, 1)} us): the extra time Y is NOT inside "
                        f"the command, it is the {d.get('exit_latency_us')} us the host had to wait BEFORE the doorbell could be transmitted "
                        f"(from host-visible submission to CQE the command therefore took about {round((c.get('latency_us') or 0) + (d.get('exit_latency_us') or 0), 1)} us).")
        new("l1_exit_latency", 4 if d.get("exit_latency_us", 0) > 20 else 2,
            f"ASPM L1 exit latency {d.get('exit_latency_us')} us before the first command after idle ({len(l1)} L1 cycles)",
            f"PM L1 request/ack put the link into L1 at packet #{d.get('enter_pkt')} (residency {d.get('residency_ms')} ms). "
            f"Exit started at #{d.get('exit_start_pkt')} and the link was back in L0 only at #{d.get('exit_done_pkt')} "
            f"({d.get('exit_latency_us')} us)." + cmd_note,
            "l1_exit_latency", "While the link is in L1 no TLP can be sent. The host's doorbell write (and therefore the whole "
            "NVMe command) waits for Recovery to finish. That wait is the 'Y' on top of the normal command time X. "
            "If the measured exit latency exceeds the L1 Exit Latency the endpoint advertises in Link Capabilities, "
            "it is an endpoint PHY/firmware defect; if it is within the advertised value, the host ASPM/LTR policy is too aggressive.",
            [d.get("enter_pkt"), d.get("exit_start_pkt"), d.get("exit_done_pkt"), cmd_info.get("doorbell_pkt"), cmd_info.get("cqe_pkt")],
            count=len(l1), t_first_s=l1[0]["t_s"], affected_command=cmd_info,
            timing={"extra_us": d.get("exit_latency_us"), "attributed_to": "L1 -> Recovery -> L0 (ASPM exit)", **cmd_timing},
            fix_hypothesis="Compare with lspci Link Capabilities L1 exit latency; disable ASPM L1 (pcie_aspm.policy=performance) "
                           "or set LTR so the device does not enter L1.2; fix endpoint PLL/CDR re-lock time.",
            test_hint="Idle 5 ms then single 4K read, 1000 iterations; trigger on PM_Enter_L1; pass if 99th pct latency "
                      "<= median + advertised L1 exit latency")

    # ---- slow NVMe commands (per command, top N) - X vs X+Y attribution
    slow = det.get("nvme", {}).get("slow_commands", [])
    lat_by_opc = det.get("nvme", {}).get("latency_by_opcode_us", {})
    link_events = det.get("link_events", [])
    for c in slow[:10]:
        c = dict(c)
        c["qid"] = f"SQ{c['qid']}"
        c["data_bytes"] = c.get("bytes", 0)
        med = lat_by_opc.get(c["opc"], {}).get("median_us")
        ph = c["phases_us"]
        # which phase holds the extra time?
        phase_items = [(k, v) for k, v in ph.items() if k != "total" and v is not None]
        worst_phase = max(phase_items, key=lambda kv: kv[1]) if phase_items else ("?", 0)
        before = c.get("link_events_before") or []
        extra = (c["latency_us"] - med) if med else None
        if before and any("L1" in str(e) or "PM_" in str(e) for e in before):
            cause = "link was in L1 (ASPM) right before the doorbell - power-management exit latency"
            layer_kind = "l1_exit_latency"
        elif worst_phase[0].startswith("last_data_to_cqe"):
            cause = "device-internal processing between the last data transfer and the CQE (firmware/NAND, no PCIe event in between)"
            layer_kind = "slow_nvme_command"
        elif worst_phase[0] == "data_phase":
            cause = "data phase stretched - look for NAK/replay/flow-control events between the data TLPs"
            layer_kind = "slow_nvme_command"
        elif worst_phase[0].startswith("doorbell_to_sqe_fetch"):
            cause = "controller was slow to fetch the SQE after the doorbell (controller front-end / arbitration / L1 exit)"
            layer_kind = "slow_nvme_command"
        else:
            cause = f"host completion latency in phase '{worst_phase[0]}' (RC / memory subsystem)"
            layer_kind = "slow_nvme_command"
        f = new(layer_kind, 4 if c["latency_us"] > 5000 else 3,
                f"Slow NVMe {c['opc']} {c['qid']} CID {c['cid']}: {c['latency_us']:.1f} us"
                + (f" (median {med:.1f} us, +{extra:.1f} us)" if med else ""),
                f"Doorbell at packet #{c['doorbell_pkt']}, CQE at #{c['cqe_pkt']}. Phase breakdown (us): {ph}. "
                f"Longest phase: {worst_phase[0]} = {worst_phase[1]} us.",
                "nvme_latency", f"X = steady-state median for {c['opc']} ({med} us); Y = {extra:.1f} us sits in phase "
                f"'{worst_phase[0]}'. Cause: {cause}." if med else f"Longest phase '{worst_phase[0]}'. Cause: {cause}.",
                [c["doorbell_pkt"], c["cqe_pkt"]] + [e[0] for e in before if isinstance(e, (list, tuple))],
                affected_command={"qid": c["qid"], "cid": c["cid"], "opcode": c["opc"], "bytes": c["data_bytes"],
                                  "status": c["status"]},
                timing={"expected_us": med, "observed_us": c["latency_us"], "extra_us": extra, "slow_phase": worst_phase[0],
                        "attributed_to": cause},
                fix_hypothesis="Firmware: profile the command path for this opcode/size (GC, flush, write-cache); "
                               "if L1 related see the ASPM finding; if host related check RC completion latency."
                if "device-internal" in cause or "L1" in cause else
                "Inspect the link events listed in evidence between doorbell and CQE.",
                test_hint=f"Replay {c['opc']} on queue {c['qid']} with {c['data_bytes']} bytes at QD1 x 1000; "
                          f"pass if p99 <= 3x median")
        f.t_first_s = math.nan

    # ---- NVMe error status
    ne = by_kind.get("nvme_error_status", [])
    if ne:
        new("nvme_error_status", 4, f"NVMe commands completed with error status ({len(ne)}x)",
            "; ".join(a["summary"] for a in ne[:3]), "nvme_flow",
            "The CQE status field is non-zero. Map SCT/SC to NVMe Base Spec Figure 'Status Code - Generic Command Status'.",
            [a["pkt"] for a in ne[:12]], count=len(ne), t_first_s=ne[0]["t_s"],
            fix_hypothesis="Decode SCT/SC; check Error Information Log (log page 0x01).",
            test_hint="Re-issue the same opcode with nvme-cli io-passthru; pass if status 0")

    # ---- idle gaps (information)
    gaps = det.get("idle_gaps", [])
    big = [g for g in gaps if g["gap_us"] > 1000]
    if big:
        new("idle_gap", 1, f"Link idle gaps > 1 ms ({len(big)}x, longest {big[0]['gap_us']:.0f} us)",
            f"Longest silence ends at packet #{big[0]['pkt']} with {big[0]['next_packet']}.", "nvme_latency",
            "Idle gaps are only a problem when a command is outstanding across them; the LLM pass checks each gap for open commands.",
            [g["pkt"] for g in big[:10]], count=len(big))
    findings.sort(key=lambda f: (-f.severity, f.id))
    return findings
