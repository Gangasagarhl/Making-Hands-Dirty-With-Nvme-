"""Runtime configuration. Everything can be overridden by environment variables or by the
settings panel in the frontend (per job)."""
from __future__ import annotations

import os
from dataclasses import dataclass, asdict

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_dotenv() -> None:
    """Load <project>/.env (KEY=VALUE lines) into the environment without overriding variables already set.
    This is how the API URL / key / model are normally supplied: see .env.example."""
    for name in (".env", "llm.env"):
        p = os.path.join(ROOT_DIR, name)
        if not os.path.isfile(p):
            continue
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k, v = k.strip(), v.strip().strip('"').strip("'")
                if k and k not in os.environ:
                    os.environ[k] = v


_load_dotenv()


def _default_provider() -> str:
    p = os.getenv("LLM_PROVIDER", "").strip().lower()
    if p:
        return p
    url = os.getenv("LLM_BASE_URL", "")
    if os.getenv("LLM_API_KEY"):
        return "anthropic" if "anthropic" in url else "openai"
    return "mock"


@dataclass
class LLMConfig:
    # provider: "openai"    any OpenAI-compatible /chat/completions endpoint (Qwen/DashScope, vLLM, Ollama, OpenRouter...)
    #           "anthropic" Claude Messages API
    #           "claude_cli" local `claude -p` CLI (optional; only if no API key is given and the CLI is installed)
    #           "mock"      offline deterministic - used when nothing is configured so the pipeline still runs
    # Normal configuration = three values: LLM_BASE_URL, LLM_API_KEY, LLM_MODEL (in .env or the environment).
    provider: str = _default_provider()
    base_url: str = os.getenv("LLM_BASE_URL", "")
    api_key: str = os.getenv("LLM_API_KEY", "")
    model: str = os.getenv("LLM_MODEL", "")
    # Total context window of the model. 28k for the user's Qwen deployment.
    context_tokens: int = int(os.getenv("LLM_CONTEXT_TOKENS", "28000"))
    # Reserved for the answer (JSON). The rest minus the system prompt is the evidence budget.
    max_output_tokens: int = int(os.getenv("LLM_MAX_OUTPUT_TOKENS", "2500"))
    # Safety margin for tokenizer mismatch (we estimate tokens at ~3.3 chars/token for CSV-like text).
    safety_ratio: float = float(os.getenv("LLM_SAFETY_RATIO", "0.80"))
    temperature: float = float(os.getenv("LLM_TEMPERATURE", "0.1"))
    timeout_s: int = int(os.getenv("LLM_TIMEOUT_S", "180"))
    max_retries: int = int(os.getenv("LLM_MAX_RETRIES", "3"))
    claude_cli_path: str = os.getenv("CLAUDE_CLI_PATH", "")

    def resolve_claude_cli(self) -> str:
        """Find the Claude Code CLI: explicit path, PATH, or the binary bundled with the IDE extension."""
        import glob
        import shutil
        if self.claude_cli_path and os.path.isfile(self.claude_cli_path):
            return self.claude_cli_path
        p = shutil.which(self.claude_cli_path or "claude")
        if p:
            return p
        home = os.path.expanduser("~")
        patterns = [
            os.path.join(home, ".antigravity-ide", "extensions", "anthropic.claude-code-*", "resources", "native-binary", "claude.exe"),
            os.path.join(home, ".vscode", "extensions", "anthropic.claude-code-*", "resources", "native-binary", "claude.exe"),
            os.path.join(home, ".cursor", "extensions", "anthropic.claude-code-*", "resources", "native-binary", "claude.exe"),
            os.path.join(home, ".claude", "local", "claude.exe"),
            os.path.join(home, ".local", "bin", "claude*"),
            os.path.join(home, "AppData", "Roaming", "npm", "claude.cmd"),
        ]
        hits = []
        for pat in patterns:
            hits += glob.glob(pat)
        return sorted(hits)[-1] if hits else "claude"

    def evidence_budget_tokens(self, system_prompt_tokens: int) -> int:
        usable = int(self.context_tokens * self.safety_ratio)
        return max(2000, usable - self.max_output_tokens - system_prompt_tokens)

    def public(self) -> dict:
        d = asdict(self)
        d["api_key"] = "***" if self.api_key else ""
        return d

    def normalize(self) -> "LLMConfig":
        """Make the three user-supplied values robust: provider from the URL/key, URL with or without /v1 or
        /chat/completions, default model names."""
        self.provider = (self.provider or "").strip().lower() or "openai"
        url = (self.base_url or "").strip().rstrip("/")
        if self.provider in ("openai", "anthropic") and not self.api_key:
            self.provider = "mock"
        if self.provider == "openai" and "anthropic.com" in url:
            self.provider = "anthropic"
        if self.provider == "openai":
            for suffix in ("/chat/completions", "/completions"):
                if url.endswith(suffix):
                    url = url[: -len(suffix)]
            if url and not url.endswith("/v1") and "/v" not in url.rsplit("/", 1)[-1] and "compatible-mode" not in url:
                # vLLM / Ollama / OpenRouter / OpenAI all serve under /v1; DashScope compatible-mode already includes it
                url = url + "/v1"
            if not url:
                url = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
            self.model = self.model or "qwen-plus"
        elif self.provider == "anthropic":
            url = url or "https://api.anthropic.com"
            for suffix in ("/v1/messages", "/v1"):
                if url.endswith(suffix):
                    url = url[: -len(suffix)]
            self.model = self.model or "claude-haiku-5-5"
        elif self.provider == "claude_cli":
            self.model = self.model or "haiku"
        self.base_url = url
        return self


@dataclass
class AnalysisConfig:
    chunk_rows: int = int(os.getenv("CSV_CHUNK_ROWS", "250000"))
    # Evidence window: rows before/after an anomaly packet shipped to the LLM, and the overlap kept between
    # neighbouring ranges of one window so a mechanism spanning a cut is never split
    window_before: int = 60
    window_after: int = 90
    window_overlap_rows: int = 25
    # Max LLM windows per job (keeps cost bounded on 3 GB traces; windows are ranked by severity)
    max_llm_windows: int = int(os.getenv("MAX_LLM_WINDOWS", "24"))
    # Slow command detection
    slow_cmd_abs_us: float = 1000.0       # any NVMe command > 1 ms is reported
    slow_cmd_ratio: float = 8.0           # or > 8x the median of its opcode
    top_slow_commands: int = 25
    # Idle gap considered noteworthy (link silent)
    idle_gap_us: float = 500.0


DATA_DIR = os.getenv("PCIE_DATA_DIR", os.path.join(os.path.dirname(os.path.dirname(__file__)), "data"))
JOBS_DIR = os.path.join(DATA_DIR, "jobs")
