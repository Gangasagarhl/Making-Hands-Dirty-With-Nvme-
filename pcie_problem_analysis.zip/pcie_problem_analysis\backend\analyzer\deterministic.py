"""Stage 2 / Substage 2.1 - deterministic streaming pass over the raw Teledyne packet export.

The export has no decode-helper columns, so every observation is derived from protocol content:
  speed/width      <- Link Event text + TS_Data Rate / TS Lane of TS1/TS2 ordered sets
  LCRC/ECRC error  <- "(Bad)" in the LCRC / ECRC cell
  Nak              <- DLLP Type == Nak
  replay           <- TLP re-sent with a PSN already seen in that direction
  replay timeout   <- a replay burst without a preceding Nak within 10 us
  Ack latency      <- time from the newest TLP covered by an Ack to that Ack
  flow control     <- credit accounting: InitFC/UpdateFC-P DataFC (12-bit cumulative limit) vs posted TLP consumption
  poison           <- EP == 1
  UR / CA          <- Cpl Status
  malformed        <- Length > Max_Payload_Size/4 for payload TLPs, or Length*4 != payload bytes present
  completion tmo   <- (requester, tag) open > 50 ms or never completed
  ASPM L1          <- PM_* DLLPs + Link Event L1 Entry/Exit + Recovery ... L0
  NVMe             <- BAR0 learned from CfgWr0 reg 0x10 (or heuristically); doorbells = MWr to BAR0+0x1000..;
                      SQE = 64-byte CplD payload of the controller's MRd (opcode/CID/NSID/PRP1/PRP2/SLBA/NLB);
                      CQE = 16-byte upstream MWr payload (SQHD/SQID/CID/P/status); MSI-X = MWr to 0xFEExxxxx
Memory is constant: chunked pandas read, compact per-chunk vector ops, a Python state machine only for the
rows that carry state (TLPs, Nak/UpdateFC/PM DLLPs, link events, bad ordered sets).
"""
from __future__ import annotations

import math
import os
import re
import statistics
import struct
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from typing import Callable, Optional

import numpy as np
import pandas as pd

from .. import csv_schema
from ..config import AnalysisConfig

NON_POSTED = ("MRd", "IORd", "CfgRd", "IOWr", "CfgWr", "Atomic", "FetchAdd", "Swap", "CAS")
COMPLETION = ("Cpl", "CplD", "CplLk", "CplDLk")
POSTED_DATA = ("MWr", "MsgD")
MAX_PAYLOAD_BYTES = 256
BAD_RE = r"\bbad\b|\berror\b|\binvalid\b|\bfail"


def _is_bad(cell: str) -> bool:
    return bool(re.search(BAD_RE, cell, re.I)) if cell else False
MSIX_LOW, MSIX_HIGH = 0xFEE0_0000, 0xFEF0_0000
NVM_OPC = {0x00: "Flush", 0x01: "Write", 0x02: "Read", 0x04: "Write Uncorrectable", 0x05: "Compare", 0x08: "Write Zeroes",
           0x09: "Dataset Management", 0x0C: "Verify", 0x0D: "Reservation Register", 0x0E: "Reservation Report", 0x19: "Copy"}
ADMIN_OPC = {0x00: "Delete IO SQ", 0x01: "Create IO SQ", 0x02: "Get Log Page", 0x04: "Delete IO CQ", 0x05: "Create IO CQ",
             0x06: "Identify", 0x08: "Abort", 0x09: "Set Features", 0x0A: "Get Features", 0x0C: "Async Event Request",
             0x10: "Firmware Commit", 0x11: "Firmware Image Download", 0x14: "Device Self-test", 0x18: "Keep Alive",
             0x80: "Format NVM", 0x81: "Security Send", 0x82: "Security Receive", 0x84: "Sanitize"}

EVENT_KINDS = (  # lower-case keyword in Link Event text -> anomaly kind, severity
    ("invalid symbol", "receiver_error", 4), ("framing", "receiver_error", 4), ("receiver error", "receiver_error", 4),
    ("disparity", "receiver_error", 4), ("8b/10b", "receiver_error", 4), ("symbol error", "receiver_error", 4),
    ("decode error", "receiver_error", 4), ("elastic buffer", "receiver_error", 3),
    ("speed change", "speed_change", 2), ("width change", "width_change", 2), ("link down", "link_down", 5),
    ("hot reset", "hot_reset", 4), ("recovery entry", "ltssm_recovery", 2), ("l1 entry", "pm_l1_entry", 1),
    ("l1 exit", "pm_l1_exit", 1), ("l2", "pm_l23", 2), ("l23", "pm_l23", 2),
)


@dataclass
class Anomaly:
    kind: str
    pkt: int
    t_s: float
    severity: int
    summary: str
    details: dict = field(default_factory=dict)


@dataclass
class NvmeCmd:
    qid: int
    pkt_doorbell: int
    t_doorbell: float
    cid: int = -1
    opc: str = ""
    nsid: int = 0
    prp1: int = 0
    prp2: int = 0
    slba: int = -1
    nlb: int = 0
    t_sqe_fetch: float = math.nan
    pkt_sqe_fetch: int = -1
    sqe_tag: int = -1
    t_sqe_data: float = math.nan
    pkt_sqe_data: int = -1
    t_first_data: float = math.nan
    t_last_data: float = math.nan
    data_tlps: int = 0
    data_bytes: int = 0
    t_cqe: float = math.nan
    pkt_cqe: int = -1
    status: int = -1
    link_events_before: list = field(default_factory=list)
    after_l1: Optional[dict] = None

    def latency_us(self):
        return math.nan if (math.isnan(self.t_doorbell) or math.isnan(self.t_cqe)) else (self.t_cqe - self.t_doorbell) * 1e6

    def phases_us(self):
        def d(a, b):
            return None if (a != a or b != b) else round((b - a) * 1e6, 3)
        last = self.t_last_data if self.t_last_data == self.t_last_data else self.t_sqe_data
        return {"doorbell_to_sqe_fetch": d(self.t_doorbell, self.t_sqe_fetch),
                "sqe_fetch_to_sqe_data": d(self.t_sqe_fetch, self.t_sqe_data),
                "sqe_data_to_first_data": d(self.t_sqe_data, self.t_first_data),
                "data_phase": d(self.t_first_data, self.t_last_data),
                "last_data_to_cqe (device internal)": d(last, self.t_cqe),
                "total": d(self.t_doorbell, self.t_cqe)}

    def public(self):
        return {"qid": self.qid, "cid": self.cid, "opc": self.opc, "nsid": self.nsid, "slba": self.slba, "nlb": self.nlb,
                "bytes": self.data_bytes, "status": self.status, "latency_us": round(self.latency_us(), 3) if self.latency_us() == self.latency_us() else None,
                "doorbell_pkt": self.pkt_doorbell, "sqe_fetch_pkt": self.pkt_sqe_fetch, "sqe_data_pkt": self.pkt_sqe_data,
                "cqe_pkt": self.pkt_cqe, "phases_us": self.phases_us(), "link_events_before": self.link_events_before,
                "prp1": f"0x{self.prp1:X}", "prp2": f"0x{self.prp2:X}"}


class RunningStats:
    def __init__(self, cap=3000):
        self.n, self.sum, self.min, self.max, self.res, self.cap = 0, 0.0, math.inf, -math.inf, [], cap
        self._rng = np.random.default_rng(1)

    def add(self, x):
        self.n += 1
        self.sum += x
        self.min = min(self.min, x)
        self.max = max(self.max, x)
        if len(self.res) < self.cap:
            self.res.append(x)
        else:
            j = int(self._rng.integers(self.n))
            if j < self.cap:
                self.res[j] = x

    def median(self):
        return statistics.median(self.res) if self.res else math.nan

    def p(self, q):
        if not self.res:
            return math.nan
        s = sorted(self.res)
        return s[min(len(s) - 1, int(q * len(s)))]

    def as_dict(self):
        if not self.n:
            return {"n": 0}
        return {"n": self.n, "min_us": round(self.min, 3), "median_us": round(self.median(), 3), "p95_us": round(self.p(.95), 3),
                "p99_us": round(self.p(.99), 3), "max_us": round(self.max, 3), "mean_us": round(self.sum / self.n, 3)}


def decode_sqe(b: bytes, qid: int) -> dict:
    if len(b) < 64:
        return {}
    cdw0, nsid = struct.unpack_from("<II", b, 0)
    prp1, prp2 = struct.unpack_from("<QQ", b, 24)
    cdw10, cdw11, cdw12 = struct.unpack_from("<III", b, 40)
    opc = cdw0 & 0xFF
    cid = cdw0 >> 16
    name = (ADMIN_OPC if qid == 0 else NVM_OPC).get(opc, f"0x{opc:02X}")
    return {"opc": opc, "name": name, "cid": cid, "nsid": nsid, "prp1": prp1, "prp2": prp2,
            "slba": cdw10 | (cdw11 << 32), "nlb": (cdw12 & 0xFFFF) + 1}


def decode_cqe(b: bytes) -> dict:
    if len(b) < 16:
        return {}
    sqhd, sqid, cid, dw3 = struct.unpack_from("<HHHH", b, 8)
    return {"sqhd": sqhd, "sqid": sqid, "cid": cid, "phase": dw3 & 1, "status": dw3 >> 1}


class DeterministicAnalyzer:
    def __init__(self, cfg: AnalysisConfig, progress: Optional[Callable[[str, float], None]] = None):
        self.cfg = cfg
        self.progress = progress or (lambda m, f: None)
        self.mapping: dict[str, str] = {}
        self.rows = 0
        self.max_pkt = 0
        self.t_first = math.nan
        self.t_last = math.nan
        self._last_t = math.nan
        self.counts_cls = Counter()
        self.counts_ptype = Counter()
        self.counts_dir = Counter()
        self.counts_errors = Counter()
        self.error_examples = defaultdict(list)
        self.anomalies: list[Anomaly] = []
        # link state
        self.speed = "unknown"
        self.width = "unknown"
        self._state_t0 = math.nan
        self._negotiating_rate = ""
        self.speed_width_time = defaultdict(float)
        self.speed_width_rows = Counter()
        self.link_events: list[dict] = []
        self.recent_link_events: deque = deque(maxlen=40)
        self.pm_l1_intervals: list[dict] = []
        self._l1_enter: Optional[tuple] = None
        self._l1_exit_start: Optional[dict] = None
        self._l1_exit_for_next_cmd: Optional[dict] = None
        self.commands_after_l1: list[dict] = []
        self.idle_gaps: list[dict] = []
        # data link
        self.recent_psn = {"Upstream": {}, "Downstream": {}}      # psn -> t (last 128 per direction)
        self.unacked = {"Upstream": deque(), "Downstream": deque()}  # (psn, t)
        self.ack_latency = RunningStats()
        self.last_nak_t = {"Upstream": -1.0, "Downstream": -1.0}
        self.replay_bursts = []
        self.fc = {"Upstream": {"limit": None, "consumed": 0, "stall_since": None, "last_update_t": math.nan},
                   "Downstream": {"limit": None, "consumed": 0, "stall_since": None, "last_update_t": math.nan}}
        self.max_updatefc_gap_us = {"Upstream": 0.0, "Downstream": 0.0}
        # transaction
        self.open_np: dict[tuple, tuple] = {}
        self.cpl_latency = RunningStats()
        self.cpl_latency_by_type = defaultdict(RunningStats)
        self.config_space: list[dict] = []
        # nvme
        self.bar0: Optional[int] = None
        self.db_stride = 4
        self.pending_doorbells: dict[int, deque] = defaultdict(deque)   # qid -> NvmeCmd waiting for SQE fetch/data
        self.fetch_by_tag: dict[int, NvmeCmd] = {}                     # upstream MRd tag -> cmd
        self.open_cmds: dict[tuple, NvmeCmd] = {}                      # (qid, cid) -> cmd
        self.sq_page_to_qid: dict[int, int] = {}
        self.nvme_lat = defaultdict(RunningStats)
        self.nvme_done = 0
        self.nvme_errors = 0
        self.slow_cmds: list[NvmeCmd] = []
        self.cmd_count_by_opc = Counter()
        self._mwr32_down_small = Counter()
        # timeline segments (one per chunk)
        self.segments: list[dict] = []
        self._seg = None

    # ------------------------------------------------------------------ driver
    def run(self, path: str, total_bytes: Optional[int] = None):
        total_bytes = total_bytes or os.path.getsize(path)
        with open(path, "rb") as fh:
            reader = pd.read_csv(fh, chunksize=self.cfg.chunk_rows, dtype=str, keep_default_na=False, on_bad_lines="skip",
                                 engine="c", encoding_errors="replace", usecols=lambda c: True)
            for raw in reader:
                if not self.mapping:
                    self.mapping = csv_schema.detect_mapping(raw.columns)
                    self.missing = csv_schema.missing(self.mapping)
                    self.header = list(raw.columns)
                df = csv_schema.normalize_chunk(raw, self.mapping)
                self._process_chunk(df)
                self.rows += len(df)
                frac = min(0.99, fh.tell() / total_bytes) if total_bytes else 0.5
                self.progress(f"deterministic pass: {self.rows:,} rows ({frac * 100:.0f}% of file)", frac)
        self._finalize()
        return self.result()

    # ------------------------------------------------------------------ chunk
    def _process_chunk(self, df: pd.DataFrame):
        n = len(df)
        if n == 0:
            return
        self.counts_cls.update(df["cls"].value_counts().to_dict())
        self.counts_ptype.update(df["ptype"].value_counts().to_dict())
        self.counts_dir.update(df["dir"].value_counts().to_dict())
        t = df["t_s"].to_numpy()
        valid = ~np.isnan(t)
        if valid.any():
            if math.isnan(self.t_first):
                self.t_first = float(t[valid][0])
            self.t_last = float(t[valid][-1])
        self.max_pkt = max(self.max_pkt, int(df["pkt_n"].max()))
        seg = {"segment": len(self.segments), "first_pkt": int(df["pkt_n"].iloc[0]), "last_pkt": int(df["pkt_n"].iloc[-1]),
               "t_start": float(t[valid][0]) if valid.any() else None, "t_end": float(t[valid][-1]) if valid.any() else None,
               "rows": n, "tlps": int((df["cls"] == "TLP").sum()), "naks": 0, "replays": 0, "bad_lcrc": 0, "errors": 0,
               "nvme_completed": 0, "max_cmd_latency_us": 0.0, "speed": self.speed, "l1_entries": 0, "recovery": 0,
               "cpl_timeouts": 0, "fc_stalls": 0}
        self._seg = seg
        # idle gaps (vectorised)
        prev = np.concatenate(([self._last_t], t[:-1]))
        gaps = (t - prev) * 1e6
        big = np.where(gaps >= self.cfg.idle_gap_us)[0]
        for i in big[:200]:
            if len(self.idle_gaps) < 2000:
                self.idle_gaps.append({"pkt": int(df["pkt_n"].iat[i]), "t_s": float(t[i]), "gap_us": round(float(gaps[i]), 1),
                                       "next_packet": df["ptype"].iat[i], "dir": df["dir"].iat[i]})
        if valid.any():
            if self._state_t0 != self._state_t0:
                self._state_t0 = float(t[valid][0])
            self.speed_width_rows[f"{self.speed} | {self.width}"] += n
            self._last_t = float(t[valid][-1])
        # rows that need the state machine
        cls = df["cls"].to_numpy()
        ptype = df["ptype"].to_numpy()
        lcrc_bad = df["lcrc"].str.contains(BAD_RE, case=False, regex=True).to_numpy()
        ecrc_bad = df["ecrc"].str.contains(BAD_RE, case=False, regex=True).to_numpy()
        need = (cls == "TLP") | (cls == "EVENT") | ((cls == "DLLP") & (ptype != "Ack")) | lcrc_bad | ecrc_bad
        # Acks: vectorised latency is not possible (needs per-PSN state) -> include them but handle cheaply
        need |= (ptype == "Ack")
        # ordered sets with a speed-change / data rate change: include TS rows only when the rate text changes
        rate = df["ts_rate"].to_numpy()
        is_ts = (cls == "OS") & (rate != "")
        if is_ts.any():
            rate_change = np.concatenate(([True], rate[1:] != rate[:-1])) & is_ts
            need |= rate_change
        idx = np.where(need)[0]
        if len(idx) == 0:
            self.segments.append(seg)
            return
        sub = df.iloc[idx]
        cols = ["pkt_n", "t_s", "dir", "cls", "ptype", "psn_n", "acknak_n", "hdrfc_n", "datafc_n", "ep_n", "length_n", "req", "tag_n",
                "cpl", "addr", "register", "status", "bcount_n", "data", "ts_rate", "ts_lane", "link_event", "lcrc", "ecrc"]
        arrays = [sub[c].to_numpy() for c in cols]
        for row in zip(*arrays):
            self._row(*row)
        self.segments.append(seg)

    # ------------------------------------------------------------------ state machine
    def _anom(self, kind, pkt, ts, sev, summary, details=None):
        if len(self.anomalies) < 50000:
            self.anomalies.append(Anomaly(kind, int(pkt), float(ts), sev, summary, details or {}))
        self.counts_errors[kind] += 1
        if len(self.error_examples[kind]) < 25:
            self.error_examples[kind].append(int(pkt))
        if self._seg is not None and kind not in ("pm_l1_entry", "pm_l1_exit", "speed_change", "width_change", "ltssm_recovery",
                                                  "slow_command_after_idle"):
            self._seg["errors"] += 1

    def _row(self, pkt, ts, dirn, cls, ptype, psn, ackseq, hdrfc, datafc, ep, length, req, tag, cpl, addr, register, status,
             bcount, data, ts_rate, ts_lane, link_event, lcrc, ecrc):
        if ts != ts:
            return
        if cls == "TLP":
            self._tlp(pkt, ts, dirn, ptype, psn, ep, length, req, tag, cpl, addr, register, status, bcount, data, lcrc, ecrc)
        elif cls == "DLLP":
            self._dllp(pkt, ts, dirn, ptype, ackseq, hdrfc, datafc)
        elif cls == "EVENT":
            self._event(pkt, ts, dirn, link_event or ptype)
        elif cls == "OS":
            if ts_rate:
                self._ts_rate(pkt, ts, ts_rate, ts_lane)
            if _is_bad(lcrc):
                self._anom("receiver_error", pkt, ts, 4, f"Ordered set {ptype} flagged bad", {})

    # ---- physical / LTSSM
    def _ts_rate(self, pkt, ts, ts_rate, ts_lane):
        r = ts_rate.split("(")[0].strip()
        if ts_lane and "-" in ts_lane:
            try:
                a, b = ts_lane.split("-")
                self._set_width(f"x{int(b) - int(a) + 1}", pkt, ts)
            except Exception:
                pass
        self._negotiating_rate = r
        if self.speed == "unknown" and r:
            self._set_speed(r, pkt, ts)

    def _credit_state_time(self, ts):
        if self._state_t0 == self._state_t0:
            self.speed_width_time[f"{self.speed} | {self.width}"] += max(0.0, ts - self._state_t0)
        self._state_t0 = float(ts)

    def _set_speed(self, speed, pkt, ts):
        if speed != self.speed:
            self._credit_state_time(ts)
            self.speed = speed
            if self._seg is not None:
                self._seg["speed"] = speed

    def _set_width(self, width, pkt, ts):
        if width != self.width:
            self._credit_state_time(ts)
            self.width = width

    def _event(self, pkt, ts, dirn, text):
        low = text.lower()
        ev = {"pkt": int(pkt), "t_s": float(ts), "dir": dirn, "text": text}
        if len(self.link_events) < 5000:
            self.link_events.append(ev)
        self.recent_link_events.append((int(pkt), text))
        if "recovery" in low and "exit" not in low:
            if self._seg is not None:
                self._seg["recovery"] += 1
            self._anom("ltssm_recovery", pkt, ts, 3 if "error" in low else 2, f"LTSSM Recovery: {text}", {})
            if self._l1_exit_start is not None and "recovery_pkt" not in self._l1_exit_start:
                self._l1_exit_start["recovery_pkt"] = int(pkt)
            return
        if "speed change" in low and "recovery" not in low:
            # "Speed Change: 16.0 GT/s -> 8.0 GT/s"  or  "Speed Change to 16.0 GT/s"
            rates = re.findall(r"(\d+(?:\.\d+)?)\s*GT/s", text, re.I)
            new = f"{rates[-1]} GT/s" if rates else self._negotiating_rate or self.speed
            old = f"{rates[0]} GT/s" if len(rates) > 1 else self.speed
            downshift = False
            try:
                downshift = float(new.split()[0]) < float(old.split()[0])
            except Exception:
                pass
            self._set_speed(new, pkt, ts)
            self._anom("speed_change", pkt, ts, 4 if downshift else 2,
                       f"Link speed change {old} -> {new}" + (" (DOWNSHIFT)" if downshift else ""), {"old": old, "new": new, "downshift": downshift})
            return
        if "width change" in low:
            m = re.findall(r"x\d+", low)
            new = m[-1] if m else self.width
            self._set_width(new, pkt, ts)
            self._anom("width_change", pkt, ts, 2, f"Link width change: {text}", {})
            return
        if "l1 entry" in low or ("l1" in low and "entry" in low):
            self._l1_enter = (int(pkt), float(ts))
            if self._seg is not None:
                self._seg["l1_entries"] += 1
            return
        if "l1 exit" in low:
            if self._l1_enter is not None:
                self._l1_exit_start = {"enter_pkt": self._l1_enter[0], "t_enter": self._l1_enter[1], "exit_start_pkt": int(pkt),
                                       "t_exit_start": float(ts), "residency_ms": round((ts - self._l1_enter[1]) * 1e3, 3)}
                self._l1_enter = None
            return
        if ("l0" in low and ("exit" in low or "link up" in low)) and self._l1_exit_start is not None:
            iv = self._l1_exit_start
            iv["exit_done_pkt"] = int(pkt)
            iv["exit_latency_us"] = round((ts - iv["t_exit_start"]) * 1e6, 3)
            self.pm_l1_intervals.append(iv)
            self._anom("l1_exit_latency", pkt, ts, 4 if iv["exit_latency_us"] > 20 else 2,
                       f"L1 exit took {iv['exit_latency_us']} us (L1 residency {iv['residency_ms']} ms; entry #{iv['enter_pkt']}, "
                       f"exit start #{iv['exit_start_pkt']}, L0 at #{pkt})", dict(iv))
            self._l1_exit_for_next_cmd = iv
            self._l1_exit_start = None
            return
        for kw, kind, sev in EVENT_KINDS:
            if kw in low:
                if kind in ("pm_l1_entry", "pm_l1_exit", "ltssm_recovery", "speed_change", "width_change"):
                    break
                self._anom(kind, pkt, ts, sev, f"Link event: {text}", {})
                break

    # ---- data link
    def _dllp(self, pkt, ts, dirn, ptype, ackseq, hdrfc, datafc):
        other = "Downstream" if dirn == "Upstream" else "Upstream"   # Ack/Nak/UpdateFC refer to traffic of the other direction
        if ptype == "Ack":
            q = self.unacked[other]
            newest = None
            while q and self._psn_le(q[0][0], ackseq):
                newest = q.popleft()
            if newest is not None:
                lat = (ts - newest[1]) * 1e6
                self.ack_latency.add(lat)
            return
        if ptype == "Nak":
            self.last_nak_t[other] = ts
            if self._seg is not None:
                self._seg["naks"] += 1
            self._anom("nak", pkt, ts, 3, f"Nak sent {dirn} (last good PSN {ackseq}); the {other} transmitter must replay PSN {(ackseq + 1) & 0xFFF}+",
                       {"ack_seq": int(ackseq)})
            return
        if ptype.startswith("UpdateFC") or ptype.startswith("InitFC"):
            kind = ptype.split("-")[-1] if "-" in ptype else ""
            if kind == "P":
                st = self.fc[other]      # credits granted to the other direction's transmitter
                if ptype.startswith("InitFC"):
                    st["limit"], st["consumed"] = int(datafc) if datafc >= 0 else None, 0
                else:
                    if st["last_update_t"] == st["last_update_t"]:
                        gap = (ts - st["last_update_t"]) * 1e6
                        self.max_updatefc_gap_us[dirn] = max(self.max_updatefc_gap_us[dirn], gap)
                    if datafc >= 0:
                        st["limit"] = int(datafc)
                    if st["stall_since"] is not None:
                        s_pkt, s_t, s_limit, s_consumed, s_avail = st["stall_since"]
                        stalled_us = (ts - s_t) * 1e6
                        if self._seg is not None:
                            self._seg["fc_stalls"] += 1
                        self._anom("flow_control_stall", s_pkt, s_t, 4 if stalled_us > 30 else 3,
                                   f"Posted DataFC credit accounting for the {other} transmitter: advertised limit {s_limit} (12-bit, 16 B units), "
                                   f"consumed {s_consumed} since InitFC -> only {s_avail} credits left after TLP #{s_pkt} (a 256 B TLP needs 16); "
                                   f"the next UpdateFC-P (#{pkt}, new limit {st['limit']}) came {stalled_us:.1f} us later (spec: <= 30 us)",
                                   {"stalled_us": round(stalled_us, 2), "updatefc_pkt": int(pkt), "limit_at_stall": s_limit,
                                    "consumed_at_stall": s_consumed, "credits_left": s_avail, "new_limit": st["limit"]})
                        st["stall_since"] = None
                st["last_update_t"] = ts
            return
        if ptype in ("PM_Enter_L1", "PM_Active_State_Request_L1"):
            self._anom("pm_l1_request", pkt, ts, 2, f"{ptype} sent {dirn}: link requesting L1", {})
            self.recent_link_events.append((int(pkt), ptype))
        elif ptype == "PM_Request_Ack":
            self.recent_link_events.append((int(pkt), ptype))
        elif ptype == "PM_Enter_L23":
            self._anom("pm_l23", pkt, ts, 2, "PM_Enter_L23 - device going to L2/L3", {})

    @staticmethod
    def _psn_le(a, b):
        return ((b - a) & 0xFFF) < 2048

    # ---- transaction layer
    def _tlp(self, pkt, ts, dirn, ptype, psn, ep, length, req, tag, cpl, addr, register, status, bcount, data, lcrc, ecrc):
        seg = self._seg
        # replay detection by PSN reuse
        if psn >= 0:
            rp = self.recent_psn[dirn]
            prev_t = rp.get(psn)
            if prev_t is not None and (ts - prev_t) < 0.5:
                if seg:
                    seg["replays"] += 1
                nak_recent = (ts - self.last_nak_t[dirn]) < 10e-6
                kind = "replayed_tlp" if nak_recent else "replay_timer_timeout"
                self._anom(kind, pkt, ts, 3 if nak_recent else 4,
                           f"{ptype} {dirn} re-sent with PSN {psn} ({(ts - prev_t) * 1e6:.2f} us after the original)"
                           + (" after a Nak" if nak_recent else " with NO Nak in the previous 10 us -> REPLAY_TIMER expiry (Ack starvation)"),
                           {"psn": int(psn), "first_sent_us_before": round((ts - prev_t) * 1e6, 2)})
                return   # replayed copy: do not re-count it as a new request/data
            rp[psn] = ts
            if len(rp) > 256:
                for k in list(rp.keys())[:64]:
                    rp.pop(k, None)
            self.unacked[dirn].append((psn, ts))
            if len(self.unacked[dirn]) > 512:
                self.unacked[dirn].popleft()
        if _is_bad(lcrc):
            if seg:
                seg["bad_lcrc"] += 1
            self._anom("lcrc_error", pkt, ts, 4, f"{ptype} {dirn} PSN {psn} with bad LCRC ({lcrc})", {"psn": int(psn)})
        if _is_bad(ecrc):
            self._anom("ecrc_error", pkt, ts, 4, f"{ptype} {dirn} PSN {psn} with bad ECRC", {"psn": int(psn)})
        if ep == 1:
            self._anom("poisoned_tlp", pkt, ts, 4, f"{ptype} {dirn} with EP=1 (poisoned data) addr {addr}", {"addr": addr})
        payload_tlp = ptype.startswith(POSTED_DATA) or ptype in ("CplD", "CplDLk")
        if payload_tlp and length > MAX_PAYLOAD_BYTES // 4:
            self._anom("malformed_tlp", pkt, ts, 5, f"{ptype} {dirn} Length={length} DW ({length * 4} B) exceeds Max_Payload_Size {MAX_PAYLOAD_BYTES} B",
                       {"length_dw": int(length)})
        elif payload_tlp and data and length > 0:
            nbytes = (len(data) + 1) // 3 if " " in data else len(data) // 2
            if 0 < nbytes < 4096 and nbytes != length * 4 and not data.endswith("..."):
                self._anom("malformed_tlp", pkt, ts, 5, f"{ptype} {dirn} Length={length} DW but {nbytes} payload bytes present",
                           {"length_dw": int(length), "payload_bytes": nbytes})
        # posted credit consumption (receiver side accounting)
        if ptype.startswith(POSTED_DATA):
            st = self.fc[dirn]
            if st["limit"] is not None:
                st["consumed"] = (st["consumed"] + max(1, (length * 4 + 15) // 16)) & 0xFFF
                avail = (st["limit"] - st["consumed"]) & 0xFFF
                if avail < 16 and st["stall_since"] is None:     # fewer credits than one full 256 B TLP left
                    st["stall_since"] = (int(pkt), float(ts), st["limit"], st["consumed"], avail)
        # config space
        if ptype.startswith("Cfg") and len(self.config_space) < 200:
            self.config_space.append({"pkt": int(pkt), "type": ptype, "register": register, "tag": int(tag), "data": data[:11]})
            if ptype.startswith("CfgWr") and register and csv_schema.parse_hex_int(register) == 0x10 and data:
                b = csv_schema.data_bytes(data)
                if len(b) >= 4:
                    val = struct.unpack("<I", b[:4])[0]
                    if val not in (0xFFFFFFFF, 0) and (val & 0xFFFFFFF0):
                        self.bar0 = val & 0xFFFFFFF0
        # non-posted bookkeeping
        if ptype.startswith(NON_POSTED) and tag >= 0:
            prev = self.open_np.get((req, int(tag)))
            if prev is not None:
                age_ms = (ts - prev[1]) * 1e3
                if age_ms > 50:
                    if seg:
                        seg["cpl_timeouts"] += 1
                    self._anom("completion_timeout", prev[0], prev[1], 5,
                               f"{prev[2]} {prev[3]} tag {tag} from {req} (#{prev[0]}) never completed; the tag was reused {age_ms:.1f} ms later at #{pkt}",
                               {"tag": int(tag), "req": req, "reused_at_pkt": int(pkt)})
                else:
                    self._anom("tag_reuse_while_outstanding", pkt, ts, 3,
                               f"{ptype} {dirn} reuses tag {tag} of {req} while #{prev[0]} is still outstanding ({age_ms * 1e3:.1f} us old)",
                               {"tag": int(tag), "prev_pkt": prev[0]})
            self.open_np[(req, int(tag))] = (int(pkt), float(ts), ptype, dirn, 0)
            if dirn == "Upstream" and ptype.startswith("MRd") and length == 16:
                self._nvme_sqe_fetch(pkt, ts, int(tag), addr)
            elif dirn == "Upstream" and ptype.startswith("MRd"):
                self._nvme_data(pkt, ts, addr, length * 4)
        elif ptype.startswith(COMPLETION):
            key = (req, int(tag))
            opened = self.open_np.get(key) if tag >= 0 else None
            if opened is None:
                if tag >= 0:
                    self._anom("unexpected_completion", pkt, ts, 3, f"{ptype} for {req} tag {tag} without an open request", {})
            else:
                pkt0, t0, ptype0, dir0, _ = opened
                # PCIe Byte Count = bytes remaining INCLUDING this completion: keep the request open while more data follows
                if ptype == "CplD" and bcount > 0 and bcount > length * 4:
                    self.open_np[key] = (pkt0, t0, ptype0, dir0, 1)
                else:
                    self.open_np.pop(key, None)
                lat = (ts - t0) * 1e6
                self.cpl_latency.add(lat)
                self.cpl_latency_by_type[ptype0].add(lat)
                if lat > 50_000:
                    if seg:
                        seg["cpl_timeouts"] += 1
                    self._anom("completion_timeout", pkt0, t0, 5, f"{ptype0} tag {tag} (#{pkt0}) completed only after {lat / 1000:.2f} ms", {"cpl_pkt": int(pkt)})
                if ptype.startswith("Cpl") and ptype0.startswith("Cfg"):
                    self.config_space.append({"pkt": int(pkt), "type": "Cpl->" + ptype0, "tag": int(tag), "data": data[:11], "status": status})
                if dirn == "Downstream" and int(tag) in self.fetch_by_tag:
                    self._nvme_sqe_data(pkt, ts, int(tag), data)
                elif dirn == "Downstream" and ptype == "CplD":
                    self._nvme_data(pkt, ts, "", length * 4)
            st = status.upper()
            if st and st not in ("SC", "SUCCESS", "SUCCESSFUL COMPLETION", "0", "000", "0X0"):
                kind = {"UR": "unsupported_request", "CA": "completion_status_ca", "CRS": "completion_status_crs"}.get(st, "completion_status_" + st.lower())
                self._anom(kind, pkt, ts, 4 if st != "CRS" else 2, f"{ptype} {dirn} with Cpl Status {st} for {req} tag {tag}"
                           + (f" (request #{opened[0]} {opened[2]})" if opened else ""), {"request_pkt": opened[0] if opened else None})
        elif ptype.startswith("MWr"):
            if dirn == "Downstream":
                self._nvme_host_write(pkt, ts, addr, length, data)
            else:
                self._nvme_device_write(pkt, ts, addr, length, data)

    # ---- NVMe reconstruction from raw TLPs
    def _doorbell_index(self, a: int) -> int:
        if self.bar0 is None:
            return -1
        off = a - (self.bar0 + 0x1000)
        if 0 <= off < 0x4000 and off % self.db_stride == 0:
            return off // self.db_stride
        return -1

    def _nvme_host_write(self, pkt, ts, addr, length, data):
        a = csv_schema.parse_hex_int(addr)
        if a < 0 or length != 1:
            return
        if self.bar0 is None:
            # heuristic: 4-byte downstream writes cluster inside the controller's BAR; learn the base after a few samples
            self._mwr32_down_small[a & ~0xFFFF] += 1
            if sum(self._mwr32_down_small.values()) >= 50:
                self.bar0 = self._mwr32_down_small.most_common(1)[0][0]
            else:
                return
        idx = self._doorbell_index(a)
        if idx < 0:
            return
        qid, is_cq = idx // 2, idx % 2
        if is_cq:
            return
        cmd = NvmeCmd(qid=qid, pkt_doorbell=int(pkt), t_doorbell=float(ts))
        if self.recent_link_events:
            cmd.link_events_before = list(self.recent_link_events)[-6:]
            self.recent_link_events.clear()
        if self._l1_exit_for_next_cmd is not None:
            cmd.after_l1 = self._l1_exit_for_next_cmd
            self._l1_exit_for_next_cmd = None
        q = self.pending_doorbells[qid]
        q.append(cmd)
        if len(q) > 512:
            q.popleft()

    def _nvme_sqe_fetch(self, pkt, ts, tag, addr):
        a = csv_schema.parse_hex_int(addr)
        page = a & ~0xFFF
        qid = self.sq_page_to_qid.get(page)
        cand = None
        if qid is not None and self.pending_doorbells.get(qid):
            for c in self.pending_doorbells[qid]:
                if c.t_sqe_fetch != c.t_sqe_fetch:
                    cand = c
                    break
        if cand is None:   # oldest unfetched doorbell on any queue
            best = None
            for q, dq in self.pending_doorbells.items():
                for c in dq:
                    if c.t_sqe_fetch != c.t_sqe_fetch and (best is None or c.t_doorbell < best.t_doorbell):
                        best = c
                        break
            cand = best
        if cand is None:
            return
        cand.t_sqe_fetch, cand.pkt_sqe_fetch, cand.sqe_tag = float(ts), int(pkt), tag
        self.sq_page_to_qid[page] = cand.qid
        self.fetch_by_tag[tag] = cand
        if len(self.fetch_by_tag) > 1024:
            self.fetch_by_tag.pop(next(iter(self.fetch_by_tag)))

    def _expire_stale(self, ts):
        for qid, dq in self.pending_doorbells.items():
            while dq and dq[0].t_sqe_fetch == dq[0].t_sqe_fetch and dq[0].t_sqe_data != dq[0].t_sqe_data and (ts - dq[0].t_sqe_fetch) > 0.010:
                stale = dq.popleft()
                self.fetch_by_tag.pop(stale.sqe_tag, None)
                self._anom("nvme_command_never_completed", stale.pkt_doorbell, stale.t_doorbell, 5,
                           f"NVMe SQ{stale.qid} doorbell #{stale.pkt_doorbell}: SQE fetch MRd64 #{stale.pkt_sqe_fetch} (tag {stale.sqe_tag}) "
                           f"never received its CplD ({(ts - stale.t_sqe_fetch) * 1e3:.1f} ms) - the command can never start",
                           {"doorbell_pkt": stale.pkt_doorbell, "sqe_fetch_pkt": stale.pkt_sqe_fetch, "qid": stale.qid, "tag": stale.sqe_tag})

    def _nvme_sqe_data(self, pkt, ts, tag, data):
        cmd = self.fetch_by_tag.pop(tag, None)
        if cmd is None:
            return
        self._expire_stale(ts)
        sqe = decode_sqe(csv_schema.data_bytes(data), cmd.qid)
        dq = self.pending_doorbells.get(cmd.qid)
        if dq and cmd in dq:
            dq.remove(cmd)
        cmd.t_sqe_data, cmd.pkt_sqe_data = float(ts), int(pkt)
        if sqe:
            cmd.cid, cmd.opc, cmd.nsid, cmd.prp1, cmd.prp2, cmd.slba, cmd.nlb = sqe["cid"], sqe["name"], sqe["nsid"], sqe["prp1"], sqe["prp2"], sqe["slba"], sqe["nlb"]
        else:
            cmd.opc = "?"
        self.open_cmds[(cmd.qid, cmd.cid)] = cmd
        self.cmd_count_by_opc[cmd.opc] += 1
        if len(self.open_cmds) > 4096:
            self.open_cmds.pop(next(iter(self.open_cmds)))

    def _nvme_data(self, pkt, ts, addr, nbytes):
        if not self.open_cmds:
            return
        cmd = None
        if addr:
            a = csv_schema.parse_hex_int(addr)
            page = a & ~0xFFF
            for c in self.open_cmds.values():
                if page in ((c.prp1 & ~0xFFF), (c.prp2 & ~0xFFF)) and c.prp1:
                    cmd = c
                    break
        if cmd is None:
            cmd = next(reversed(self.open_cmds.values()))
        if cmd.t_first_data != cmd.t_first_data:
            cmd.t_first_data = float(ts)
        cmd.t_last_data = float(ts)
        cmd.data_tlps += 1
        cmd.data_bytes += nbytes

    def _nvme_device_write(self, pkt, ts, addr, length, data):
        a = csv_schema.parse_hex_int(addr)
        if MSIX_LOW <= a < MSIX_HIGH:
            return
        if length == 4 and data:
            cqe = decode_cqe(csv_schema.data_bytes(data))
            if cqe:
                cmd = self.open_cmds.pop((cqe["sqid"], cqe["cid"]), None)
                if cmd is not None:
                    self._nvme_complete(cmd, pkt, ts, cqe)
                    return
        self._nvme_data(pkt, ts, addr, length * 4)

    def _nvme_complete(self, cmd: NvmeCmd, pkt, ts, cqe):
        cmd.t_cqe, cmd.pkt_cqe, cmd.status = float(ts), int(pkt), cqe["status"]
        self.nvme_done += 1
        lat = cmd.latency_us()
        st = self.nvme_lat[cmd.opc]
        med = st.median() if st.n > 50 else math.nan
        st.add(lat)
        if self._seg is not None:
            self._seg["nvme_completed"] += 1
            self._seg["max_cmd_latency_us"] = max(self._seg["max_cmd_latency_us"], round(lat, 1))
        if cmd.after_l1 is not None:
            info = {**cmd.public(), "median_us": med if med == med else None,
                    "extra_us": round(lat - med, 3) if med == med else None, "l1": cmd.after_l1}
            self.commands_after_l1.append(info)
            self._anom("slow_command_after_idle", pkt, ts, 3,
                       f"First NVMe command after L1 exit: {cmd.opc} SQ{cmd.qid} CID {cmd.cid} = {lat:.1f} us; its doorbell (#{cmd.pkt_doorbell}) "
                       f"could only be sent after the {cmd.after_l1.get('exit_latency_us')} us L1 exit (#{cmd.after_l1.get('exit_start_pkt')}-#{cmd.after_l1.get('exit_done_pkt')})",
                       info)
        if cmd.status:
            self.nvme_errors += 1
            self._anom("nvme_error_status", pkt, ts, 4, f"NVMe {cmd.opc} SQ{cmd.qid} CID {cmd.cid} completed with status 0x{cmd.status:03X} (SCT {cmd.status >> 8} SC {cmd.status & 0xFF})",
                       cmd.public())
        is_slow = lat > self.cfg.slow_cmd_abs_us or (med == med and lat > self.cfg.slow_cmd_ratio * med)
        if is_slow:
            self.slow_cmds.append(cmd)
            self.slow_cmds.sort(key=lambda c: -c.latency_us())
            del self.slow_cmds[self.cfg.top_slow_commands:]
            self._anom("slow_nvme_command", pkt, ts, 4 if lat > 5000 else 3,
                       f"NVMe {cmd.opc} SQ{cmd.qid} CID {cmd.cid} took {lat:.1f} us" + (f" (median {med:.1f} us)" if med == med else ""),
                       {**cmd.public(), "median_us": med if med == med else None})

    # ------------------------------------------------------------------ end
    def _finalize(self):
        tl = self.t_last
        if tl == tl and self._state_t0 == self._state_t0:
            self.speed_width_time[f"{self.speed} | {self.width}"] += max(0.0, tl - self._state_t0)
        for (req, tag), (pkt0, t0, ptype0, dir0, _) in list(self.open_np.items()):
            if tl == tl and (tl - t0) * 1e3 > 50:
                self._anom("completion_timeout", pkt0, t0, 5, f"{ptype0} {dir0} tag {tag} from {req} (#{pkt0}) never completed "
                           f"({(tl - t0) * 1e3:.1f} ms until end of trace)", {"tag": int(tag), "req": req})
        if tl == tl:
            self._expire_stale(tl + 1.0)
        for (qid, cid), cmd in list(self.open_cmds.items()):
            if tl == tl and (tl - cmd.t_doorbell) > 0.05:
                self._anom("nvme_command_never_completed", cmd.pkt_doorbell, cmd.t_doorbell, 5,
                           f"NVMe {cmd.opc} SQ{qid} CID {cid} never received a CQE ({(tl - cmd.t_doorbell) * 1e3:.1f} ms to end of trace)", cmd.public())

    def result(self) -> dict:
        dur = (self.t_last - self.t_first) if (self.t_first == self.t_first and self.t_last == self.t_last) else 0.0
        return {
            "schema_mapping": self.mapping, "schema_missing": getattr(self, "missing", []), "header_columns": len(getattr(self, "header", [])),
            "rows": self.rows, "max_packet": self.max_pkt, "t_first_s": self.t_first, "t_last_s": self.t_last, "duration_s": dur,
            "counts": {"by_type": dict(self.counts_cls.most_common()), "by_packet_type": dict(self.counts_ptype.most_common(60)),
                       "by_direction": dict(self.counts_dir), "errors": dict(self.counts_errors.most_common())},
            "error_examples": dict(self.error_examples),
            "speed_width": {"rows": dict(self.speed_width_rows.most_common()), "time_s": {k: round(v, 6) for k, v in self.speed_width_time.items()},
                            "final_speed": self.speed, "final_width": self.width},
            "completion_latency_us": self.cpl_latency.as_dict(),
            "completion_latency_by_type": {k: v.as_dict() for k, v in self.cpl_latency_by_type.items()},
            "ack_latency_us": self.ack_latency.as_dict(),
            "max_updatefc_gap_us": {k: round(v, 2) for k, v in self.max_updatefc_gap_us.items()},
            "config_space": self.config_space[:120],
            "nvme": {"bar0": f"0x{self.bar0:X}" if self.bar0 is not None else None, "completed_commands": self.nvme_done,
                     "error_completions": self.nvme_errors, "commands_by_opcode": dict(self.cmd_count_by_opc.most_common()),
                     "latency_by_opcode_us": {k: v.as_dict() for k, v in self.nvme_lat.items()},
                     "slow_commands": [{**c.public(), "median_us": (self.nvme_lat[c.opc].median() if self.nvme_lat[c.opc].n else None)} for c in self.slow_cmds]},
            "pm_l1_intervals": self.pm_l1_intervals[:200], "commands_after_l1": self.commands_after_l1[:200],
            "link_events": self.link_events[:2000], "idle_gaps": sorted(self.idle_gaps, key=lambda g: -g["gap_us"])[:50],
            "segments": self.segments, "anomalies": [asdict(a) for a in self.anomalies],
        }
