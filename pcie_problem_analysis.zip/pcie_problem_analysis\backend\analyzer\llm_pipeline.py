"""Stage 2 orchestration - all substages for one job.

  2.1 deterministic streaming pass (per CSV)          -> stats, anomalies
  2.2 spec rule engine                                 -> findings (with packet evidence)
  2.3 evidence windows cut to the LLM token budget     -> windows
  2.4 LLM map: one call per window                     -> window analyses (root cause, X / X+Y / Y)
  2.5 LLM reduce: merge into root causes               -> root causes + executive summary
  2.6 LLM test-case generation per root cause          -> test cases (JSON) -> files via testgen.py
  3   HTML report                                      -> report.html
"""
from __future__ import annotations

import json
import math
import os
import time
import traceback
from ..config import AnalysisConfig, LLMConfig
from . import chunker, prompts, spec_rules, testgen, report
from .deterministic import DeterministicAnalyzer
from .llm_client import LLMClient, LLMError


class Progress:
    def __init__(self, job_dir: str):
        self.job_dir = job_dir
        self.state = {"status": "running", "stage": "", "substage": "", "message": "", "fraction": 0.0,
                      "started": time.time(), "updated": time.time(), "substages": [], "llm_calls": 0}
        self._save()

    def set(self, stage, substage, message, fraction=None):
        s = self.state
        s["stage"], s["substage"], s["message"] = stage, substage, message
        if fraction is not None:
            s["fraction"] = round(float(fraction), 4)
        s["updated"] = time.time()
        if not s["substages"] or s["substages"][-1]["name"] != substage:
            s["substages"].append({"name": substage, "stage": stage, "started": time.time(), "done": False})
        self._save()

    def done_substage(self, substage, **info):
        for ss in self.state["substages"]:
            if ss["name"] == substage:
                ss["done"], ss["finished"] = True, time.time()
                ss.update(info)
        self._save()

    def finish(self, ok: bool, error: str = ""):
        self.state["status"] = "done" if ok else "error"
        self.state["error"] = error
        self.state["fraction"] = 1.0 if ok else self.state["fraction"]
        self._save()

    def _save(self):
        with open(os.path.join(self.job_dir, "status.json"), "w", encoding="utf-8") as f:
            json.dump(clean_nan(self.state), f, indent=1, default=str)


def clean_nan(obj):
    """Replace NaN/inf with None recursively so the stored JSON is strict (FastAPI refuses NaN)."""
    if isinstance(obj, float):
        return None if (math.isnan(obj) or math.isinf(obj)) else obj
    if isinstance(obj, dict):
        return {k: clean_nan(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean_nan(v) for v in obj]
    return obj


def _dump(job_dir, name, obj):
    with open(os.path.join(job_dir, name), "w", encoding="utf-8") as f:
        json.dump(clean_nan(obj), f, indent=1, default=str)


def run_job(job_dir: str, inputs: dict[str, str], llm_cfg: LLMConfig, acfg: AnalysisConfig,
            environment: str = "") -> dict:
    """inputs: {"trace": path}  (or several labelled exports, e.g. {"all_speeds": ..., "gen4_x4": ...})"""
    prog = Progress(job_dir)
    client = LLMClient(llm_cfg)
    result = {"inputs": {k: os.path.basename(v) for k, v in inputs.items() if v}, "files": {}, "llm": llm_cfg.public()}
    try:
        # ------------------------------------------------------------ 2.1 / 2.2 per file
        for label, path in inputs.items():
            if not path:
                continue
            size = os.path.getsize(path)
            prog.set("Stage 2", f"2.1 deterministic pass [{label}]", f"streaming {size / 1e9:.2f} GB", 0.02)
            det = DeterministicAnalyzer(acfg, lambda m, f, _l=label: prog.set("Stage 2", f"2.1 deterministic pass [{_l}]", m, 0.02 + 0.3 * (f or 0))).run(path, size)
            _dump(job_dir, f"deterministic_{label}.json", det)
            prog.done_substage(f"2.1 deterministic pass [{label}]", rows=det["rows"], anomalies=len(det["anomalies"]))

            prog.set("Stage 2", f"2.2 spec rules [{label}]", "mapping anomalies to spec expectations", 0.34)
            findings = spec_rules.build_findings(det, label)
            _dump(job_dir, f"findings_{label}.json", [f.to_dict() for f in findings])
            prog.done_substage(f"2.2 spec rules [{label}]", findings=len(findings))
            result["files"][label] = {"path": path, "det": det, "findings": findings}

        # ------------------------------------------------------------ cross-file comparison
        comparison = compare_exports(result["files"])
        _dump(job_dir, "comparison.json", comparison)

        # ------------------------------------------------------------ 2.3 windows
        sys_tokens = chunker.est_tokens(prompts.SYSTEM_ANALYST) + 900   # + template + summary block
        budget = llm_cfg.evidence_budget_tokens(sys_tokens)
        window_analyses = []
        all_findings = []
        for label, fd in result["files"].items():
            prog.set("Stage 2", f"2.3 evidence windows [{label}]", f"budget {budget} tokens/window", 0.38)
            fl = [f for f in fd["findings"] if f.severity >= 2]
            windows = chunker.plan_ranges(fl, acfg, acfg.max_llm_windows)
            windows = chunker.fill_windows(fd["path"], windows, fd["det"]["schema_mapping"], acfg, budget,
                                           progress=lambda m, f: prog.set("Stage 2", f"2.3 evidence windows [{label}]", m))
            _dump(job_dir, f"windows_{label}.json", [{"finding_id": w.finding_id, "ranges": w.ranges, "tokens": w.tokens,
                                                      "truncated": w.truncated, "lines": w.lines} for w in windows])
            prog.done_substage(f"2.3 evidence windows [{label}]", windows=len(windows))
            fd["windows"] = windows
            all_findings += fd["findings"]

            # -------------------------------------------------------- 2.4 map
            summary = chunker.summary_for_llm(fd["det"])
            by_id = {f.id: f for f in fd["findings"]}
            for i, w in enumerate(windows):
                f = by_id[w.finding_id]
                prog.set("Stage 2", f"2.4 LLM window analysis [{label}]", f"{i + 1}/{len(windows)} {f.title[:70]}",
                         0.40 + 0.30 * (i / max(1, len(windows))))
                user = prompts.ANALYZE_WINDOW.format(
                    finding_id=f.id, kind=f.kind, title=f.title, observed=f.observed[:600], expected=f.expected[:300],
                    spec_ref=f.spec_ref, timing=json.dumps(f.timing, default=str)[:400], summary=summary,
                    n_lines=len(w.lines), trunc=", truncated to budget" if w.truncated else "", evidence=w.text())
                try:
                    ans = client.chat_json(prompts.SYSTEM_ANALYST, user, tag=f"map:{f.id}")
                except LLMError as e:
                    ans = {"finding_id": f.id, "confirmed": None, "error": str(e)}
                ans["source_file"] = label
                ans["window_tokens"] = w.tokens
                window_analyses.append(ans)
                prog.state["llm_calls"] = client.calls
            prog.done_substage(f"2.4 LLM window analysis [{label}]", calls=len(windows))
        _dump(job_dir, "window_analyses.json", window_analyses)

        # ------------------------------------------------------------ 2.5 reduce (batched to fit the context)
        prog.set("Stage 2", "2.5 LLM reduce", "merging window findings into root causes", 0.72)
        root = reduce_in_batches(client, llm_cfg, result["files"], window_analyses, all_findings)
        _dump(job_dir, "root_causes.json", root)
        prog.state["llm_calls"] = client.calls
        prog.done_substage("2.5 LLM reduce", root_causes=len(root.get("root_causes", [])))

        # ------------------------------------------------------------ 2.6 test cases
        prog.set("Stage 2", "2.6 test case generation", "one test case per root cause", 0.80)
        fmap = {f.id: f for f in all_findings}
        test_cases = []
        rcs = root.get("root_causes", [])
        for i, rc in enumerate(rcs):
            prog.set("Stage 2", "2.6 test case generation", f"{i + 1}/{len(rcs)} {rc.get('title', '')[:60]}",
                     0.80 + 0.12 * (i / max(1, len(rcs))))
            related = [abridge_finding(fmap[x]) for x in rc.get("finding_ids", []) if x in fmap][:6]
            user = prompts.GENERATE_TEST_CASE.format(root_cause_json=json.dumps(rc, default=str)[:3500],
                                                     findings_json=json.dumps(related, default=str)[:5000],
                                                     environment=environment or testgen.DEFAULT_ENV)
            try:
                tc = client.chat_json(prompts.SYSTEM_TESTGEN, user, tag=f"test:{rc.get('id')}")
            except LLMError as e:
                tc = testgen.fallback_test_case(rc, related, str(e))
            tc["root_cause_id"] = rc.get("id")
            # always add the deterministic hint-based steps so the test is runnable even with a weak model
            tc = testgen.enrich_with_deterministic(tc, rc, related)
            test_cases.append(tc)
            prog.state["llm_calls"] = client.calls
        tc_dir = os.path.join(job_dir, "testcases")
        testgen.write_test_suite(tc_dir, test_cases, root, environment or testgen.DEFAULT_ENV)
        _dump(job_dir, "test_cases.json", test_cases)
        prog.done_substage("2.6 test case generation", test_cases=len(test_cases))

        # ------------------------------------------------------------ Stage 3 report
        prog.set("Stage 3", "3.1 HTML report", "rendering", 0.95)
        html = report.render(job_dir, result["files"], comparison, window_analyses, root, test_cases, client, llm_cfg)
        with open(os.path.join(job_dir, "report.html"), "w", encoding="utf-8") as f:
            f.write(html)
        _dump(job_dir, "llm_log.json", client.log)
        prog.done_substage("3.1 HTML report")
        prog.finish(True)
        return {"ok": True}
    except Exception as e:   # noqa: BLE001
        tb = traceback.format_exc()
        with open(os.path.join(job_dir, "error.txt"), "w", encoding="utf-8") as f:
            f.write(tb)
        prog.finish(False, f"{e}")
        return {"ok": False, "error": str(e)}


def abridge_finding(f) -> dict:
    return {"finding_id": f.id, "kind": f.kind, "layer": f.layer, "severity": f.severity, "title": f.title,
            "observed": f.observed[:400], "evidence_packets": f.evidence_packets[:12], "timing": f.timing,
            "affected_command": f.affected_command, "test_hint": f.test_hint, "fix": f.fix_hypothesis[:300]}


def reduce_in_batches(client: LLMClient, cfg: LLMConfig, files: dict, analyses: list, findings: list) -> dict:
    """Merge window analyses; if too many for one call, reduce hierarchically."""
    fmap = {f.id: f for f in findings}
    items = []
    for a in analyses:
        f = fmap.get(a.get("finding_id"))
        item = {"finding_id": a.get("finding_id"), "confirmed": a.get("confirmed"), "root_cause": a.get("root_cause"),
                "mechanism": (a.get("mechanism") or "")[:500], "offending_packets": a.get("offending_packets"),
                "offending_command": a.get("offending_command"), "extra_time_us": a.get("extra_time_us"),
                "expected_time_us": a.get("expected_time_us"), "observed_time_us": a.get("observed_time_us"),
                "responsible_side": a.get("responsible_side"), "fix": (a.get("fix") or "")[:300],
                "severity": f.severity if f else None, "layer": f.layer if f else None, "title": f.title if f else None,
                "source_file": a.get("source_file")}
        items.append(item)
    # findings that had no LLM window still go into the reduce step (severity 1 info ones)
    seen = {i["finding_id"] for i in items}
    for f in findings:
        if f.id not in seen:
            items.append({"finding_id": f.id, "confirmed": None, "root_cause": f.observed[:300], "severity": f.severity,
                          "layer": f.layer, "title": f.title, "offending_packets": f.evidence_packets[:8],
                          "timing": f.timing, "source_file": f.source_file, "note": "deterministic only"})
    first = next(iter(files.values())) if files else None
    det = first["det"] if first else {"rows": 0, "duration_s": 0}
    summary = "\n".join(f"[{lbl}] " + chunker.summary_for_llm(fd["det"], 1800) for lbl, fd in files.items())
    budget_chars = int(cfg.evidence_budget_tokens(chunker.est_tokens(prompts.SYSTEM_REDUCER) + 600) * chunker.CHARS_PER_TOKEN) - 6500

    timeline = "\n".join(f"[{lbl}]\n" + chunker.segment_timeline(fd["det"]) for lbl, fd in files.items())

    def call(batch):
        user = prompts.REDUCE_FINDINGS.format(source=", ".join(files.keys()), rows=det["rows"], duration_s=det["duration_s"],
                                              summary=summary[:4000], timeline=timeline[:6000], findings_json=json.dumps(batch, default=str))
        return client.chat_json(prompts.SYSTEM_REDUCER, user, tag="reduce")

    batches, cur, cur_len = [], [], 0
    for it in items:
        s = len(json.dumps(it, default=str))
        if cur and cur_len + s > budget_chars - 4500:
            batches.append(cur)
            cur, cur_len = [], 0
        cur.append(it)
        cur_len += s
    if cur:
        batches.append(cur)
    partials = []
    for b in batches:
        try:
            partials.append(call(b))
        except LLMError as e:
            partials.append({"root_causes": [{"id": f"RC-{len(partials) + 1}", "title": "LLM reduce failed", "finding_ids": [x["finding_id"] for x in b],
                                              "severity": "medium", "layer": "unknown", "explanation": str(e), "fix": ""}],
                             "executive_summary": ""})
    if len(partials) == 1:
        out = partials[0]
    else:
        merged = []
        for p in partials:
            merged += p.get("root_causes", [])
        try:
            out = call([{"finding_id": rc.get("id"), "root_cause": rc.get("title"), "mechanism": rc.get("explanation"),
                         "offending_packets": rc.get("evidence_packets"), "severity": rc.get("severity"),
                         "finding_ids": rc.get("finding_ids")} for rc in merged])
        except LLMError:
            out = {"root_causes": merged, "executive_summary": " ".join(p.get("executive_summary", "") for p in partials)}
    # normalise ids
    for i, rc in enumerate(out.get("root_causes", [])):
        rc["id"] = rc.get("id") or f"RC-{i + 1}"
    return out


def compare_exports(files: dict) -> dict:
    """Link-state profile of the trace (speed/width residency derived from training sets and link events);
    if two exports are given (full + Gen4-x4 filtered) also compare them."""
    out = {"present": list(files.keys())}
    first = next(iter(files.values())) if files else None
    if first:
        det = first["det"]
        tot = sum(det["speed_width"]["time_s"].values()) or 1
        out["residency_pct"] = {k: round(100 * v / tot, 3) for k, v in det["speed_width"]["time_s"].items()}
        out["final_state"] = f"{det['speed_width'].get('final_speed')} {det['speed_width'].get('final_width')}"
        out["link_training_rows"] = det["counts"]["by_packet_type"].get("TS1", 0) + det["counts"]["by_packet_type"].get("TS2", 0)
        out["speed_changes"] = [e for e in det["link_events"] if "speed change" in e.get("text", "").lower()][:20]
        out["width_changes"] = [e for e in det["link_events"] if "width change" in e.get("text", "").lower()][:20]
        out["time_outside_16GTs_x4_s"] = round(sum(v for k, v in det["speed_width"]["time_s"].items() if not ("16.0" in k and "x4" in k)), 6)
        out["interpretation"] = (
            f"The link spent {out['time_outside_16GTs_x4_s']} s of {tot:.4f} s outside 16 GT/s x4 (training, Recovery, speed changes, "
            f"L1). Final state: {out['final_state']}. Errors inside those intervals are physical-layer / LTSSM problems; "
            "errors while the link was at 16 GT/s x4 are link-, transaction- or device-level problems.")
    a, g = files.get("all_speeds"), files.get("gen4_x4")
    if a and g:
        out["rows_all"] = a["det"]["rows"]
        out["rows_gen4"] = g["det"]["rows"]
        out["rows_only_in_all_speeds"] = a["det"]["rows"] - g["det"]["rows"]
        ea, eg = a["det"]["counts"]["errors"], g["det"]["counts"]["errors"]
        out["errors_only_outside_gen4_x4"] = {k: v - eg.get(k, 0) for k, v in ea.items() if v - eg.get(k, 0) > 0}
        out["interpretation_two_files"] = (
            f"{out['rows_only_in_all_speeds']:,} packets occurred while the link was NOT at Gen4 x4 "
            "(link training, Recovery, speed/width changes, L1 exits, Gen3 fallback). Errors that appear only in the "
            "all-speeds file happened during those transitions -> physical layer / LTSSM problems. Errors present in "
            "both files happened in steady state -> link, transaction or device problems.")
    return out
