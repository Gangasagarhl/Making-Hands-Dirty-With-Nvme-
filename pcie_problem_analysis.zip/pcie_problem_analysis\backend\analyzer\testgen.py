"""Stage 2 / Substage 2.6 - turn root causes into runnable test artifacts.

For every root cause we emit:
  testcases/TC-<id>.json            the structured test case (from the LLM, enriched deterministically)
  testcases/TC-<id>.sh              Linux reproduction script (nvme-cli / fio / setpci) with analyzer arming notes
  testcases/test_pcie_regressions.py pytest suite: runs the scripts (or dry-run) and checks pass criteria
  testcases/analyzer_triggers.md     how to arm the Teledyne analyzer for each case
  testcases/README.md
"""
from __future__ import annotations

import json
import os
import re

DEFAULT_ENV = ("Linux host (kernel 6.x) with nvme-cli >= 2.0, fio >= 3.30, setpci; DUT = NVMe SSD under test at "
               "/dev/nvme0 on a PCIe Gen4 x4 slot behind a Teledyne LeCroy Summit interposer; PCIe Protocol Analysis "
               "13.28.b.15 recording with 'All link speeds/widths'; root complex ASPM policy = default.")

# Deterministic recipes keyed by finding kind - these make the test runnable even if the LLM output is thin.
RECIPES = {
    "lcrc_error": {
        "trigger": "Trigger on DLLP Nak (any direction); pre-trigger 30%",
        "steps": ["fio --name=seqread --filename=/dev/nvme0n1 --rw=read --bs=128k --iodepth=32 --numjobs=4 --direct=1 --runtime=300 --time_based --group_reporting",
                  "nvme error-log /dev/nvme0", "setpci -s $BDF CAP_EXP+0x0a.w   # Correctable Error Status: Bad TLP / Bad DLLP bits"],
        "pass": ["Teledyne Error Summary: LCRC Error = 0, Nak = 0 over the run", "AER correctable Bad TLP bit not set"],
    },
    "replay_timer_timeout": {
        "trigger": "Trigger on 'Replay Timer Timeout' link event; pre-trigger 30%",
        "steps": ["fio --name=mixed --filename=/dev/nvme0n1 --rw=randrw --rwmixread=70 --bs=4k --iodepth=64 --numjobs=4 --direct=1 --runtime=300 --time_based",
                  "setpci -s $BDF CAP_EXP+0x0a.w   # Replay Timer Timeout status bit"],
        "pass": ["0 replay-timer events in Error Summary", "no 'Replayed TLP' entries"],
    },
    "flow_control_stall": {
        "trigger": "Timing trigger: gap between UpdateFC-P DLLPs > 30 us, or 'Flow Control' link event",
        "steps": ["fio --name=rr --filename=/dev/nvme0n1 --rw=randread --bs=128k --iodepth=32 --numjobs=8 --direct=1 --runtime=180 --time_based"],
        "pass": ["max UpdateFC gap < 30 us (Flow Control Tracking view)", "no credit-exhaustion stall"],
    },
    "completion_timeout": {
        "trigger": "Trigger on 'Completion Timeout' / AER uncorrectable; pre-trigger 50%",
        "steps": ["nvme read /dev/nvme0n1 --start-block=$SLBA --block-count=7 --data-size=4096 --data=/tmp/out.bin",
                  "dmesg | grep -iE 'nvme|DMAR|AMD-Vi|IOMMU'",
                  "setpci -s $BDF CAP_EXP+0x04.l   # Device Status: Fatal/Non-fatal error detected"],
        "pass": ["every MRd gets a CplD within 10 ms", "command completes with CQE status 0", "no IOMMU fault in dmesg"],
    },
    "nvme_command_never_completed": {
        "trigger": "Trigger on 'Completion Timeout'; pre-trigger 50%",
        "steps": ["nvme read /dev/nvme0n1 --start-block=$SLBA --block-count=7 --data-size=4096 --data=/tmp/out.bin",
                  "nvme get-log /dev/nvme0 --log-id=1 --log-len=4096   # error information log"],
        "pass": ["doorbell -> CQE observed for every command", "no host-side nvme timeout in dmesg"],
    },
    "unsupported_request": {
        "trigger": "Trigger on TLP Completion with status UR",
        "steps": ["setpci -s $BDF 0x10.l   # BAR0", "devmem2 $((BAR0 + OFFSET)) w   # read the offending register offset once",
                  "nvme id-ctrl /dev/nvme0"],
        "pass": ["UR appears at most once for the probe read and never during I/O"],
    },
    "malformed_tlp": {
        "trigger": "Trigger on 'Malformed TLP' error; pre-trigger 50%",
        "steps": ["fio --name=mal --filename=/dev/nvme0n1 --rw=write --bs=$BS --offset=$OFFSET --iodepth=1 --direct=1 --size=64m",
                  "setpci -s $BDF CAP_EXP+0x04.l   # Device Status"],
        "pass": ["0 Malformed TLP in Error Summary", "Length (DW) == ceil(ByteCount/4) on every MRd/MWr"],
    },
    "poisoned_tlp": {
        "trigger": "Trigger on TLP with EP=1",
        "steps": ["nvme read /dev/nvme0n1 --start-block=$SLBA --block-count=7 --data-size=4096 --data=/tmp/out.bin",
                  "nvme smart-log /dev/nvme0", "nvme get-log /dev/nvme0 --log-id=1 --log-len=4096"],
        "pass": ["no EP=1 TLP", "media errors counter unchanged"],
    },
    "receiver_error": {
        "trigger": "Trigger on 'Link Speed Change' or Receiver/Framing error; record LTSSM Flow Graph",
        "steps": ["fio --name=seq --filename=/dev/nvme0n1 --rw=read --bs=1m --iodepth=16 --direct=1 --runtime=600 --time_based",
                  "watch -n1 'setpci -s $BDF CAP_EXP+0x12.w'   # Link Status: Current Link Speed/Width stays 0x44 (Gen4 x4)"],
        "pass": ["link stays 16 GT/s x4 for the whole run", "0 Receiver / Framing / Invalid Symbol errors", "0 Recovery entries"],
    },
    "l1_exit_latency": {
        "trigger": "Trigger on DLLP PM_Enter_L1 (or PM_Active_State_Request_L1); pre-trigger 20%",
        "steps": ["lspci -vvv -s $BDF | grep -E 'LnkCap|LnkCtl|L1SubCap|LTR'   # record advertised L1 exit latency and ASPM state",
                  "fio --name=idle --filename=/dev/nvme0n1 --rw=randread --bs=4k --iodepth=1 --direct=1 --thinktime=5000 --thinktime_blocks=1 --runtime=120 --time_based --lat_percentiles=1",
                  "echo performance > /sys/module/pcie_aspm/parameters/policy   # control run: repeat fio with ASPM disabled"],
        "pass": ["p99 latency (ASPM on) - median <= advertised L1 exit latency", "with ASPM off the tail disappears (confirms attribution)"],
    },
    "slow_nvme_command": {
        "trigger": "Trigger on NVMe CQE for the opcode under test; use Bus Utilization 'Latency Time at Split level' graph",
        "steps": ["fio --name=repro --filename=/dev/nvme0n1 --rw=$RW --bs=$BS --iodepth=1 --direct=1 --runtime=120 --time_based --lat_percentiles=1",
                  "nvme smart-log /dev/nvme0   # background GC / thermal state"],
        "pass": ["p99 <= 3x median for the opcode", "no command with last-data->CQE phase > 1 ms"],
    },
    "nvme_error_status": {
        "trigger": "Trigger on NVMe CQE with SF != 0",
        "steps": ["nvme io-passthru /dev/nvme0n1 --opcode=$OPC --namespace-id=1 --cdw10=$CDW10 --cdw12=$CDW12 -r -l 4096",
                  "nvme get-log /dev/nvme0 --log-id=1 --log-len=4096"],
        "pass": ["CQE status 0 for the replayed command"],
    },
}


def _kind_of(rc: dict, related: list[dict]) -> str:
    for f in related:
        if f.get("kind") in RECIPES:
            return f["kind"]
    low = json.dumps(rc).lower()
    for k in RECIPES:
        if k.replace("_", " ") in low or k in low:
            return k
    return "slow_nvme_command"


def fallback_test_case(rc: dict, related: list[dict], err: str) -> dict:
    kind = _kind_of(rc, related)
    r = RECIPES[kind]
    return {"test_id": f"TC-{rc.get('id', 'X')}", "title": rc.get("title", kind), "objective": rc.get("explanation", ""),
            "environment": {"host": "Linux", "analyzer": "Teledyne Summit / PCIe Protocol Analysis 13.28", "link": "Gen4 x4"},
            "preconditions": ["LLM test generation failed: " + err[:200]], "analyzer_trigger": {"event": r["trigger"]},
            "steps": [{"n": i + 1, "cmd": c, "expect": ""} for i, c in enumerate(r["steps"])],
            "pass_criteria": r["pass"], "fail_criteria": ["any pass criterion violated"], "metrics_to_record": []}


def enrich_with_deterministic(tc: dict, rc: dict, related: list[dict]) -> dict:
    kind = _kind_of(rc, related)
    r = RECIPES[kind]
    tc.setdefault("steps", [])
    have = {s.get("cmd", "") for s in tc["steps"]}
    n = len(tc["steps"])
    for c in r["steps"]:
        if c not in have:
            n += 1
            tc["steps"].append({"n": n, "cmd": c, "expect": "(deterministic recipe)"})
    tc.setdefault("pass_criteria", [])
    for p in r["pass"]:
        if p not in tc["pass_criteria"]:
            tc["pass_criteria"].append(p)
    tc.setdefault("analyzer_trigger", {})
    tc["analyzer_trigger"].setdefault("event", r["trigger"])
    tc["kind"] = kind
    # variables the script needs, filled from the affected command where known
    vars_ = {"BDF": "0000:01:00.0", "SLBA": "0", "BS": "4k", "RW": "randread", "OFFSET": "0", "OPC": "0x02",
             "CDW10": "0", "CDW12": "7"}
    for f in related:
        cmd = f.get("affected_command") or {}
        if cmd.get("bytes"):
            vars_["BS"] = f"{int(cmd['bytes'])}"
        if cmd.get("opcode"):
            op = str(cmd["opcode"]).lower()
            vars_["RW"] = "randwrite" if "write" in op else "randread"
            vars_["OPC"] = "0x01" if "write" in op else "0x02"
    tc["variables"] = vars_
    tc["maps_to_trace_packets"] = tc.get("maps_to_trace_packets") or sorted({p for f in related for p in f.get("evidence_packets", [])})[:20]
    return tc


def _sh(tc: dict) -> str:
    lines = ["#!/usr/bin/env bash", f"# {tc.get('test_id')} - {tc.get('title')}", f"# Objective: {tc.get('objective', '')}",
             f"# Root cause: {tc.get('root_cause_id')}   Trace packets: {tc.get('maps_to_trace_packets')}",
             f"# Analyzer: {tc.get('analyzer_trigger', {}).get('event', '')}",
             "set -euo pipefail", ""]
    for k, v in tc.get("variables", {}).items():
        lines.append(f"{k}=${{{k}:-{v}}}")
    lines += ["DRY_RUN=${DRY_RUN:-0}", "run() { echo \"+ $*\"; if [ \"$DRY_RUN\" = 0 ]; then eval \"$@\"; fi; }", "",
              "echo '== ARM THE ANALYZER NOW: " + tc.get("analyzer_trigger", {}).get("event", "").replace("'", "") + " =='", ""]
    for s in tc.get("steps", []):
        cmd = str(s.get("cmd", "")).replace("\n", " ")
        if not cmd:
            continue
        lines.append(f"# step {s.get('n')}: {s.get('expect', '')}")
        lines.append("run " + json.dumps(cmd))
    lines += ["", "echo '== PASS CRITERIA (check in Teledyne Error Summary / Traffic Summary) =='"]
    for p in tc.get("pass_criteria", []):
        lines.append("echo " + json.dumps(" - " + str(p)))
    return "\n".join(lines) + "\n"


PYTEST = '''"""Generated regression suite. Runs each TC-*.sh (DRY_RUN=1 by default so it is safe on any machine).
Set PCIE_TC_LIVE=1 on the validation host to execute the commands for real. Pass criteria that depend on the
Teledyne Error Summary are read from an exported summary JSON if PCIE_ERROR_SUMMARY points at one
({"LCRC Error": 0, "Nak": 0, ...}); otherwise they are reported as 'manual'."""
import glob, json, os, subprocess, pytest

HERE = os.path.dirname(__file__)
CASES = sorted(glob.glob(os.path.join(HERE, "TC-*.json")))


def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


@pytest.mark.parametrize("case_path", CASES, ids=[os.path.basename(c) for c in CASES])
def test_reproduction_script_runs(case_path):
    tc = load(case_path)
    sh = case_path[:-5] + ".sh"
    env = dict(os.environ, DRY_RUN="0" if os.environ.get("PCIE_TC_LIVE") == "1" else "1")
    r = subprocess.run(["bash", sh], capture_output=True, text=True, env=env, timeout=3600)
    assert r.returncode == 0, r.stderr[-2000:]
    assert tc.get("steps"), "test case has no steps"


@pytest.mark.parametrize("case_path", CASES, ids=[os.path.basename(c) for c in CASES])
def test_analyzer_error_counts(case_path):
    tc = load(case_path)
    summary_path = os.environ.get("PCIE_ERROR_SUMMARY")
    if not summary_path:
        pytest.skip("manual: compare Teledyne Error Summary against pass criteria: %s" % tc.get("pass_criteria"))
    summ = load(summary_path)
    kind = tc.get("kind", "")
    keys = {"lcrc_error": ["LCRC Error", "Nak"], "replay_timer_timeout": ["Replay Timer Timeout"],
            "malformed_tlp": ["Malformed TLP"], "poisoned_tlp": ["Poisoned TLP"], "completion_timeout": ["Completion Timeout"],
            "receiver_error": ["Receiver Error", "Framing Error", "Invalid Symbol", "Speed Downshift"],
            "flow_control_stall": ["Flow Control Stall"], "unsupported_request": ["Unsupported Request"]}.get(kind, [])
    for k in keys:
        assert summ.get(k, 0) == 0, f"{k} = {summ.get(k)} (expected 0)"
'''


def write_test_suite(tc_dir: str, test_cases: list[dict], root: dict, environment: str):
    os.makedirs(tc_dir, exist_ok=True)
    trig = ["# Teledyne analyzer arming per test case", "", f"Environment: {environment}", ""]
    for tc in test_cases:
        tid = re.sub(r"[^A-Za-z0-9_-]", "_", str(tc.get("test_id", "TC")))
        with open(os.path.join(tc_dir, f"{tid}.json"), "w", encoding="utf-8") as f:
            json.dump(tc, f, indent=1, default=str)
        with open(os.path.join(tc_dir, f"{tid}.sh"), "w", encoding="utf-8", newline="\n") as f:
            f.write(_sh(tc))
        trig += [f"## {tid} - {tc.get('title')}", f"- Trigger: {tc.get('analyzer_trigger', {}).get('event')}",
                 f"- Pre-trigger: {tc.get('analyzer_trigger', {}).get('pre_trigger_pct', 20)} %",
                 f"- Trace packets this reproduces: {tc.get('maps_to_trace_packets')}",
                 "- Pass: " + "; ".join(map(str, tc.get("pass_criteria", []))), ""]
    with open(os.path.join(tc_dir, "analyzer_triggers.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(trig))
    with open(os.path.join(tc_dir, "test_pcie_regressions.py"), "w", encoding="utf-8") as f:
        f.write(PYTEST)
    with open(os.path.join(tc_dir, "README.md"), "w", encoding="utf-8") as f:
        f.write("# Generated regression tests\n\n" + (root.get("executive_summary") or "") +
                "\n\nRun: `pytest -q` (dry run) or `PCIE_TC_LIVE=1 pytest -q` on the validation host.\n"
                "Export the Teledyne Error Summary to JSON and point PCIE_ERROR_SUMMARY at it to make the count checks automatic.\n")
