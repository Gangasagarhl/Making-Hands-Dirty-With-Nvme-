# PCIe / NVMe trace problem analysis

Input: **one CSV** exported straight from a `.pex` trace by **Teledyne LeCroy PCIe Protocol Analysis 13.28.b.15**
(112 raw packet columns: Marker, Packet, Link, Direction, Ordered Set Type, DLLP Type, TLP Type, Link Event, PSN,
ACK/NAK Sequence Number, VC ID, HdrScale/HdrFC/DataScale/DataFC, TC..AT, Length, Requester ID, Tag, Completer ID,
Address, Device ID, Register, First/Last BE, Cpl Status, Byte Cnt, BCM, Lwr Addr, Msg fields, TS fields, PMUX, LTR,
PTM, SMBus ARP/UDID, LCRC, ECRC, CRC16, Data, Time Delta, Time Stamp, Jammer, CXL/ALMP). 2-5 GB per file.

Output: what is wrong, why, which packet / DLLP / PM request / NVMe command caused it, how much extra time (Y) it
added on top of the expected time (X), and generated test cases that reproduce it on the next build.

There are **no decode-helper columns** in that export (no Errors, no Link Speed/Width, no NVMe fields), so the
analysis derives everything from protocol content:

| What | How it is derived from the raw export |
|---|---|
| link speed / width | `TS_Data Rate`, `TS Lane` of TS1/TS2 + `Link Event` (Speed Change, Width Change, Recovery, L1) |
| LCRC / ECRC errors | `(Bad)` in the LCRC / ECRC cell |
| Nak, replay, replay-timer expiry | `DLLP Type = Nak`; a TLP re-sent with an already-seen PSN (with / without a Nak in the 10 µs before) |
| Ack latency | time from the newest TLP covered by an Ack to that Ack |
| flow-control stall | credit accounting: InitFC/UpdateFC-P `DataFC` (12-bit cumulative limit) vs posted TLP consumption |
| poison / UR / CA | `EP = 1`; `Cpl Status` |
| malformed TLP | `Length` vs payload bytes in `Data`, or Length > Max_Payload_Size |
| completion timeout, tag reuse | (Requester ID, Tag) open > 50 ms, never completed, or re-used while outstanding; Byte Cnt handles split completions |
| ASPM L1 cost | PM_* DLLPs + L1 Entry/Exit + Recovery → L0; the first doorbell after it is tagged |
| NVMe commands | BAR0 from CfgWr0 reg 0x10; doorbells = MWr to BAR0+0x1000+…; SQE = 64-byte CplD payload (opcode/CID/NSID/PRP/SLBA/NLB); CQE = 16-byte upstream MWr payload (SQID/CID/status); MSI-X = MWr to 0xFEExxxxx |

## Layout

```
stage1_research/generate_synthetic_trace.py   synthetic export in the real 112-column layout, 10 injected faults, --size-gb 2
backend/csv_schema.py                          header auto-mapping (aliases, duplicate "Device ID" handled)
backend/analyzer/deterministic.py              2.1 streaming protocol analysis (≈40k rows/s, constant memory)
backend/analyzer/spec_rules.py                 2.2 anomaly -> spec expectation -> finding (packets, X / X+Y / Y, fix, test hint)
backend/analyzer/chunker.py                    2.3 overlapping evidence windows + whole-trace segment timeline, token-budgeted
backend/analyzer/llm_client.py                 claude_cli (Haiku) | openai-compatible (Qwen 28k) | anthropic | mock
backend/analyzer/prompts.py                    2.4 map / 2.5 reduce / 2.6 test generation prompts
backend/analyzer/llm_pipeline.py               orchestration + progress
backend/analyzer/testgen.py                    .sh / .json / pytest / analyzer trigger files per root cause
backend/analyzer/report.py                     Stage 3 HTML report
backend/app.py, frontend/                      FastAPI server + UI (upload or server-side path, live substage progress)
tests/test_pipeline.py                         16 tests: every injected fault must be found at its packet
docs/                                          CLAUDE_CODE_PROMPT.md, stage1_problem_catalog.html, final_report_what_was_done.html
```

## Run

```powershell
pip install -r requirements.txt
python run_server.py --port 8000              # open http://127.0.0.1:8000 ; choose provider "claude CLI (Haiku)"
# or headless:
python run_cli.py --trace D:\traces\export.csv --provider claude_cli
python run_cli.py --trace D:\traces\export.csv --provider openai --base-url https://.../v1 --api-key sk-... --model qwen-plus
pytest -q tests
```

For multi-GB exports type the server-side path in the UI instead of uploading; the file is streamed in place.
Throughput on a laptop: ~40k packets/s for the deterministic pass (2 GB ≈ 4 M packets ≈ 2 min; 5 GB ≈ 5 min), then
one LLM call per evidence window (24 by default) plus reduce and test-generation calls.

## How a 5 GB CSV is handled (chunking strategy)

1. **Streaming pass** in 250k-row chunks; only compact state is kept (open requests by tag, open NVMe commands, last
   PSNs, credit counters). Every anomaly is pinned to a `Packet` number.
2. **Segment timeline**: per chunk, counts of TLPs / Naks / replays / bad LCRC / anomalies / NVMe completions / max
   command latency / speed. 100 % coverage of the trace in ~1-2k tokens; sent with the reduce call.
3. **Evidence windows**: ±60/90 rows around every evidence packet of a finding, touching ranges merged, neighbours
   overlapping by 25 rows, far-apart anchors (doorbell … CQE) joined with "N packets skipped" markers, trimmed to
   the model budget (`context × 0.8 − output − system` ≈ 18.5k tokens for a 28k model). A second streaming pass
   materialises only those rows.
4. **LLM map** (one call per window) → **reduce** (batched to the budget) → **test generation** (per root cause).

## Synthetic data

`python stage1_research\generate_synthetic_trace.py --out data\big --size-gb 2` writes a 2 GB export with link
training, config-space enumeration (BAR0, Link Capabilities with the advertised L1 exit latency), NVMe admin setup and
I/O traffic, and 10 injected faults recorded in `injected_faults.json` (ground truth with packet numbers).

## Real exports

Export with the `Data` column populated (the NVMe SQE/CQE decode needs it). The header is auto-mapped; any canonical
column that could not be mapped is listed in `deterministic_trace.json -> schema_missing` for the job. Direction
values `Upstream/Downstream` or `Up/Down` are both accepted; timestamps in seconds, `ns`, `us`, or `0.000 012 345`
grouping are parsed.
