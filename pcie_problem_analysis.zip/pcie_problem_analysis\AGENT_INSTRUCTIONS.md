# AGENT INSTRUCTIONS — install, run, and deliver the PCIe/NVMe trace analysis

You are an automation agent (Claude Code or similar) that has been handed this package and **one CSV path**.
Follow the steps in order. Every step has a check; do not continue past a failed check without fixing it.
Do not modify analysis logic unless a check tells you to (section 6).

## 0. What this package does

Input: one CSV exported by **Teledyne LeCroy PCIe Protocol Analysis 13.28.b.15** from a `.pex`/`.ptrace`
(File ▸ Export ▸ Packets to CSV Text; 112 raw packet columns; 2–5 GB).
Output (per job, in `data/jobs/<job-id>/`):
- `report.html` — what is wrong, why, which packet / DLLP / PM request / NVMe command, how much extra time (Y) on
  top of the expected time (X), root causes, generated test cases.
- `findings_trace.json`, `root_causes.json`, `window_analyses.json`, `deterministic_trace.json`
- `testcases/TC-*.sh|.json`, `testcases/test_pcie_regressions.py`, `testcases/analyzer_triggers.md` — reproduction
  scripts per root cause, each referencing the trace packets it reproduces.

Pipeline: streaming deterministic protocol analysis (constant memory) → spec rule engine → overlapping,
token-budgeted evidence windows → LLM map/reduce/test-generation → HTML report. Details: `docs/how_it_works.html`.

## 1. Prerequisites

- Windows or Linux, **Python 3.10+** (tested on 3.12). ~1 GB free RAM; disk space for the CSV only (it is read in place).
- **The LLM is reached through an API. The user gives exactly three values: the API base URL, the API key and the
  model name.** Put them in `.env` (copy `.env.example`):
  ```
  LLM_BASE_URL=https://your-endpoint/v1      # OpenAI-compatible chat-completions endpoint (Qwen/DashScope, vLLM, OpenRouter, gateways)
  LLM_API_KEY=sk-...
  LLM_MODEL=qwen-plus
  LLM_CONTEXT_TOKENS=28000                   # optional; the model's context window (evidence windows are sized from it)
  ```
  The provider is auto-detected (`openai`; an `api.anthropic.com` URL switches to the Anthropic Messages API). A URL
  with or without `/v1` or `/chat/completions` is accepted. No Claude CLI is required or used when a key is present.
  The same three values can instead be passed on the command line (`--base-url --api-key --model`) or typed in the UI.
  Without any key the pipeline runs with the offline **mock** provider: deterministic findings with packet evidence
  but no written root-cause text (fine for smoke tests, not for delivery).

## 1b. If you received this as a zip by e-mail

The Windows setup script is shipped as `setup_and_run.ps1.txt` because mail gateways block `.ps1`. Rename it:
`Rename-Item setup_and_run.ps1.txt setup_and_run.ps1` (the Linux `setup_and_run.sh` needs no rename). Everything
else is plain `.py`, `.html`, `.css`, `.md`, `.txt`.

## 2. Install

```powershell
# Windows PowerShell (from the unzipped folder)
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```
```bash
# Linux / macOS
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
Or simply run `setup_and_run.ps1` / `setup_and_run.sh` (section 4), which does install + check + run.

**Check:** `python -c "import fastapi, pandas, uvicorn, requests; print('ok')"` prints `ok`.

## 3. Verify the installation (mandatory, ~30 s)

```
python -m pytest -q tests
```
**Check:** `16 passed`. This generates a small synthetic export with 10 known faults, runs the whole pipeline with the
mock provider and asserts every fault is found at the right packet. If it fails, read the assertion: it names the
fault and the packet; see section 6.

Then confirm the API: `python -c "from backend.config import LLMConfig; c=LLMConfig().normalize(); print(c.provider, c.base_url, c.model)"`
must print `openai` (or `anthropic`), the URL and the model, not `mock`. The first LLM call of the run will fail fast
with the HTTP status and body in `data/jobs/<job>/llm_log.json` if the URL/key/model are wrong.

## 4. Run on the user's CSV

### 4a. Headless (recommended for multi-GB files; gives a report path at the end)
```powershell
python run_cli.py --trace "<CSV PATH>" --max-windows 20 `
  --environment "Linux 6.x host, nvme-cli, fio, DUT /dev/nvme0 at 0000:01:00.0, Gen4 x4, Summit interposer, PAP 13.28.b.15"
# or pass the API values explicitly instead of .env:
python run_cli.py --trace "<CSV PATH>" --base-url "<URL>" --api-key "<KEY>" --model "<MODEL>" --context-tokens 28000
```
Progress is written every few seconds to `data/jobs/<job>/status.json` (`substage`, `message`, `fraction`).
Expected durations: deterministic pass ≈ 35–40k packets/s (2 GB ≈ 2–3 min, 5 GB ≈ 5–6 min); evidence extraction ≈ 1 min;
LLM: ~20 map calls + 1–3 reduce + ~10 test-generation calls (hosted API: a few seconds to ~1 min each).

### 4b. Quick confidence run first (optional, ~30 s with mock, a few minutes with the API)
```
python stage1_research\generate_synthetic_trace.py --out data\samples --rows 150000
python run_cli.py --trace data\samples\pcie_trace_export.csv --max-windows 6
```
`data/samples/injected_faults.json` lists what must be found (F1–F10 with packet numbers).

### 4c. Server + UI (for the user to click through)
```
python run_server.py --host 0.0.0.0 --port 8000
```
Open `http://<host>:8000`, paste the **server-side CSV path** (do not upload multi-GB files); the URL/key/model fields
can stay empty when `.env` is set (the page says so), click Analyze. The page shows live substage progress, then root causes, findings (with X / X+Y / Y and packet
numbers), the embedded report, and a **Download test cases (.zip)** button. API: `POST /api/jobs` (form fields
`trace_path` or file `trace`, `provider`, `model`, …), `GET /api/jobs/{id}`, `/report`, `/findings`, `/testcases.zip`.

**Check after the run:** `status.json` has `"status": "done"`; `report.html` exists; `llm_log.json` shows `"ok": true`
for the calls (a few failed calls are tolerated: the pipeline falls back to deterministic text for that item).

## 5. What to hand back to the user

1. `data/jobs/<job>/report.html` (self-contained; open in a browser).
2. The executive summary from `root_causes.json` → `executive_summary`, and the root-cause list (id, title, severity,
   responsible side, latency impact, evidence packets). Packet numbers = the `Packet` column of their CSV, so they can
   jump to them in the Teledyne software.
3. `data/jobs/<job>/testcases/` (or the zip from the UI): one `TC-*.sh` per root cause. Tell the user:
   `DRY_RUN=1 bash TC-xxx.sh` prints the steps; on the validation host `PCIE_TC_LIVE=1 pytest -q testcases` runs them;
   `analyzer_triggers.md` says what to arm on the Summit before each test.
4. `deterministic_trace.json` → `schema_mapping` / `schema_missing` / `nvme.bar0` (see section 6) so the user knows
   the export was fully understood.

## 6. First-real-export checks and fixes (the only places you may need to touch code)

The 112 column **names** were confirmed by the owner; the cell **formats** were assumed from Teledyne conventions.
After the deterministic pass (even before the LLM phase finishes), open `data/jobs/<job>/deterministic_trace.json`:

| Symptom | Meaning | Fix |
|---|---|---|
| `schema_missing` lists columns (e.g. `psn`, `data`, `time`) | a header name differs from the aliases | add the exact header text (lower-case) to `COLUMN_ALIASES` in `backend/csv_schema.py` |
| `counts.by_type` has almost everything under `OTHER` | TLP/DLLP/OS/Link Event columns not recognised | same as above for `tlp_type`, `dllp_type`, `os_type`, `link_event` |
| `duration_s` is 0 or absurd | Time Stamp format not parsed | extend `parse_time_to_seconds` in `csv_schema.py` with the real format (print 3 raw values first) |
| `nvme.bar0` is null and `nvme.completed_commands` is 0 | no CfgWr0 to register 0x10 in the trace (recording started after enumeration) and the doorbell heuristic found nothing | set `self.bar0 = 0x<BAR0 from lspci -v>` in `DeterministicAnalyzer.__init__` (`backend/analyzer/deterministic.py`) |
| commands decoded but all opcodes are `?` | `Data` column empty or truncated below 64 bytes | re-export with payload data visible; link/transaction findings still work |
| `counts.errors.lcrc_error` is huge (thousands) | the LCRC cell annotation differs (e.g. a separate marker) | adjust `BAD_RE` in `deterministic.py`; print a few LCRC cells of known-bad packets first |
| `speed_width.time_s` only has `unknown` | Link Event / TS_Data Rate wording differs | adjust the keywords in `_event()` / `_ts_rate()` in `deterministic.py` |
| direction values are not Upstream/Downstream or Up/Down | different wording | normalise in `compact_row` and in `_tlp`/`_dllp` comparisons (`deterministic.py`) |

After any fix: `python -m pytest -q tests` must still pass, then rerun 4a.

## 7. Tunables (`backend/config.py` or environment)

`LLM_PROVIDER`, `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`, `LLM_CONTEXT_TOKENS` (window budget = context × 0.8 − output − system),
`LLM_MAX_OUTPUT_TOKENS`, `MAX_LLM_WINDOWS` (default 24; cost/time cap), `CSV_CHUNK_ROWS` (250000),
`AnalysisConfig.slow_cmd_abs_us` (1000) / `slow_cmd_ratio` (8), `window_before/after/overlap_rows` (60/90/25), `idle_gap_us` (500).

## 8. Files

```
AGENT_INSTRUCTIONS.md           this file (CLAUDE.md points here)
.env.example                    copy to .env: LLM_BASE_URL, LLM_API_KEY, LLM_MODEL
setup_and_run.ps1 / .sh         install + verify + run with a CSV path (writes .env from -BaseUrl/-ApiKey/-Model if given)
run_server.py / run_cli.py      server / headless entry points
backend/                        app.py (FastAPI), config.py, csv_schema.py, analyzer/{deterministic,spec_rules,chunker,llm_client,prompts,llm_pipeline,testgen,report}.py
frontend/                       index.html, app.js, style.css
tests/test_pipeline.py          16 validation tests
stage1_research/                synthetic export generator (--size-gb N)
data/samples/                   small synthetic export + injected_faults.json (ground truth)
data/jobs/sample-haiku, big-2gb-haiku   reference outputs of the validated runs (reports, root causes, test cases)
docs/                           CLAUDE_CODE_PROMPT.md, stage1_problem_catalog.html, how_it_works.html, final_report_what_was_done.html
```
