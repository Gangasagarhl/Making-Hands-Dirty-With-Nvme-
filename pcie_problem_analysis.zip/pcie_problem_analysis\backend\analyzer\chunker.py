"""Stage 2 / Substage 2.3 - evidence windows for a small-context LLM, cut from a multi-GB CSV.

Why not chunk the whole file? A 2-5 GB export is 4-10 M packets; at ~35 tokens per packet that is 150-350 M
tokens. Even with overlap-free 20k-token chunks that is >7,000 LLM calls per trace and the model would see
mostly healthy Ack/MWr traffic. Instead the deterministic pass pins every anomaly to a packet number and
the chunker builds three kinds of context, all sized to the model budget:

  1. Anomaly windows   - rows [pkt - before, pkt + after] around each evidence packet of a finding.
                         Ranges that touch are merged; consecutive windows of the same finding keep an
                         `overlap_rows` overlap so a mechanism spanning a cut (e.g. Nak -> replay) is never split.
  2. Command windows   - for a slow NVMe command: the doorbell region, the SQE fetch/data, the start and end
                         of the data phase and the CQE region, with the elided middle summarised
                         ("... 1,234 packets skipped ...") so the whole command fits one call.
  3. Segment timeline  - per-segment statistics (one segment per CSV chunk of 250k rows) covering 100 % of the
                         trace in ~1-2k tokens, sent with every reduce call so coverage is complete even though
                         the model never reads the healthy 99.99 % of packets.

Token estimate ~3.3 characters per token (conservative for Qwen; Haiku is similar).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from .. import csv_schema
from ..config import AnalysisConfig

CHARS_PER_TOKEN = 3.3


def est_tokens(text: str) -> int:
    return int(len(text) / CHARS_PER_TOKEN) + 1


@dataclass
class EvidenceWindow:
    finding_id: str
    title: str
    ranges: list                      # [(start_pkt, end_pkt)]
    lines: list = field(default_factory=list)
    truncated: bool = False
    tokens: int = 0
    overlap_rows: int = 0

    def text(self) -> str:
        return "\n".join(self.lines)


def _merge(ranges: list[tuple[int, int]], overlap: int) -> list[tuple[int, int]]:
    """Merge ranges that touch or overlap; keep `overlap` rows shared between neighbours that are close."""
    out: list[list[int]] = []
    for a, b in sorted(ranges):
        if out and a <= out[-1][1] + overlap:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return [(max(1, a), b) for a, b in out]


def plan_ranges(findings, cfg: AnalysisConfig, max_windows: int) -> list[EvidenceWindow]:
    windows = []
    for f in findings[:max_windows]:
        pk = sorted({int(p) for p in f.evidence_packets if p is not None and int(p) >= 0})
        if not pk:
            continue
        before, after = cfg.window_before, cfg.window_after
        if f.kind in ("slow_nvme_command", "l1_exit_latency", "nvme_command_never_completed", "completion_timeout"):
            # command-centred: tighter around each anchor, but every anchor (doorbell, fetch, CQE, L1 events) is kept
            before, after = max(20, before // 2), max(30, after // 2)
        ranges = [(p - before, p + after) for p in pk]
        merged = _merge(ranges, cfg.window_overlap_rows)
        # bound the number of ranges per window: keep the first, the last and the ones around the most severe anchors
        if len(merged) > 8:
            merged = merged[:4] + merged[-4:]
        w = EvidenceWindow(f.id, f.title, merged, overlap_rows=cfg.window_overlap_rows)
        windows.append(w)
    return windows


def fill_windows(csv_path: str, windows: list[EvidenceWindow], mapping: dict, cfg: AnalysisConfig, budget_tokens: int,
                 progress=None) -> list[EvidenceWindow]:
    """Second streaming pass: materialise only the requested packet ranges."""
    if not windows:
        return windows
    wanted = sorted((a, b, i) for i, w in enumerate(windows) for a, b in w.ranges)
    lo, hi = wanted[0][0], max(b for _, b, _ in wanted)
    collected: dict[int, dict[int, str]] = {i: {} for i in range(len(windows))}
    with open(csv_path, "rb") as fh:
        reader = pd.read_csv(fh, chunksize=cfg.chunk_rows, dtype=str, keep_default_na=False, on_bad_lines="skip",
                             engine="c", encoding_errors="replace")
        for raw in reader:
            df = csv_schema.normalize_chunk(raw, mapping)
            pk = df["pkt_n"].to_numpy()
            pmin, pmax = int(pk.min()), int(pk.max())
            if pmax < lo:
                continue
            if pmin > hi:
                break
            for a, b, i in wanted:
                if b < pmin or a > pmax:
                    continue
                m = (pk >= a) & (pk <= b)
                if not m.any():
                    continue
                for r in df[m].itertuples(index=False):
                    collected[i][int(r.pkt_n)] = csv_schema.compact_row(r)
            if progress:
                progress(f"evidence extraction up to packet {pmax:,}", None)
    for i, w in enumerate(windows):
        rows = sorted(collected[i].items())
        lines, last = [], None
        for p, line in rows:
            if last is not None and p - last > 1:
                lines.append(f"... ({p - last - 1:,} packets skipped) ...")
            lines.append(line)
            last = p
        w.lines = _trim_to_budget(lines, budget_tokens, w)
        w.tokens = est_tokens(w.text())
    return windows


def _trim_to_budget(lines: list[str], budget: int, w: EvidenceWindow) -> list[str]:
    total = sum(est_tokens(l) + 1 for l in lines)
    if total <= budget:
        return lines
    w.truncated = True
    anchors = [(a + b) // 2 for a, b in w.ranges]

    def pnum(line):
        try:
            return int(line.split()[0].lstrip("#"))
        except Exception:
            return None

    scored = []
    for idx, line in enumerate(lines):
        p = pnum(line)
        dist = min(abs(p - a) for a in anchors) if p is not None else 10 ** 9
        scored.append((dist, idx))
    keep = set()
    used = 0
    for dist, idx in sorted(scored):
        c = est_tokens(lines[idx]) + 1
        if used + c > budget:
            break
        keep.add(idx)
        used += c
    out, last_kept = [], True
    for idx, line in enumerate(lines):
        if idx in keep:
            if not last_kept:
                out.append("... (rows trimmed to token budget) ...")
            out.append(line)
            last_kept = True
        else:
            last_kept = False
    return out


def segment_timeline(det: dict, max_lines: int = 96) -> str:
    """Whole-trace coverage in ~1-2k tokens: one line per segment (or per merged group of segments)."""
    segs = det.get("segments") or []
    if not segs:
        return "(no segments)"
    group = max(1, (len(segs) + max_lines - 1) // max_lines)
    lines = ["seg | packets | t_start..t_end (s) | speed | tlps | naks | replays | badLCRC | errs | nvme_done | max_cmd_us | L1 | recov | cplTO | fcStall"]
    for i in range(0, len(segs), group):
        g = segs[i:i + group]
        agg = {k: sum(s.get(k, 0) or 0 for s in g) for k in ("rows", "tlps", "naks", "replays", "bad_lcrc", "errors", "nvme_completed",
                                                             "l1_entries", "recovery", "cpl_timeouts", "fc_stalls")}
        mx = max((s.get("max_cmd_latency_us") or 0) for s in g)
        lines.append(f"{g[0]['segment']}-{g[-1]['segment']} | #{g[0]['first_pkt']:,}-#{g[-1]['last_pkt']:,} | "
                     f"{(g[0].get('t_start') or 0):.4f}..{(g[-1].get('t_end') or 0):.4f} | {g[-1].get('speed')} | {agg['tlps']:,} | {agg['naks']} | "
                     f"{agg['replays']} | {agg['bad_lcrc']} | {agg['errors']} | {agg['nvme_completed']:,} | {mx:.0f} | {agg['l1_entries']} | "
                     f"{agg['recovery']} | {agg['cpl_timeouts']} | {agg['fc_stalls']}")
    return "\n".join(lines)


def summary_for_llm(det: dict, max_chars: int = 6000) -> str:
    nv = det.get("nvme", {})
    sw = det.get("speed_width", {}).get("time_s", {})
    parts = [
        f"rows={det['rows']:,} last_packet={det['max_packet']:,} duration_s={det['duration_s']:.6f} columns_mapped={len(det.get('schema_mapping', {}))}",
        "link speed|width residency (s): " + ", ".join(f"{k}: {v}" for k, v in sorted(sw.items(), key=lambda kv: -kv[1])[:6]),
        "packet mix: " + ", ".join(f"{k}={v:,}" for k, v in list(det['counts']['by_packet_type'].items())[:16]),
        "anomaly classes: " + (", ".join(f"{k}={v}" for k, v in det['counts']['errors'].items()) or "none"),
        f"completion latency us (all non-posted): {det['completion_latency_us']}",
        f"ack latency us: {det['ack_latency_us']}  max UpdateFC gap us: {det['max_updatefc_gap_us']}",
        f"NVMe: BAR0={nv.get('bar0')} completed={nv.get('completed_commands')} by opcode={nv.get('commands_by_opcode')}",
        "NVMe latency by opcode us: " + "; ".join(f"{k}: med {v.get('median_us')} p99 {v.get('p99_us')} max {v.get('max_us')} n={v.get('n')}"
                                                 for k, v in nv.get('latency_by_opcode_us', {}).items() if v.get('n')),
        f"L1 cycles: {len(det.get('pm_l1_intervals', []))}  config-space packets: {len(det.get('config_space', []))}",
    ]
    return "\n".join(parts)[:max_chars]
